<?php
$url = 'http://localhost:8000/livestream/1';
$html = @file_get_contents($url);
echo "=== Full output ===\n";
echo $html;
