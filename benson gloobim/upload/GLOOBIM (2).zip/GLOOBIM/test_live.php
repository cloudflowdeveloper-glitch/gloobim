<?php
$url = 'http://localhost:8000/livestream/1';
$html = @file_get_contents($url);
if ($html === false) {
    echo "FAILED\n";
    exit(1);
}
echo "Length: " . strlen($html) . "\n";
echo "Has DOCTYPE: " . (str_contains($html, '<!DOCTYPE') ? 'Y' : 'N') . "\n";
echo "Has Fatal: " . (str_contains($html, 'Fatal error') ? 'Y' : 'N') . "\n";
echo "Has Undefined: " . (str_contains($html, 'Undefined') ? 'Y' : 'N') . "\n";
echo "Has body: " . (str_contains($html, '<body') ? 'Y' : 'N') . "\n";
echo "Has /html: " . (str_contains($html, '</html>') ? 'Y' : 'N') . "\n";
echo "Has fixed: " . (str_contains($html, 'fixed inset-0') ? 'Y' : 'N') . "\n";
echo "Has stream title: " . (str_contains($html, 'Late Night') || str_contains($html, 'Music Session') ? 'Y' : 'N') . "\n";
echo "\n--- First 400 chars ---\n";
echo substr($html, 0, 400);
echo "\n\n--- Last 200 chars ---\n";
echo substr($html, -200);
