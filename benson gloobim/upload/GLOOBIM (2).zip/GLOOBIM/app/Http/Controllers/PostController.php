<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class PostController extends Controller
{
    public function index(): Response
    {
        return $this->view('posts.index', ['posts' => $this->getPosts()]);
    }

    public function create(): Response
    {
        return $this->view('posts.create');
    }

    public function store(): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $content = trim($input['content'] ?? '');

        if (empty($content)) {
            return $this->json(['error' => 'Content is required'], 422);
        }

        try {
            $postId = Database::insert('posts', [
                'user_id' => $user['id'],
                'content' => $content,
                'image_url' => $input['image_url'] ?? null,
                'status' => 'published',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->json([
                'message' => 'Post created successfully',
                'post_id' => $postId,
            ], 201);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function show($id): Response
    {
        $post = $this->getPostById($id);
        if (!$post) {
            return $this->redirect('/');
        }
        return $this->view('posts.show', [
            'post' => $post,
            'comments' => $this->getComments($id),
        ]);
    }

    public function edit($id): Response
    {
        return $this->view('posts.edit', ['id' => $id]);
    }

    public function update($id): Response
    {
        return $this->json(['message' => 'Post updated successfully']);
    }

    public function destroy($id): Response
    {
        try {
            Database::execute("UPDATE posts SET status = 'deleted' WHERE id = ?", [$id]);
            return $this->json(['message' => 'Post deleted successfully']);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function like($id): Response
    {
        try {
            Database::execute("UPDATE posts SET likes = COALESCE(likes, 0) + 1 WHERE id = ?", [$id]);
            $post = Database::query("SELECT likes FROM posts WHERE id = ?", [$id]);
            return $this->json(['message' => 'Liked', 'likes' => $post[0]['likes'] ?? 0]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function comment($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $body = trim($input['body'] ?? '');

        if (empty($body)) {
            return $this->json(['error' => 'Comment body is required'], 422);
        }

        try {
            Database::insert('comments', [
                'user_id' => $user['id'],
                'commentable_type' => 'post',
                'commentable_id' => $id,
                'body' => $body,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            Database::execute(
                "UPDATE posts SET comments_count = COALESCE(comments_count, 0) + 1 WHERE id = ?",
                [$id]
            );

            $post = Database::query("SELECT comments_count FROM posts WHERE id = ?", [$id]);
            $commentsCount = $post[0]['comments_count'] ?? 0;

            return $this->json([
                'message' => 'Comment added',
                'post_id' => $id,
                'comments_count' => $commentsCount,
                'user_name' => $user['name'],
                'user_avatar' => $user['avatar'] ?? null,
            ]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function share($id): Response
    {
        try {
            Database::execute("UPDATE posts SET shares = COALESCE(shares, 0) + 1 WHERE id = ?", [$id]);
            return $this->json(['message' => 'Shared', 'post_id' => $id]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function uploadImage(): Response
    {
        return $this->json(['message' => 'Image uploaded', 'url' => 'https://picsum.photos/id/1/600/400']);
    }

    protected function getPosts(): array
    {
        try {
            return Database::query(
                "SELECT p.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM posts p
                 INNER JOIN users u ON p.user_id = u.id
                 WHERE p.status = 'published'
                 ORDER BY p.created_at DESC
                 LIMIT 20"
            );
        } catch (\Exception $e) {
            return $this->fallbackPosts();
        }
    }

    protected function getPostById($id): ?array
    {
        try {
            $posts = Database::query(
                "SELECT p.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM posts p
                 INNER JOIN users u ON p.user_id = u.id
                 WHERE p.id = ? AND p.status = 'published'",
                [$id]
            );
            return $posts[0] ?? null;
        } catch (\Exception $e) {
            return null;
        }
    }

    protected function getComments($postId): array
    {
        try {
            return Database::query(
                "SELECT c.*, u.username, u.name AS commenter_name, u.avatar AS commenter_avatar
                 FROM comments c
                 INNER JOIN users u ON c.user_id = u.id
                 WHERE c.commentable_type = 'post' AND c.commentable_id = ?
                 ORDER BY c.created_at DESC
                 LIMIT 20",
                [$postId]
            );
        } catch (\Exception $e) {
            return [];
        }
    }

    protected function fallbackPosts(): array
    {
        return [
            [
                'id' => 1, 'user_id' => 2, 'content' => 'Just dropped a new dance challenge! 🔥💃 Who\'s trying this? Tag me in your videos! #dancechallenge #kukua #trending',
                'image_url' => 'https://picsum.photos/id/2/600/400', 'likes' => 12500, 'comments_count' => 843, 'shares' => 2100,
                'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1,
                'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours')),
            ],
            [
                'id' => 2, 'user_id' => 2, 'content' => 'Behind the scenes of today\'s photoshoot! 📸✨ The lighting was perfect for this shoot. Check out the full album on my page.',
                'image_url' => 'https://picsum.photos/id/3/600/400', 'likes' => 8400, 'comments_count' => 521, 'shares' => 980,
                'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1,
                'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours')),
            ],
            [
                'id' => 3, 'user_id' => 1, 'content' => 'Big things coming to DTTube! 🚀 New features dropping next week. Stay tuned for updates on monetization, live streaming upgrades, and more!',
                'image_url' => null, 'likes' => 3200, 'comments_count' => 189, 'shares' => 450,
                'creator_name' => 'DTTube Admin', 'username' => 'admin', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1,
                'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')),
            ],
        ];
    }
}
