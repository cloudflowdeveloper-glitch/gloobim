<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class MarketplaceController extends Controller
{
    public function index(): Response
    {
        $listings = [];
        $user = \Core\Auth::user();
        $category = $_GET['category'] ?? '';
        $search = trim($_GET['search'] ?? '');
        $sort = $_GET['sort'] ?? 'latest';
        $minPrice = (float)($_GET['min_price'] ?? 0);
        $maxPrice = (float)($_GET['max_price'] ?? 0);

        try {
            $sql = "SELECT ml.*, u.username, u.name AS seller_name, u.avatar AS seller_avatar, u.is_verified
                    FROM marketplace_listings ml
                    INNER JOIN users u ON ml.user_id = u.id
                    WHERE ml.status = 'active'";
            $params = [];

            if ($category && $category !== 'all') {
                $sql .= " AND ml.category = ?";
                $params[] = $category;
            }

            if ($search) {
                $sql .= " AND (ml.title LIKE ? OR ml.description LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }

            if ($minPrice > 0) {
                $sql .= " AND ml.price >= ?";
                $params[] = $minPrice;
            }

            if ($maxPrice > 0) {
                $sql .= " AND ml.price <= ?";
                $params[] = $maxPrice;
            }

            switch ($sort) {
                case 'price_asc':
                    $sql .= " ORDER BY ml.price ASC";
                    break;
                case 'price_desc':
                    $sql .= " ORDER BY ml.price DESC";
                    break;
                case 'views':
                    $sql .= " ORDER BY ml.views DESC";
                    break;
                default:
                    $sql .= " ORDER BY ml.created_at DESC";
                    break;
            }

            $sql .= " LIMIT 30";

            $listings = Database::query($sql, $params);
        } catch (\Exception $e) {
            $listings = [];
        }

        if (empty($listings)) {
            $listings = $this->fallbackListings();
        }

        $categories = Database::query(
            "SELECT category, COUNT(*) AS count FROM marketplace_listings WHERE status = 'active' GROUP BY category ORDER BY count DESC"
        );
        if (empty($categories)) {
            $categories = [
                ['count' => 4, 'category' => 'Electronics'],
                ['count' => 2, 'category' => 'Fashion'],
                ['count' => 1, 'category' => 'Home'],
                ['count' => 1, 'category' => 'Collectibles'],
            ];
        }

        $userListings = [];
        if ($user) {
            try {
                $userListings = Database::query(
                    "SELECT * FROM marketplace_listings WHERE user_id = ? AND status != 'deleted' ORDER BY created_at DESC LIMIT 5",
                    [$user['id']]
                );
            } catch (\Exception $e) {}
        }

        return $this->view('marketplace.index', [
            'listings' => $listings,
            'categories' => $categories,
            'userListings' => $userListings,
            'activeCategory' => $category,
            'search' => $search,
            'sort' => $sort,
            'minPrice' => $minPrice,
            'maxPrice' => $maxPrice,
            'currencyInfo' => $user ? $this->getUserCurrency($user) : ['code' => 'USD', 'symbol' => '$', 'rate' => 1],
        ]);
    }

    public function show($id): Response
    {
        $listing = null;

        try {
            $listings = Database::query(
                "SELECT ml.*, u.username, u.name AS seller_name, u.avatar AS seller_avatar, u.is_verified
                 FROM marketplace_listings ml
                 INNER JOIN users u ON ml.user_id = u.id
                 WHERE ml.id = ? AND ml.status != 'deleted'
                 LIMIT 1",
                [$id]
            );
            $listing = $listings[0] ?? null;

            if ($listing) {
                Database::execute("UPDATE marketplace_listings SET views = views + 1 WHERE id = ?", [$id]);
            }
        } catch (\Exception $e) {
            $listing = null;
        }

        if (!$listing) {
            $listings = $this->fallbackListings();
            $listing = array_filter($listings, fn($l) => $l['id'] == $id);
            $listing = reset($listing) ?: null;
        }

        $user = \Core\Auth::user();
        $currencyInfo = $user ? $this->getUserCurrency($user) : ['code' => 'USD', 'symbol' => '$', 'rate' => 1];

        return $this->view('marketplace.show', [
            'listing' => $listing,
            'currencyInfo' => $currencyInfo,
        ]);
    }

    public function create(): Response
    {
        $user = \Core\Auth::user();
        $currencyInfo = $user ? $this->getUserCurrency($user) : ['code' => 'USD', 'symbol' => '$', 'rate' => 1];
        return $this->view('marketplace.create', ['currencyInfo' => $currencyInfo]);
    }

    public function store(): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $title = trim($_POST['title'] ?? '');

        if (empty($title)) {
            return $this->json(['error' => 'Title is required'], 422);
        }

        $price = (float)($_POST['price'] ?? 0);
        if ($price <= 0) {
            return $this->json(['error' => 'Valid price is required'], 422);
        }

        $image_url = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image_url = $this->uploadImage($_FILES['image']);
        } elseif (!empty($_POST['image_url'])) {
            $image_url = trim($_POST['image_url']);
        }

        $currencyInfo = $this->getUserCurrency($user);

        try {
            $listingId = Database::insert('marketplace_listings', [
                'user_id' => $user['id'],
                'title' => $title,
                'description' => trim($_POST['description'] ?? ''),
                'price' => $price,
                'currency' => $currencyInfo['code'],
                'image_url' => $image_url,
                'category' => $_POST['category'] ?? 'Other',
                'condition' => $_POST['condition'] ?? 'good',
                'location' => trim($_POST['location'] ?? ''),
                'phone' => trim($_POST['phone'] ?? ''),
                'status' => 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->json([
                'message' => 'Listing created successfully!',
                'listing_id' => $listingId,
            ], 201);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function edit($id): Response
    {
        $user = \Core\Auth::user();
        $listing = null;

        try {
            $listings = Database::query(
                "SELECT * FROM marketplace_listings WHERE id = ? AND user_id = ? AND status != 'deleted' LIMIT 1",
                [$id, $user['id'] ?? 0]
            );
            $listing = $listings[0] ?? null;
        } catch (\Exception $e) {}

        if (!$listing) {
            return $this->redirect('/marketplace');
        }

        $currencyInfo = $user ? $this->getUserCurrency($user) : ['code' => 'USD', 'symbol' => '$', 'rate' => 1];

        return $this->view('marketplace.edit', [
            'listing' => $listing,
            'currencyInfo' => $currencyInfo,
        ]);
    }

    public function update($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $title = trim($_POST['title'] ?? '');

        if (empty($title)) {
            return $this->json(['error' => 'Title is required'], 422);
        }

        try {
            $listings = Database::query("SELECT * FROM marketplace_listings WHERE id = ? AND user_id = ?", [$id, $user['id']]);
            if (empty($listings)) return $this->json(['error' => 'Not found'], 404);
            $listing = $listings[0];

            $image_url = $listing['image_url'];
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploaded = $this->uploadImage($_FILES['image']);
                if ($uploaded) $image_url = $uploaded;
            } elseif (isset($_POST['image_url']) && $_POST['image_url'] !== $listing['image_url']) {
                $image_url = trim($_POST['image_url']);
            }
            if (!empty($_POST['remove_image'])) {
                $image_url = null;
            }

            $currencyInfo = $this->getUserCurrency($user);

            Database::execute(
                "UPDATE marketplace_listings SET title = ?, description = ?, price = ?, currency = ?, category = ?, condition = ?, location = ?, phone = ?, image_url = ?, updated_at = NOW() WHERE id = ? AND user_id = ?",
                [$title, trim($_POST['description'] ?? ''), (float)($_POST['price'] ?? 0), $currencyInfo['code'], $_POST['category'] ?? 'Other', $_POST['condition'] ?? 'good', trim($_POST['location'] ?? ''), trim($_POST['phone'] ?? ''), $image_url, $id, $user['id']]
            );

            return $this->json(['message' => 'Listing updated successfully!', 'listing_id' => $id]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function destroy($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        try {
            Database::execute(
                "UPDATE marketplace_listings SET status = 'deleted', updated_at = NOW() WHERE id = ? AND user_id = ?",
                [$id, $user['id']]
            );
            return $this->json(['message' => 'Listing removed']);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function markSold($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        try {
            Database::execute(
                "UPDATE marketplace_listings SET sold = 1, status = 'sold', updated_at = NOW() WHERE id = ? AND user_id = ?",
                [$id, $user['id']]
            );
            return $this->json(['message' => 'Marked as sold']);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function my(): Response
    {
        $user = \Core\Auth::user();
        $listings = [];

        if ($user) {
            try {
                $listings = Database::query(
                    "SELECT ml.*, u.username, u.name AS seller_name, u.avatar AS seller_avatar, u.is_verified
                     FROM marketplace_listings ml
                     INNER JOIN users u ON ml.user_id = u.id
                     WHERE ml.user_id = ? AND ml.status != 'deleted'
                     ORDER BY ml.created_at DESC
                     LIMIT 30",
                    [$user['id']]
                );
            } catch (\Exception $e) {}
        }

        return $this->view('marketplace.my', ['listings' => $listings]);
    }

    protected function fallbackListings(): array
    {
        return [
            ['id' => 1, 'user_id' => 2, 'title' => 'iPhone 15 Pro Max 256GB', 'description' => 'Brand new, box sealed. Natural Titanium.', 'price' => 180000, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/0/400/300', 'category' => 'Electronics', 'condition' => 'new', 'location' => 'Nairobi', 'views' => 2340, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
            ['id' => 2, 'user_id' => 2, 'title' => 'MacBook Air M3 - 16GB RAM', 'description' => 'Lightly used, battery cycle: 12', 'price' => 145000, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/1/400/300', 'category' => 'Electronics', 'condition' => 'like_new', 'location' => 'Nairobi', 'views' => 1870, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
            ['id' => 3, 'user_id' => 2, 'title' => 'Wireless Studio Headphones', 'description' => 'Noise-cancelling, perfect for creators', 'price' => 8500, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/2/400/300', 'category' => 'Electronics', 'condition' => 'good', 'location' => 'Nairobi', 'views' => 3120, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
            ['id' => 5, 'user_id' => 2, 'title' => 'Vintage Vinyl Collection', 'description' => '12 records including Fela Kuti, Miriam Makeba', 'price' => 12000, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/39/400/300', 'category' => 'Collectibles', 'condition' => 'good', 'location' => 'Nairobi', 'views' => 1560, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-4 days'))],
            ['id' => 6, 'user_id' => 2, 'title' => 'Gaming Console PS5 Digital', 'description' => 'Brand new, still sealed', 'price' => 65000, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/4/400/300', 'category' => 'Electronics', 'condition' => 'new', 'location' => 'Nairobi', 'views' => 4100, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
            ['id' => 7, 'user_id' => 2, 'title' => 'Modern Desk Lamp LED', 'description' => 'Adjustable brightness, USB powered', 'price' => 2500, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/5/400/300', 'category' => 'Home', 'condition' => 'new', 'location' => 'Nairobi', 'views' => 340, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-6 days'))],
            ['id' => 8, 'user_id' => 2, 'title' => 'Handmade Beaded Jewelry Set', 'description' => 'Handcrafted by local artisans', 'price' => 3200, 'currency' => 'KES', 'image_url' => 'https://picsum.photos/id/6/400/300', 'category' => 'Fashion', 'condition' => 'good', 'location' => 'Nairobi', 'views' => 670, 'sold' => 0, 'status' => 'active', 'seller_name' => 'Zara Ke', 'username' => 'zarake', 'seller_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
        ];
    }

    protected function getUserCurrency($user): array
    {
        $countryCode = $user['country_code'] ?? 'KE';
        try {
            $currencies = Database::query(
                "SELECT currency_code, currency_symbol, exchange_rate_usd FROM country_currencies WHERE country_code = ?",
                [$countryCode]
            );
            if (!empty($currencies)) {
                return [
                    'code' => $currencies[0]['currency_code'],
                    'symbol' => $currencies[0]['currency_symbol'],
                    'rate' => (float)$currencies[0]['exchange_rate_usd'],
                ];
            }
        } catch (\Exception $e) {}
        return ['code' => 'KES', 'symbol' => 'KES', 'rate' => 129.50];
    }

    protected function uploadImage(array $file): ?string
    {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;

        if (!in_array($file['type'], $allowedTypes)) return null;
        if ($file['size'] > $maxSize) return null;

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'listing_' . uniqid() . '_' . time() . '.' . $ext;
        $uploadDir = __DIR__ . '/../../../../public/uploads/marketplace';

        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }

        $dest = $uploadDir . '/' . $filename;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            return '/uploads/marketplace/' . $filename;
        }

        return null;
    }
}
