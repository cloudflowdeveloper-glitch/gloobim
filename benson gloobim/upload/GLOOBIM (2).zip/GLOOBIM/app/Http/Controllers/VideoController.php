<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class VideoController extends Controller
{
    public function index(): Response
    {
        $videos = [];

        try {
            $videos = Database::query(
                "SELECT v.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM videos v
                 INNER JOIN users u ON v.user_id = u.id
                 WHERE v.status = 'published'
                 ORDER BY v.created_at DESC
                 LIMIT 20"
            );
        } catch (\Exception $e) {
            $videos = [];
        }

        if (empty($videos)) {
            $videos = [
                ['id' => 1, 'title' => 'Building a Startup in Africa - Full Documentary', 'description' => 'The complete journey of building a tech startup from Nairobi', 'thumbnail' => 'https://picsum.photos/id/40/400/225', 'duration' => 2720, 'views' => 1200000, 'likes' => 45000, 'comments_count' => 2300, 'shares' => 8900, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
                ['id' => 2, 'title' => 'How to Make Money as a Creator in 2025', 'description' => 'Complete guide to monetizing your content', 'thumbnail' => 'https://picsum.photos/id/41/400/225', 'duration' => 1335, 'views' => 890000, 'likes' => 32000, 'comments_count' => 1800, 'shares' => 6700, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
                ['id' => 3, 'title' => 'Lagos to Nairobi: Road Trip Vlog', 'description' => 'Cross-country adventure through East and West Africa', 'thumbnail' => 'https://picsum.photos/id/42/400/225', 'duration' => 1905, 'views' => 670000, 'likes' => 21000, 'comments_count' => 980, 'shares' => 4500, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
                ['id' => 4, 'title' => 'Learn Flutter in 2 Hours - Complete Course', 'description' => 'Full Flutter development course for beginners', 'thumbnail' => 'https://picsum.photos/id/43/400/225', 'duration' => 7290, 'views' => 2100000, 'likes' => 89000, 'comments_count' => 5600, 'shares' => 23000, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
                ['id' => 5, 'title' => 'Best Afrobeat Mix 2025', 'description' => 'Non-stop afrobeats mix for your playlist', 'thumbnail' => 'https://picsum.photos/id/44/400/225', 'duration' => 4500, 'views' => 3500000, 'likes' => 120000, 'comments_count' => 7800, 'shares' => 34000, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
                ['id' => 6, 'title' => 'Street Food Tour: Accra Edition', 'description' => 'Trying the best street food in Accra, Ghana', 'thumbnail' => 'https://picsum.photos/id/45/400/225', 'duration' => 1110, 'views' => 450000, 'likes' => 15000, 'comments_count' => 670, 'shares' => 2100, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1],
            ];
        }

        return $this->view('videos.index', ['videos' => $videos]);
    }

    public function create(): Response
    {
        return $this->view('videos.create');
    }

    public function store(): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $title = trim($input['title'] ?? '');

        if (empty($title)) {
            return $this->json(['error' => 'Title is required'], 422);
        }

        try {
            $videoId = Database::insert('videos', [
                'user_id' => $user['id'],
                'title' => $title,
                'description' => trim($input['description'] ?? ''),
                'thumbnail' => $input['thumbnail'] ?? null,
                'video_url' => $input['video_url'] ?? null,
                'duration' => (int)($input['duration'] ?? 0),
                'category' => $input['category'] ?? null,
                'status' => 'published',
                'published_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->json(['message' => 'Video uploaded successfully', 'video_id' => $videoId], 201);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function show($id): Response
    {
        $video = null;
        try {
            $videos = Database::query(
                "SELECT v.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM videos v
                 INNER JOIN users u ON v.user_id = u.id
                 WHERE v.id = ? AND v.status = 'published'
                 LIMIT 1",
                [$id]
            );
            $video = $videos[0] ?? null;
        } catch (\Exception $e) {
            $video = null;
        }

        if (!$video) {
            $video = [
                'id' => $id, 'title' => 'Video #' . $id, 'description' => 'No description available',
                'thumbnail' => 'https://picsum.photos/id/40/400/225', . $id,
                'duration' => 0, 'views' => 0, 'likes' => 0, 'comments_count' => 0, 'shares' => 0,
                'creator_name' => 'DTTube', 'username' => 'dttube',
                'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1,
            ];
        }

        return $this->view('videos.show', [
            'video' => $video,
            'comments' => $this->getComments($id),
        ]);
    }

    public function edit($id): Response
    {
        return $this->view('videos.edit', ['id' => $id]);
    }

    public function update($id): Response
    {
        return $this->json(['message' => 'Video updated successfully']);
    }

    public function destroy($id): Response
    {
        try {
            Database::execute("UPDATE videos SET status = 'deleted' WHERE id = ?", [$id]);
            return $this->json(['message' => 'Video deleted successfully']);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function like($id): Response
    {
        try {
            Database::execute("UPDATE videos SET likes = COALESCE(likes, 0) + 1 WHERE id = ?", [$id]);
            $video = Database::query("SELECT likes FROM videos WHERE id = ?", [$id]);
            return $this->json(['message' => 'Liked', 'likes' => $video[0]['likes'] ?? 0]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function comment($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $body = trim($input['body'] ?? '');

        if (empty($body)) {
            return $this->json(['error' => 'Comment body is required'], 422);
        }

        try {
            Database::insert('comments', [
                'user_id' => $user['id'],
                'commentable_type' => 'video',
                'commentable_id' => $id,
                'body' => $body,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            Database::execute("UPDATE videos SET comments_count = COALESCE(comments_count, 0) + 1 WHERE id = ?", [$id]);

            return $this->json([
                'message' => 'Comment added',
                'user_name' => $user['name'],
                'user_avatar' => $user['avatar'] ?? null,
            ]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function share($id): Response
    {
        try {
            Database::execute("UPDATE videos SET shares = COALESCE(shares, 0) + 1 WHERE id = ?", [$id]);
            return $this->json(['message' => 'Shared', 'video_id' => $id]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    protected function getComments($videoId): array
    {
        try {
            return Database::query(
                "SELECT c.*, u.username, u.name AS commenter_name, u.avatar AS commenter_avatar
                 FROM comments c
                 INNER JOIN users u ON c.user_id = u.id
                 WHERE c.commentable_type = 'video' AND c.commentable_id = ?
                 ORDER BY c.created_at DESC
                 LIMIT 20",
                [$videoId]
            );
        } catch (\Exception $e) {
            return [];
        }
    }
}
