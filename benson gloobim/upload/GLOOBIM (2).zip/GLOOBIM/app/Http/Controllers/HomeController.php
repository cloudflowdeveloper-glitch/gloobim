<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class HomeController extends Controller
{
    public function index(): Response
    {
        return $this->view('home.index', [
            'trendingReels' => $this->getTrendingReels(),
            'trendingVideos' => $this->getTrendingVideos(),
            'topCreators' => $this->getTopCreators(),
            'liveNow' => $this->getLivestreams(),
            'posts' => $this->getPosts(),
            'categories' => $this->getCategories(),
        ]);
    }

    protected function getTrendingReels(): array
    {
        try {
            return Database::query(
                "SELECT r.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM reels r
                 INNER JOIN users u ON r.user_id = u.id
                 WHERE r.status = 'published'
                 ORDER BY r.views DESC
                 LIMIT 8"
            );
        } catch (\Exception $e) {
            return $this->fallbackReels();
        }
    }

    protected function getTrendingVideos(): array
    {
        try {
            return Database::query(
                "SELECT v.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM videos v
                 INNER JOIN users u ON v.user_id = u.id
                 WHERE v.status = 'published'
                 ORDER BY v.views DESC
                 LIMIT 8"
            );
        } catch (\Exception $e) {
            return $this->fallbackVideos();
        }
    }

    protected function getTopCreators(): array
    {
        try {
            return Database::query(
                "SELECT u.*, COUNT(f.id) AS follower_count
                 FROM users u
                 LEFT JOIN followers f ON f.following_id = u.id
                 WHERE u.role IN ('creator', 'admin')
                 GROUP BY u.id
                 ORDER BY follower_count DESC
                 LIMIT 6"
            );
        } catch (\Exception $e) {
            return $this->fallbackCreators();
        }
    }

    protected function getLivestreams(): array
    {
        try {
            return Database::query(
                "SELECT l.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar
                 FROM livestreams l
                 INNER JOIN users u ON l.user_id = u.id
                 WHERE l.status = 'live'
                 ORDER BY l.viewers DESC"
            );
        } catch (\Exception $e) {
            return $this->fallbackLivestreams();
        }
    }

    protected function getPosts(): array
    {
        try {
            return Database::query(
                "SELECT p.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM posts p
                 INNER JOIN users u ON p.user_id = u.id
                 WHERE p.status = 'published'
                 ORDER BY p.created_at DESC
                 LIMIT 10"
            );
        } catch (\Exception $e) {
            return $this->fallbackPosts();
        }
    }

    protected function getCategories(): array
    {
        return [
            ['name' => 'Music', 'icon' => 'music_note', 'color' => 'bg-purple-600'],
            ['name' => 'Gaming', 'icon' => 'sports_esports', 'color' => 'bg-green-600'],
            ['name' => 'Tech', 'icon' => 'computer', 'color' => 'bg-blue-600'],
            ['name' => 'Comedy', 'icon' => 'sentiment_very_satisfied', 'color' => 'bg-yellow-600'],
            ['name' => 'Food', 'icon' => 'restaurant', 'color' => 'bg-red-600'],
            ['name' => 'Sports', 'icon' => 'sports_soccer', 'color' => 'bg-cyan-600'],
            ['name' => 'Fashion', 'icon' => 'checkroom', 'color' => 'bg-pink-600'],
            ['name' => 'Education', 'icon' => 'school', 'color' => 'bg-indigo-600'],
        ];
    }

    public function menu(): Response
    {
        return $this->view('menu.index');
    }

    public function notifications(): Response
    {
        return $this->view('notifications.index', [
            'notifications' => $this->getNotifications(),
        ]);
    }

    protected function getNotifications(): array
    {
        try {
            return Database::query(
                "SELECT n.*, u.name AS actor_name, u.username AS actor_username, u.avatar AS actor_avatar
                 FROM notifications n
                 LEFT JOIN users u ON n.user_id = u.id
                 ORDER BY n.created_at DESC LIMIT 30"
            );
        } catch (\Exception $e) {
            return $this->fallbackNotifications();
        }
    }

    protected function fallbackNotifications(): array
    {
        return [
            ['id' => 1, 'type' => 'like', 'title' => 'Zara Ke liked your reel', 'body' => '"Dance Challenge #Kukua"', 'is_read' => 0, 'actor_name' => 'Zara Ke', 'actor_username' => 'zarake', 'actor_avatar' => 'https://placehold.co/40x40/6d28d9/ffffff?text=ZK', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 minutes'))],
            ['id' => 2, 'type' => 'follow', 'title' => 'TechBro started following you', 'body' => null, 'is_read' => 0, 'actor_name' => 'TechBro', 'actor_username' => 'techbro', 'actor_avatar' => 'https://placehold.co/40x40/2563eb/ffffff?text=TB', 'created_at' => date('Y-m-d H:i:s', strtotime('-15 minutes'))],
            ['id' => 3, 'type' => 'comment', 'title' => 'ChefAmi commented on your post', 'body' => 'Amazing! 🔥', 'is_read' => 0, 'actor_name' => 'ChefAmi', 'actor_username' => 'chefami', 'actor_avatar' => 'https://placehold.co/40x40/10b981/ffffff?text=CA', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
            ['id' => 4, 'type' => 'tip', 'title' => 'You received a tip of KES 500', 'body' => 'From LaughKing', 'is_read' => 0, 'actor_name' => 'LaughKing', 'actor_username' => 'laughking', 'actor_avatar' => 'https://placehold.co/40x40/f59e0b/ffffff?text=LK', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))],
            ['id' => 5, 'type' => 'share', 'title' => 'BeatMaker shared your post', 'body' => 'Shared to 2.5K followers', 'is_read' => 0, 'actor_name' => 'BeatMaker', 'actor_username' => 'beatmaker', 'actor_avatar' => 'https://placehold.co/40x40/d97706/ffffff?text=BM', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 hours'))],
            ['id' => 6, 'type' => 'verified', 'title' => 'Account Verified!', 'body' => 'Your creator account has been verified. Check mark unlocked!', 'is_read' => 0, 'actor_name' => 'DTTube', 'actor_username' => 'dttube', 'actor_avatar' => 'https://placehold.co/40x40/4f46e5/ffffff?text=DT', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))],
            ['id' => 7, 'type' => 'like', 'title' => 'DJ MixMaster and 12 others liked your reel', 'body' => null, 'is_read' => 0, 'actor_name' => 'DJ MixMaster', 'actor_username' => 'djmixmaster', 'actor_avatar' => 'https://placehold.co/40x40/d97706/ffffff?text=DM', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
            ['id' => 8, 'type' => 'follow', 'title' => 'MusicFan_KE started following you', 'body' => null, 'is_read' => 1, 'actor_name' => 'MusicFan_KE', 'actor_username' => 'musicfan_ke', 'actor_avatar' => 'https://placehold.co/40x40/06b6d4/ffffff?text=MF', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days'))],
            ['id' => 9, 'type' => 'milestone', 'title' => '🎉 10K Followers!', 'body' => 'Congratulations! You reached 10,000 followers on DTTube.', 'is_read' => 1, 'actor_name' => 'DTTube', 'actor_username' => 'dttube', 'actor_avatar' => 'https://placehold.co/40x40/4f46e5/ffffff?text=DT', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))],
            ['id' => 10, 'type' => 'system', 'title' => 'New monetization features available', 'body' => 'Enable tips and subscriptions on your content to start earning.', 'is_read' => 1, 'actor_name' => 'DTTube', 'actor_username' => 'dttube', 'actor_avatar' => 'https://placehold.co/40x40/4f46e5/ffffff?text=DT', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 week'))],
        ];
    }

    protected function fallbackReels(): array
    {
        return [
            ['id' => 1, 'title' => 'Dance Challenge #Kukua', 'creator_name' => 'ZaraKe', 'username' => 'zarake', 'creator_avatar' => 'https://placehold.co/48x48/6d28d9/ffffff?text=ZK', 'is_verified' => 1, 'thumbnail' => 'https://placehold.co/300x500/6d28d9/ffffff?text=Reel+1', 'views' => 2450000, 'duration' => 30, 'song_name' => 'Kukua Beat - DJ MixMaster'],
        ];
    }

    protected function fallbackVideos(): array
    {
        return [
            ['id' => 1, 'title' => 'Building a Startup in Africa', 'creator_name' => 'ZaraKe', 'username' => 'zarake', 'creator_avatar' => 'https://placehold.co/48x48/6d28d9/ffffff?text=ZK', 'is_verified' => 1, 'thumbnail' => 'https://placehold.co/400x225/6d28d9/ffffff?text=Video+1', 'views' => 1200000, 'duration' => 2720],
        ];
    }

    protected function fallbackCreators(): array
    {
        return [
            ['id' => 2, 'name' => 'Zara Ke', 'username' => 'zarake', 'avatar' => 'https://placehold.co/100x100/6d28d9/ffffff?text=ZK', 'is_verified' => 1, 'follower_count' => 2400000],
        ];
    }

    protected function fallbackLivestreams(): array
    {
        return [
            ['id' => 1, 'title' => 'Late Night Music Session', 'creator_name' => 'ZaraKe', 'username' => 'zarake', 'creator_avatar' => 'https://placehold.co/48x48/6d28d9/ffffff?text=ZK', 'viewers' => 4200, 'thumbnail' => 'https://placehold.co/400x225/d97706/ffffff?text=LIVE+1'],
        ];
    }

    protected function fallbackPosts(): array
    {
        return [
            ['id' => 1, 'content' => 'Just dropped a new dance challenge! 🔥💃', 'creator_name' => 'ZaraKe', 'username' => 'zarake', 'creator_avatar' => 'https://placehold.co/48x48/6d28d9/ffffff?text=ZK', 'is_verified' => 1, 'image_url' => 'https://placehold.co/600x400/6d28d9/ffffff?text=Post+1', 'likes' => 12400, 'comments_count' => 843, 'shares' => 2100, 'created_at' => date('Y-m-d H:i:s')],
        ];
    }
}
