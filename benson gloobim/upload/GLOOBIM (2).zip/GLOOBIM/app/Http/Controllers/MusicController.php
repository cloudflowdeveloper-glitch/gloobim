<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class MusicController extends Controller
{
    public function index(): Response
    {
        return $this->view('music.index', [
            'trending' => $this->getTrending(),
            'playlists' => $this->getPlaylists(),
            'genres' => $this->getGenres(),
            'recent' => $this->getRecent(),
        ]);
    }

    protected function getTrending(): array
    {
        try {
            return Database::query(
                "SELECT id, title, artist_name, artist_avatar, cover_url, duration, plays, is_verified
                 FROM music_tracks WHERE status = 'published'
                 ORDER BY plays DESC LIMIT 10"
            );
        } catch (\Exception $e) {
            return $this->fallbackTrending();
        }
    }

    protected function getPlaylists(): array
    {
        try {
            return Database::query(
                "SELECT id, name, description, cover_url, track_count, author_name
                 FROM music_playlists ORDER BY track_count DESC LIMIT 6"
            );
        } catch (\Exception $e) {
            return $this->fallbackPlaylists();
        }
    }

    protected function getGenres(): array
    {
        try {
            return Database::query("SELECT id, name, color, icon, track_count FROM music_genres ORDER BY track_count DESC LIMIT 8");
        } catch (\Exception $e) {
            return $this->fallbackGenres();
        }
    }

    protected function getRecent(): array
    {
        try {
            return Database::query(
                "SELECT id, title, artist_name, artist_avatar, cover_url, duration, plays, is_verified
                 FROM music_tracks WHERE status = 'published'
                 ORDER BY created_at DESC LIMIT 10"
            );
        } catch (\Exception $e) {
            return [];
        }
    }

    protected function fallbackTrending(): array
    {
        return [
            ['id' => 1, 'title' => 'Kukua (Remix)', 'artist_name' => 'Zara Ke', 'artist_avatar' => 'https://picsum.photos/id/50/40/40', 'cover_url' => 'https://picsum.photos/id/50/400/400', 'duration' => 214, 'plays' => 2450000, 'is_verified' => 1],
            ['id' => 2, 'title' => 'Sauti Ya Nairobi', 'artist_name' => 'DJ MixMaster', 'artist_avatar' => 'https://picsum.photos/id/51/40/40', 'cover_url' => 'https://picsum.photos/id/51/400/400', 'duration' => 198, 'plays' => 1850000, 'is_verified' => 1],
            ['id' => 3, 'title' => 'Late Night Vibes', 'artist_name' => 'Neo Soundz', 'artist_avatar' => 'https://picsum.photos/id/52/40/40', 'cover_url' => 'https://placehold.co/400x400/06b6d4/ffffff?text=Late+Night', 'duration' => 247, 'plays' => 1200000, 'is_verified' => 1],
            ['id' => 4, 'title' => 'African Dream', 'artist_name' => 'Kilele', 'artist_avatar' => 'https://placehold.co/40x40/ec4899/ffffff?text=KL', 'cover_url' => 'https://placehold.co/400x400/ec4899/ffffff?text=African+Dream', 'duration' => 232, 'plays' => 980000, 'is_verified' => 0],
            ['id' => 5, 'title' => 'Sherehe', 'artist_name' => 'Fiesta Band', 'artist_avatar' => 'https://placehold.co/40x40/10b981/ffffff?text=FB', 'cover_url' => 'https://picsum.photos/id/54/400/400', 'duration' => 189, 'plays' => 890000, 'is_verified' => 1],
        ];
    }

    protected function fallbackPlaylists(): array
    {
        return [
            ['id' => 1, 'name' => 'African Heat', 'description' => 'Hottest African tracks right now', 'cover_url' => 'https://placehold.co/200x200/7c3aed/ffffff?text=African+Heat', 'track_count' => 45, 'author_name' => 'DTTube Music'],
            ['id' => 2, 'name' => 'Chill Vibes', 'description' => 'Relax and unwind', 'cover_url' => 'https://placehold.co/200x200/06b6d4/ffffff?text=Chill+Vibes', 'track_count' => 32, 'author_name' => 'Zara Ke'],
            ['id' => 3, 'name' => 'Workout Energy', 'description' => 'High energy for your workout', 'cover_url' => 'https://placehold.co/200x200/d97706/ffffff?text=Workout', 'track_count' => 28, 'author_name' => 'DTTube Music'],
            ['id' => 4, 'name' => 'Karaoke Classics', 'description' => 'Sing along favorites', 'cover_url' => 'https://placehold.co/200x200/ec4899/ffffff?text=Karaoke', 'track_count' => 50, 'author_name' => 'DTTube Music'],
            ['id' => 5, 'name' => 'New Releases KE', 'description' => 'Fresh from Kenya', 'cover_url' => 'https://placehold.co/200x200/10b981/ffffff?text=New+KE', 'track_count' => 18, 'author_name' => 'Curated'],
            ['id' => 6, 'name' => 'Bongo Flava Mix', 'description' => 'Best of Bongo Flava', 'cover_url' => 'https://placehold.co/200x200/f59e0b/ffffff?text=Bongo', 'track_count' => 38, 'author_name' => 'DTTube Music'],
        ];
    }

    protected function fallbackGenres(): array
    {
        return [
            ['id' => 1, 'name' => 'Afrobeat', 'color' => 'from-orange-500 to-red-500', 'icon' => 'music_note', 'track_count' => 1240],
            ['id' => 2, 'name' => 'Bongo Flava', 'color' => 'from-green-500 to-emerald-500', 'icon' => 'music_note', 'track_count' => 890],
            ['id' => 3, 'name' => 'Hip Hop', 'color' => 'from-purple-500 to-violet-500', 'icon' => 'music_note', 'track_count' => 2100],
            ['id' => 4, 'name' => 'RnB', 'color' => 'from-pink-500 to-rose-500', 'icon' => 'music_note', 'track_count' => 1560],
            ['id' => 5, 'name' => 'Gospel', 'color' => 'from-blue-500 to-cyan-500', 'icon' => 'music_note', 'track_count' => 670],
            ['id' => 6, 'name' => 'Dancehall', 'color' => 'from-yellow-500 to-amber-500', 'icon' => 'music_note', 'track_count' => 780],
            ['id' => 7, 'name' => 'Traditional', 'color' => 'from-amber-500 to-orange-500', 'icon' => 'music_note', 'track_count' => 340],
            ['id' => 8, 'name' => 'Pop', 'color' => 'from-sky-500 to-indigo-500', 'icon' => 'music_note', 'track_count' => 1900],
        ];
    }
}
