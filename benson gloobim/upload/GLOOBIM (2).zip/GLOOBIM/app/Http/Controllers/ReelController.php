<?php

namespace App\Http\Controllers;

use Core\Controller;
use Core\Response;
use Core\Database;

class ReelController extends Controller
{
    public function index(): Response
    {
        try {
            $reels = Database::query(
                "SELECT r.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM reels r
                 INNER JOIN users u ON r.user_id = u.id
                 WHERE r.status = 'published'
                 ORDER BY r.created_at DESC"
            );
        } catch (\Exception $e) {
            $reels = [];
        }

        if (empty($reels)) {
            $reels = [
                ['id' => 1, 'title' => 'Dance Challenge #Kukua', 'description' => 'Can you keep up with the Kukua challenge? 🔥💃', 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'thumbnail' => 'https://picsum.photos/id/20/300/500', 'views' => 2450000, 'likes' => 24500, 'comments_count' => 1800, 'shares' => 5200, 'duration' => 30, 'song_name' => 'Kukua Beat - DJ MixMaster'],
                ['id' => 2, 'title' => 'Cooking Jollof Rice', 'description' => 'My secret recipe revealed! 🍚', 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'thumbnail' => 'https://picsum.photos/id/21/300/500', 'views' => 1800000, 'likes' => 18900, 'comments_count' => 3200, 'shares' => 8100, 'duration' => 45, 'song_name' => 'Afro Kitchen Vibes - BeatMaker'],
                ['id' => 3, 'title' => 'Nairobi Night Vibes', 'description' => 'Night out in the city 🌃', 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'thumbnail' => 'https://picsum.photos/id/22/300/500', 'views' => 980000, 'likes' => 9800, 'comments_count' => 560, 'shares' => 1900, 'duration' => 22, 'song_name' => 'Original Sound - ZaraKe'],
                ['id' => 4, 'title' => 'AI Art is Crazy', 'description' => 'Watch what AI created in 30 seconds 🤖', 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'thumbnail' => 'https://picsum.photos/id/23/300/500', 'views' => 3100000, 'likes' => 31200, 'comments_count' => 5600, 'shares' => 12400, 'duration' => 58, 'song_name' => 'Digital Dreams - SynthWave'],
                ['id' => 5, 'title' => 'Afrobeats Studio Session', 'description' => 'New track dropping this Friday 🎧🔥', 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'thumbnail' => 'https://picsum.photos/id/24/300/500', 'views' => 1200000, 'likes' => 12100, 'comments_count' => 890, 'shares' => 3400, 'duration' => 35, 'song_name' => 'Afro Drop (Preview) - BeatMaker'],
            ];
        }

        return $this->view('reels.index', ['reels' => $reels, 'gifts' => $this->getGifts()]);
    }

    protected function getGifts(): array
    {
        try {
            return Database::query(
                "SELECT id, name, description, icon, image_url, price_usd, color_class, is_animated FROM stream_gifts WHERE is_active = 1 ORDER BY sort_order ASC"
            );
        } catch (\Exception $e) {
            return [];
        }
    }

    public function create(): Response
    {
        return $this->view('reels.create');
    }

    public function store(): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $title = trim($input['title'] ?? '');

        if (empty($title)) {
            return $this->json(['error' => 'Title is required'], 422);
        }

        try {
            $reelId = Database::insert('reels', [
                'user_id' => $user['id'],
                'title' => $title,
                'description' => trim($input['description'] ?? ''),
                'thumbnail' => $input['thumbnail'] ?? null,
                'video_url' => $input['video_url'] ?? null,
                'duration' => (int)($input['duration'] ?? 0),
                'song_name' => $input['song_name'] ?? null,
                'category' => $input['category'] ?? null,
                'status' => 'published',
                'published_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->json(['message' => 'Reel created successfully', 'reel_id' => $reelId], 201);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function show($id): Response
    {
        $reel = null;
        try {
            $reels = Database::query(
                "SELECT r.*, u.username, u.name AS creator_name, u.avatar AS creator_avatar, u.is_verified
                 FROM reels r
                 INNER JOIN users u ON r.user_id = u.id
                 WHERE r.id = ? AND r.status = 'published'
                 LIMIT 1",
                [$id]
            );
            $reel = $reels[0] ?? null;
        } catch (\Exception $e) {
            $reel = null;
        }

        if (!$reel) {
            return $this->redirect('/reels');
        }

        return $this->view('reels.show', [
            'reel' => $reel,
            'comments' => $this->getComments($id),
            'gifts' => $this->getGifts(),
        ]);
    }

    public function edit($id): Response
    {
        return $this->view('reels.edit', ['id' => $id]);
    }

    public function update($id): Response
    {
        return $this->json(['message' => 'Reel updated successfully']);
    }

    public function destroy($id): Response
    {
        try {
            Database::execute("UPDATE reels SET status = 'deleted' WHERE id = ?", [$id]);
            return $this->json(['message' => 'Reel deleted successfully']);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function like($id): Response
    {
        try {
            Database::execute("UPDATE reels SET likes = COALESCE(likes, 0) + 1 WHERE id = ?", [$id]);
            $reel = Database::query("SELECT likes FROM reels WHERE id = ?", [$id]);
            return $this->json(['message' => 'Liked', 'likes' => $reel[0]['likes'] ?? 0]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function comment($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Unauthenticated'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $body = trim($input['body'] ?? '');

        if (empty($body)) {
            return $this->json(['error' => 'Comment body is required'], 422);
        }

        try {
            Database::insert('comments', [
                'user_id' => $user['id'],
                'commentable_type' => 'reel',
                'commentable_id' => $id,
                'body' => $body,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            Database::execute("UPDATE reels SET comments_count = COALESCE(comments_count, 0) + 1 WHERE id = ?", [$id]);

            return $this->json([
                'message' => 'Comment added',
                'user_name' => $user['name'],
                'user_avatar' => $user['avatar'] ?? null,
            ]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function share($id): Response
    {
        try {
            Database::execute("UPDATE reels SET shares = COALESCE(shares, 0) + 1 WHERE id = ?", [$id]);
            return $this->json(['message' => 'Shared', 'reel_id' => $id]);
        } catch (\Exception $e) {
            return $this->json(['error' => $e->getMessage()], 500);
        }
    }

    public function sendGift($id): Response
    {
        $user = \Core\Auth::user();
        if (!$user) {
            return $this->json(['error' => 'Login required'], 401);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $giftId = (int)($input['gift_id'] ?? 0);

        if ($giftId <= 0) {
            return $this->json(['error' => 'Invalid gift'], 422);
        }

        try {
            $gifts = Database::query("SELECT id, name, price_usd FROM stream_gifts WHERE id = ? AND is_active = 1", [$giftId]);
            if (empty($gifts)) {
                return $this->json(['error' => 'Gift not found'], 404);
            }
            $gift = $gifts[0];
            $priceUsd = (float)$gift['price_usd'];

            $wallets = Database::query("SELECT id, balance, currency FROM wallets WHERE user_id = ?", [$user['id']]);
            if (empty($wallets) || (float)$wallets[0]['balance'] < $priceUsd) {
                return $this->json(['error' => 'Insufficient balance'], 422);
            }
            $wallet = $wallets[0];

            Database::execute(
                "UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND balance >= ?",
                [$priceUsd, $user['id'], $priceUsd]
            );

            Database::insert('wallet_transactions', [
                'wallet_id' => $wallet['id'],
                'type' => 'gift_sent',
                'amount' => -$priceUsd,
                'currency' => $wallet['currency'],
                'description' => 'Sent gift "' . $gift['name'] . '" on reel #' . $id,
                'status' => 'completed',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->json(['message' => 'Gift sent!', 'gift' => $gift['name']]);
        } catch (\Exception $e) {
            return $this->json(['error' => 'Failed to send gift: ' . $e->getMessage()], 500);
        }
    }

    protected function getComments($reelId): array
    {
        try {
            return Database::query(
                "SELECT c.*, u.username, u.name AS commenter_name, u.avatar AS commenter_avatar
                 FROM comments c
                 INNER JOIN users u ON c.user_id = u.id
                 WHERE c.commentable_type = 'reel' AND c.commentable_id = ?
                 ORDER BY c.created_at DESC
                 LIMIT 20",
                [$reelId]
            );
        } catch (\Exception $e) {
            return [];
        }
    }
}
