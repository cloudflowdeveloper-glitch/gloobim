<?php
$h = file_get_contents('http://localhost:8000/livestream/1');
echo "Has stream highlighted: " . (preg_match('/href="\/livestream"[^>]*text-brand-400/', $h) ? 'YES' : 'NO') . "\n";
echo "Has glass hidden CSS: " . (str_contains($h, '.glass, .glass-bottom') ? 'STILL HAS' : 'REMOVED') . "\n";
echo "Nav visible: " . (str_contains($h, 'class="glass fixed top-0') ? 'YES' : 'NO') . "\n";
echo "Bottom nav visible: " . (str_contains($h, 'glass-bottom fixed bottom-0') ? 'YES' : 'NO') . "\n";
