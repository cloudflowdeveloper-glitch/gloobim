USE `dttube`;

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `avatar`, `bio`, `role`, `provider`, `provider_id`, `email_verified_at`, `is_verified`, `created_at`, `updated_at`) VALUES
(1, 'DTTube Admin', 'admin', 'admin@dttube.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://placehold.co/100x100/e11d48/ffffff?text=AD', 'Platform administrator', 'admin', NULL, NULL, NOW(), 1, NOW(), NOW()),
(2, 'Zara Ke', 'zarake', 'zarake@dttube.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'https://placehold.co/100x100/6d28d9/ffffff?text=ZK', 'Dancer & content creator from Nairobi 💃🔥', 'creator', NULL, NULL, NOW(), 1, NOW(), NOW());

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `currency`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 0.00, 'KES', 1, NOW(), NOW()),
(2, 2, 15000.00, 'KES', 1, NOW(), NOW());

INSERT INTO `followers` (`follower_id`, `following_id`, `created_at`) VALUES
(1, 2, NOW());

INSERT INTO `reels` (`id`, `user_id`, `title`, `description`, `thumbnail`, `video_url`, `duration`, `views`, `likes`, `comments_count`, `shares`, `song_name`, `category`, `status`, `is_featured`, `viral_score`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'Dance Challenge #Kukua', 'Can you keep up with the Kukua challenge? 🔥💃', 'https://placehold.co/300x500/6d28d9/ffffff?text=Reel+1', '/uploads/reels/reel1.mp4', 30, 2450000, 24500, 1800, 5200, 'Kukua Beat - DJ MixMaster', 'Dance', 'published', 1, 87.5, NOW(), NOW(), NOW()),
(2, 2, 'Cooking Jollof Rice', 'My secret recipe revealed! 🍚', 'https://placehold.co/300x500/dc2626/ffffff?text=Reel+2', '/uploads/reels/reel2.mp4', 45, 1800000, 18900, 3200, 8100, 'Afro Kitchen Vibes - BeatMaker', 'Food', 'published', 0, 72.3, NOW(), NOW(), NOW()),
(3, 2, 'Nairobi Night Vibes', 'Night out in the city 🌃', 'https://placehold.co/300x500/059669/ffffff?text=Reel+3', '/uploads/reels/reel3.mp4', 22, 980000, 9800, 560, 1900, 'Original Sound - ZaraKe', 'Lifestyle', 'published', 0, 65.1, NOW(), NOW(), NOW()),
(4, 2, 'AI Art is Crazy', 'Watch what AI created in 30 seconds 🤖', 'https://placehold.co/300x500/2563eb/ffffff?text=Reel+4', '/uploads/reels/reel4.mp4', 58, 3100000, 31200, 5600, 12400, 'Digital Dreams - SynthWave', 'Tech', 'published', 1, 91.2, NOW(), NOW(), NOW()),
(5, 2, 'Afrobeats Studio Session', 'New track dropping this Friday 🎧🔥', 'https://placehold.co/300x500/d97706/ffffff?text=Reel+5', '/uploads/reels/reel5.mp4', 35, 1200000, 12100, 890, 3400, 'Afro Drop (Preview) - BeatMaker', 'Music', 'published', 0, 68.7, NOW(), NOW(), NOW()),
(6, 2, 'Comedy: African Mom', 'When your African mom finds your wallet balance 😂💰', 'https://placehold.co/300x500/e11d48/ffffff?text=Reel+6', '/uploads/reels/reel6.mp4', 40, 5600000, 56300, 8900, 24100, 'Original Sound - ZaraKe', 'Comedy', 'published', 1, 95.8, NOW(), NOW(), NOW()),
(7, 2, 'Skincare Routine', 'The routine that ACTUALLY works ✨', 'https://placehold.co/300x500/7c3aed/ffffff?text=Reel+7', '/uploads/reels/reel7.mp4', 55, 870000, 8700, 421, 1900, 'Soft Vibes - ChillBeats', 'Beauty', 'published', 0, 54.2, NOW(), NOW(), NOW()),
(8, 2, 'Football Skills', 'Check these moves ⚽', 'https://placehold.co/300x500/0891b2/ffffff?text=Reel+8', '/uploads/reels/reel8.mp4', 28, 4200000, 42000, 3400, 11200, 'Goal Mix - DJ Sports', 'Sports', 'published', 0, 82.4, NOW(), NOW(), NOW());

INSERT INTO `videos` (`id`, `user_id`, `title`, `description`, `thumbnail`, `video_url`, `duration`, `views`, `likes`, `comments_count`, `shares`, `category`, `status`, `is_featured`, `is_monetized`, `viral_score`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'Building a Startup in Africa - Full Documentary', 'The complete journey of building a tech startup from Nairobi', 'https://placehold.co/400x225/6d28d9/ffffff?text=Video+1', '/uploads/videos/video1.mp4', 2720, 1200000, 45000, 2300, 8900, 'Tech', 'published', 1, 1, 78.5, NOW(), NOW(), NOW()),
(2, 2, 'How to Make Money as a Creator in 2025', 'Complete guide to monetizing your content', 'https://placehold.co/400x225/dc2626/ffffff?text=Video+2', '/uploads/videos/video2.mp4', 1335, 890000, 32000, 1800, 6700, 'Business', 'published', 1, 1, 73.2, NOW(), NOW(), NOW()),
(3, 2, 'Lagos to Nairobi: Road Trip Vlog', 'Cross-country adventure through East and West Africa', 'https://placehold.co/400x225/059669/ffffff?text=Video+3', '/uploads/videos/video3.mp4', 1905, 670000, 21000, 980, 4500, 'Travel', 'published', 0, 1, 61.8, NOW(), NOW(), NOW()),
(4, 2, 'Learn Flutter in 2 Hours - Complete Course', 'Full Flutter development course for beginners', 'https://placehold.co/400x225/2563eb/ffffff?text=Video+4', '/uploads/videos/video4.mp4', 7290, 2100000, 89000, 5600, 23000, 'Education', 'published', 1, 1, 92.1, NOW(), NOW(), NOW()),
(5, 2, 'Best Afrobeat Mix 2025', 'Non-stop afrobeats mix for your playlist', 'https://placehold.co/400x225/d97706/ffffff?text=Video+5', '/uploads/videos/video5.mp4', 4500, 3500000, 120000, 7800, 34000, 'Music', 'published', 1, 1, 96.3, NOW(), NOW(), NOW()),
(6, 2, 'Street Food Tour: Accra Edition', 'Trying the best street food in Accra, Ghana', 'https://placehold.co/400x225/e11d48/ffffff?text=Video+6', '/uploads/videos/video6.mp4', 1110, 450000, 15000, 670, 2100, 'Food', 'published', 0, 1, 58.4, NOW(), NOW(), NOW());

INSERT INTO `posts` (`id`, `user_id`, `content`, `image_url`, `likes`, `comments_count`, `shares`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'Just dropped a new dance challenge! Who can keep up? 🔥💃 #KukuaChallenge #DTTube', 'https://placehold.co/600x400/6d28d9/ffffff?text=Post+1', 12400, 843, 2100, 'published', NOW(), NOW()),
(2, 2, 'New afrobeats pack dropping this Friday on my creator store! 🎧🔥 Pre-order now', 'https://placehold.co/600x300/d97706/ffffff?text=Post+2', 3200, 198, 567, 'published', NOW(), NOW()),
(3, 2, 'When your African mom discovers you have a wallet balance 😂💰 #Comedy #Relatable', NULL, 24300, 3800, 8900, 'published', NOW(), NOW());

INSERT INTO `livestreams` (`id`, `user_id`, `title`, `description`, `thumbnail`, `stream_key`, `stream_url`, `viewers`, `peak_viewers`, `likes`, `total_gifts`, `gift_earnings`, `status`, `started_at`, `ended_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'Late Night Music Session', 'Live music and chat 🎵', 'https://placehold.co/400x225/d97706/ffffff?text=LIVE+1', 'seed_sk_1', '/livestream/1', 4200, 8500, 234, 56, 4250.00, 'live', NOW(), NULL, NOW(), NOW()),
(2, 2, 'Q&A: Starting Your Creator Journey', 'Ask me anything about content creation', 'https://placehold.co/400x225/6d28d9/ffffff?text=LIVE+2', 'seed_sk_2', '/livestream/2', 2800, 5100, 89, 23, 1820.00, 'live', NOW(), NULL, NOW(), NOW()),
(3, 2, 'Weekend Vibes: Acoustic Session', 'Unplugged acoustic performances', 'https://placehold.co/400x225/059669/ffffff?text=Scheduled+1', 'seed_sk_3', '/livestream/3', 0, 0, 0, 0, 0.00, 'scheduled', DATE_ADD(NOW(), INTERVAL 2 DAY), NULL, NOW(), NOW()),
(4, 2, 'Creator Workshop: Editing Tips', 'Learn video editing like a pro', 'https://placehold.co/400x225/2563eb/ffffff?text=Scheduled+2', 'seed_sk_4', '/livestream/4', 0, 0, 0, 0, 0.00, 'scheduled', DATE_ADD(NOW(), INTERVAL 1 DAY), NULL, NOW(), NOW()),
(5, 1, 'DTTube Town Hall', 'Platform updates and roadmap discussion', 'https://placehold.co/400x225/7c3aed/ffffff?text=Past+Stream', 'seed_sk_5', '/livestream/5', 12500, 18200, 567, 89, 8900.00, 'ended', DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_SUB(NOW(), INTERVAL 3 DAY), NOW(), NOW()),
(6, 2, 'Afrobeats Dance Tutorial', 'Learn the hottest dance moves', 'https://placehold.co/400x225/dc2626/ffffff?text=Past+Stream+2', 'seed_sk_6', '/livestream/6', 8900, 12400, 345, 67, 5600.00, 'ended', DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY), NOW(), NOW());

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `body`, `is_read`, `created_at`) VALUES
(1, 1, 'welcome', 'Welcome to DTTube!', 'Your admin account is ready.', 0, NOW()),
(2, 2, 'verification', 'Account Verified!', 'Your creator account has been verified.', 0, NOW());

INSERT INTO `stream_gifts` (`id`, `name`, `icon`, `price_usd`, `color_class`, `is_active`, `sort_order`, `created_at`) VALUES
(1, 'Heart', 'favorite', 0.50, 'text-red-400', 1, 1, NOW()),
(2, 'Fire', 'local_fire_department', 1.00, 'text-orange-400', 1, 2, NOW()),
(3, 'Star', 'star', 2.50, 'text-yellow-400', 1, 3, NOW()),
(4, 'Diamond', 'diamond', 5.00, 'text-cyan-400', 1, 4, NOW()),
(5, 'Crown', 'crown', 10.00, 'text-amber-400', 1, 5, NOW()),
(6, 'Rocket', 'rocket_launch', 20.00, 'text-purple-400', 1, 6, NOW()),
(7, 'Party', 'celebration', 50.00, 'text-pink-400', 1, 7, NOW()),
(8, 'Super', 'bolt', 100.00, 'text-brand-400', 1, 8, NOW());

INSERT INTO `country_currencies` (`country_code`, `country_name`, `currency_code`, `currency_symbol`, `exchange_rate_usd`) VALUES
('US', 'United States', 'USD', '$', 1.000000),
('KE', 'Kenya', 'KES', 'KES', 129.500000),
('NG', 'Nigeria', 'NGN', '₦', 1540.000000),
('GH', 'Ghana', 'GHS', '¢', 14.500000),
('ZA', 'South Africa', 'ZAR', 'R', 18.200000),
('TZ', 'Tanzania', 'TZS', 'TSh', 2580.000000),
('UG', 'Uganda', 'UGX', 'USh', 3700.000000),
('RW', 'Rwanda', 'RWF', 'FRw', 1300.000000),
('ET', 'Ethiopia', 'ETB', 'Br', 55.000000),
('GB', 'United Kingdom', 'GBP', '£', 0.790000),
('EU', 'Europe', 'EUR', '€', 0.920000),
('CA', 'Canada', 'CAD', 'C$', 1.360000),
('AU', 'Australia', 'AUD', 'A$', 1.530000),
('IN', 'India', 'INR', '₹', 83.000000);

INSERT INTO `marketplace_listings` (`id`, `user_id`, `title`, `description`, `price`, `currency`, `image_url`, `category`, `condition`, `location`, `phone`, `views`, `sold`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'iPhone 15 Pro Max 256GB', 'Brand new iPhone 15 Pro Max in Natural Titanium. Box sealed. Bought but never opened. Includes original charger and cable.', 180000.00, 'KES', 'https://placehold.co/400x300/6d28d9/ffffff?text=iPhone+15', 'Electronics', 'new', 'Nairobi, Kenya', '+254712345678', 2340, 0, 'active', DATE_SUB(NOW(), INTERVAL 1 DAY), NOW()),
(2, 2, 'MacBook Air M3 - 16GB RAM', 'Lightly used MacBook Air M3 in perfect condition. 16GB RAM, 256GB SSD. Battery cycle count: 12 only.', 145000.00, 'KES', 'https://placehold.co/400x300/7c3aed/ffffff?text=MacBook+Air', 'Electronics', 'like_new', 'Nairobi, Kenya', '+254712345678', 1870, 0, 'active', DATE_SUB(NOW(), INTERVAL 2 DAY), NOW()),
(3, 2, 'Wireless Studio Headphones', 'Professional noise-cancelling headphones. Used for only 2 weeks. Crystal clear sound quality. Perfect for creators.', 8500.00, 'KES', 'https://placehold.co/400x300/dc2626/ffffff?text=Headphones', 'Electronics', 'good', 'Nairobi, Kenya', '+254712345678', 3120, 0, 'active', DATE_SUB(NOW(), INTERVAL 3 DAY), NOW()),
(4, 2, 'Trendy Streetwear Jacket', 'Limited edition streetwear jacket, size L. Worn once for a photoshoot. High quality material, very comfortable.', 4500.00, 'KES', 'https://placehold.co/400x300/d97706/ffffff?text=Jacket', 'Fashion', 'like_new', 'Nairobi, Kenya', '+254712345678', 890, 1, 'sold', DATE_SUB(NOW(), INTERVAL 5 DAY), NOW()),
(5, 2, 'Vintage Vinyl Collection', 'Collection of 12 afrobeat and jazz vinyl records. Includes Fela Kuti, Miriam Makeba, and more. All in great condition.', 12000.00, 'KES', 'https://placehold.co/400x300/059669/ffffff?text=Vinyl', 'Collectibles', 'good', 'Nairobi, Kenya', '+254712345678', 1560, 0, 'active', DATE_SUB(NOW(), INTERVAL 4 DAY), NOW()),
(6, 2, 'Gaming Console PS5 Digital', 'PS5 Digital Edition. Brand new, still sealed. Bought as a gift but recipient already had one.', 65000.00, 'KES', 'https://placehold.co/400x300/2563eb/ffffff?text=PS5', 'Electronics', 'new', 'Nairobi, Kenya', '+254712345678', 4100, 0, 'active', DATE_SUB(NOW(), INTERVAL 1 DAY), NOW()),
(7, 2, 'Modern Desk Lamp LED', 'Minimalist LED desk lamp with adjustable brightness and color temperature. USB powered, perfect for your setup.', 2500.00, 'KES', 'https://placehold.co/400x300/0891b2/ffffff?text=Lamp', 'Home', 'new', 'Nairobi, Kenya', '+254712345678', 340, 0, 'active', DATE_SUB(NOW(), INTERVAL 6 DAY), NOW()),
(8, 2, 'Handmade Beaded Jewelry Set', 'Beautiful handcrafted beaded necklace and earring set. Made with authentic African beads by local artisans.', 3200.00, 'KES', 'https://placehold.co/400x300/e11d48/ffffff?text=Jewelry', 'Fashion', 'good', 'Nairobi, Kenya', '+254712345678', 670, 0, 'active', DATE_SUB(NOW(), INTERVAL 3 DAY), NOW());

