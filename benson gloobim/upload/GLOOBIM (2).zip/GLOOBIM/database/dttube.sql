CREATE DATABASE IF NOT EXISTS `dttube` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `dttube`;

CREATE TABLE IF NOT EXISTS `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `username` VARCHAR(100) NOT NULL UNIQUE,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `avatar` VARCHAR(500) DEFAULT NULL,
    `bio` TEXT DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `role` ENUM('user','creator','admin','super_admin') DEFAULT 'user',
    `provider` VARCHAR(50) DEFAULT NULL,
    `provider_id` VARCHAR(255) DEFAULT NULL,
    `email_verified_at` DATETIME DEFAULT NULL,
    `phone_verified_at` DATETIME DEFAULT NULL,
    `is_verified` TINYINT(1) DEFAULT 0,
    `is_banned` TINYINT(1) DEFAULT 0,
    `last_login_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_username` (`username`),
    INDEX `idx_users_email` (`email`),
    INDEX `idx_users_provider` (`provider`, `provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `followers` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `follower_id` BIGINT UNSIGNED NOT NULL,
    `following_id` BIGINT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_follow` (`follower_id`, `following_id`),
    INDEX `idx_followers_following` (`following_id`),
    FOREIGN KEY (`follower_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`following_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `videos` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `thumbnail` VARCHAR(500) DEFAULT NULL,
    `video_url` VARCHAR(500) DEFAULT NULL,
    `stream_key` VARCHAR(100) DEFAULT NULL,
    `duration` INT UNSIGNED DEFAULT 0,
    `views` BIGINT UNSIGNED DEFAULT 0,
    `likes` BIGINT UNSIGNED DEFAULT 0,
    `comments_count` BIGINT UNSIGNED DEFAULT 0,
    `shares` BIGINT UNSIGNED DEFAULT 0,
    `category` VARCHAR(100) DEFAULT NULL,
    `tags` JSON DEFAULT NULL,
    `status` ENUM('draft','processing','published','unlisted','private','deleted') DEFAULT 'draft',
    `is_featured` TINYINT(1) DEFAULT 0,
    `is_monetized` TINYINT(1) DEFAULT 0,
    `ai_captions` TEXT DEFAULT NULL,
    `viral_score` FLOAT DEFAULT 0,
    `published_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_videos_user` (`user_id`),
    INDEX `idx_videos_status` (`status`, `published_at`),
    INDEX `idx_videos_views` (`views`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reels` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `thumbnail` VARCHAR(500) DEFAULT NULL,
    `video_url` VARCHAR(500) DEFAULT NULL,
    `duration` INT UNSIGNED DEFAULT 0,
    `views` BIGINT UNSIGNED DEFAULT 0,
    `likes` BIGINT UNSIGNED DEFAULT 0,
    `comments_count` BIGINT UNSIGNED DEFAULT 0,
    `shares` BIGINT UNSIGNED DEFAULT 0,
    `song_name` VARCHAR(255) DEFAULT NULL,
    `song_url` VARCHAR(500) DEFAULT NULL,
    `category` VARCHAR(100) DEFAULT NULL,
    `tags` JSON DEFAULT NULL,
    `status` ENUM('draft','published','deleted') DEFAULT 'draft',
    `is_featured` TINYINT(1) DEFAULT 0,
    `ai_captions` TEXT DEFAULT NULL,
    `viral_score` FLOAT DEFAULT 0,
    `published_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_reels_user` (`user_id`),
    INDEX `idx_reels_status` (`status`, `published_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `posts` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `content` TEXT NOT NULL,
    `image_url` VARCHAR(500) DEFAULT NULL,
    `likes` BIGINT UNSIGNED DEFAULT 0,
    `comments_count` BIGINT UNSIGNED DEFAULT 0,
    `shares` BIGINT UNSIGNED DEFAULT 0,
    `status` ENUM('draft','published','deleted') DEFAULT 'published',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_posts_user` (`user_id`),
    INDEX `idx_posts_status` (`status`, `created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `comments` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `commentable_type` VARCHAR(50) NOT NULL,
    `commentable_id` BIGINT UNSIGNED NOT NULL,
    `parent_id` BIGINT UNSIGNED DEFAULT NULL,
    `body` TEXT NOT NULL,
    `likes` BIGINT UNSIGNED DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_comments_user` (`user_id`),
    INDEX `idx_comments_commentable` (`commentable_type`, `commentable_id`),
    INDEX `idx_comments_parent` (`parent_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `likes` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `likeable_type` VARCHAR(50) NOT NULL,
    `likeable_id` BIGINT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_like` (`user_id`, `likeable_type`, `likeable_id`),
    INDEX `idx_likes_likeable` (`likeable_type`, `likeable_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `wallets` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL UNIQUE,
    `balance` DECIMAL(15,2) DEFAULT 0.00,
    `currency` VARCHAR(10) DEFAULT 'KES',
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_wallets_user` (`user_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `wallet_transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `wallet_id` BIGINT UNSIGNED NOT NULL,
    `type` ENUM('deposit','withdrawal','gift_sent','gift_received','tip','subscription','earnings','refund','mpesa_deposit','mpesa_withdrawal') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `fee` DECIMAL(15,2) DEFAULT 0.00,
    `status` ENUM('pending','completed','failed','cancelled') DEFAULT 'pending',
    `reference` VARCHAR(255) DEFAULT NULL,
    `mpesa_checkout_id` VARCHAR(255) DEFAULT NULL,
    `mpesa_receipt` VARCHAR(255) DEFAULT NULL,
    `description` VARCHAR(500) DEFAULT NULL,
    `recipient_id` BIGINT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_wt_wallet` (`wallet_id`),
    INDEX `idx_wt_type` (`type`, `status`),
    FOREIGN KEY (`wallet_id`) REFERENCES `wallets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `conversations` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_one` BIGINT UNSIGNED NOT NULL,
    `user_two` BIGINT UNSIGNED NOT NULL,
    `last_message_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_conversation` (`user_one`, `user_two`),
    INDEX `idx_conv_users` (`user_one`, `user_two`),
    FOREIGN KEY (`user_one`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_two`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `messages` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `conversation_id` BIGINT UNSIGNED NOT NULL,
    `sender_id` BIGINT UNSIGNED NOT NULL,
    `body` TEXT NOT NULL,
    `attachment_url` VARCHAR(500) DEFAULT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_messages_conv` (`conversation_id`, `created_at`),
    INDEX `idx_messages_sender` (`sender_id`),
    FOREIGN KEY (`conversation_id`) REFERENCES `conversations`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `livestreams` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `thumbnail` VARCHAR(500) DEFAULT NULL,
    `stream_key` VARCHAR(100) DEFAULT NULL,
    `stream_url` VARCHAR(500) DEFAULT NULL,
    `category` VARCHAR(100) DEFAULT NULL,
    `tags` JSON DEFAULT NULL,
    `viewers` BIGINT UNSIGNED DEFAULT 0,
    `peak_viewers` BIGINT UNSIGNED DEFAULT 0,
    `total_likes` BIGINT UNSIGNED DEFAULT 0,
    `total_shares` BIGINT UNSIGNED DEFAULT 0,
    `total_comments` BIGINT UNSIGNED DEFAULT 0,
    `total_gifts` BIGINT UNSIGNED DEFAULT 0,
    `gift_earnings` DECIMAL(15,2) DEFAULT 0.00,
    `duration_seconds` INT UNSIGNED DEFAULT 0,
    `is_featured` TINYINT(1) DEFAULT 0,
    `is_private` TINYINT(1) DEFAULT 0,
    `access_password` VARCHAR(255) DEFAULT NULL,
    `co_host_id` BIGINT UNSIGNED DEFAULT NULL,
    `raid_target_id` BIGINT UNSIGNED DEFAULT NULL,
    `restricted_to` ENUM('everyone','subscribers','followers') DEFAULT 'everyone',
    `status` ENUM('scheduled','live','ended','cancelled') DEFAULT 'scheduled',
    `started_at` DATETIME DEFAULT NULL,
    `ended_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_livestreams_user` (`user_id`),
    INDEX `idx_livestreams_status` (`status`),
    INDEX `idx_livestreams_category` (`category`, `status`),
    INDEX `idx_livestreams_featured` (`is_featured`, `status`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `subscriptions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `subscriber_id` BIGINT UNSIGNED NOT NULL,
    `creator_id` BIGINT UNSIGNED NOT NULL,
    `plan` ENUM('free','basic','premium','vip') DEFAULT 'free',
    `amount` DECIMAL(15,2) DEFAULT 0.00,
    `currency` VARCHAR(10) DEFAULT 'KES',
    `status` ENUM('active','cancelled','expired') DEFAULT 'active',
    `starts_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `expires_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_subscription` (`subscriber_id`, `creator_id`),
    INDEX `idx_subs_creator` (`creator_id`, `status`),
    FOREIGN KEY (`subscriber_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`creator_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) DEFAULT NULL,
    `body` TEXT DEFAULT NULL,
    `data` JSON DEFAULT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_notifs_user` (`user_id`, `is_read`),
    INDEX `idx_notifs_type` (`type`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `marketplace_listings` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) DEFAULT 'KES',
    `image_url` VARCHAR(500) DEFAULT NULL,
    `category` VARCHAR(100) DEFAULT NULL,
    `condition` ENUM('new','like_new','good','fair','used') DEFAULT 'good',
    `location` VARCHAR(255) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `views` BIGINT UNSIGNED DEFAULT 0,
    `sold` TINYINT(1) DEFAULT 0,
    `status` ENUM('active','sold','deleted') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_ml_user` (`user_id`),
    INDEX `idx_ml_category` (`category`, `status`),
    INDEX `idx_ml_status` (`status`, `created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reports` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `reporter_id` BIGINT UNSIGNED NOT NULL,
    `reportable_type` VARCHAR(50) NOT NULL,
    `reportable_id` BIGINT UNSIGNED NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `status` ENUM('pending','reviewed','resolved','dismissed') DEFAULT 'pending',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_reports_status` (`status`),
    FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ads` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `advertiser_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `image_url` VARCHAR(500) DEFAULT NULL,
    `target_url` VARCHAR(500) DEFAULT NULL,
    `type` ENUM('banner','video','native','sponsored') DEFAULT 'banner',
    `placement` ENUM('feed','reel','video','sidebar','story') DEFAULT 'feed',
    `impressions` BIGINT UNSIGNED DEFAULT 0,
    `clicks` BIGINT UNSIGNED DEFAULT 0,
    `budget` DECIMAL(15,2) DEFAULT 0.00,
    `spent` DECIMAL(15,2) DEFAULT 0.00,
    `status` ENUM('draft','active','paused','ended') DEFAULT 'draft',
    `starts_at` DATETIME DEFAULT NULL,
    `ends_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_ads_status` (`status`, `placement`),
    FOREIGN KEY (`advertiser_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `migrations` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `migration` VARCHAR(255) NOT NULL,
    `batch` INT UNSIGNED DEFAULT 1,
    `ran_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stream_gifts` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `icon` VARCHAR(50) NOT NULL DEFAULT 'card_giftcard',
    `price_usd` DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    `color_class` VARCHAR(50) NOT NULL DEFAULT 'text-amber-400',
    `is_active` TINYINT(1) DEFAULT 1,
    `sort_order` INT UNSIGNED DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `country_currencies` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `country_code` VARCHAR(5) NOT NULL UNIQUE,
    `country_name` VARCHAR(100) NOT NULL,
    `currency_code` VARCHAR(10) NOT NULL,
    `currency_symbol` VARCHAR(10) DEFAULT NULL,
    `exchange_rate_usd` DECIMAL(15,6) NOT NULL DEFAULT 1.000000,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_cc_country` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stream_signals` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `stream_id` BIGINT UNSIGNED NOT NULL,
    `sender` VARCHAR(20) NOT NULL DEFAULT 'host',
    `viewer_sid` VARCHAR(100) DEFAULT NULL,
    `type` VARCHAR(20) NOT NULL,
    `data` TEXT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_signals_stream` (`stream_id`),
    INDEX `idx_signals_viewer` (`stream_id`, `viewer_sid`),
    FOREIGN KEY (`stream_id`) REFERENCES `livestreams`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stream_viewers` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `stream_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED DEFAULT NULL,
    `viewer_sid` VARCHAR(100) DEFAULT NULL,
    `username` VARCHAR(100) DEFAULT NULL,
    `avatar` VARCHAR(500) DEFAULT NULL,
    `is_moderator` TINYINT(1) DEFAULT 0,
    `is_muted` TINYINT(1) DEFAULT 0,
    `is_banned` TINYINT(1) DEFAULT 0,
    `last_heartbeat` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `joined_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sv_stream` (`stream_id`),
    INDEX `idx_sv_user` (`user_id`),
    FOREIGN KEY (`stream_id`) REFERENCES `livestreams`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `stream_reports` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `stream_id` BIGINT UNSIGNED NOT NULL,
    `reporter_id` BIGINT UNSIGNED DEFAULT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `status` ENUM('pending','reviewed','resolved','dismissed') DEFAULT 'pending',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_sr_stream` (`stream_id`),
    INDEX `idx_sr_status` (`status`),
    FOREIGN KEY (`stream_id`) REFERENCES `livestreams`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `saved_streams` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `stream_id` BIGINT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_saved` (`user_id`, `stream_id`),
    INDEX `idx_saved_user` (`user_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`stream_id`) REFERENCES `livestreams`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `market_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `type` ENUM('digital','service') NOT NULL DEFAULT 'digital',
    `price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) DEFAULT 'KES',
    `file_url` VARCHAR(500) DEFAULT NULL,
    `preview_url` VARCHAR(500) DEFAULT NULL,
    `thumbnail` VARCHAR(500) DEFAULT NULL,
    `category` VARCHAR(100) DEFAULT NULL,
    `tags` JSON DEFAULT NULL,
    `delivery_time` VARCHAR(50) DEFAULT NULL,
    `requirements` TEXT DEFAULT NULL,
    `views` BIGINT UNSIGNED DEFAULT 0,
    `downloads` BIGINT UNSIGNED DEFAULT 0,
    `orders_count` BIGINT UNSIGNED DEFAULT 0,
    `rating` DECIMAL(3,2) DEFAULT 0.00,
    `status` ENUM('active','inactive','deleted') DEFAULT 'active',
    `is_featured` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_mi_user` (`user_id`),
    INDEX `idx_mi_category` (`category`, `status`),
    INDEX `idx_mi_type` (`type`, `status`),
    INDEX `idx_mi_status` (`status`, `created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
