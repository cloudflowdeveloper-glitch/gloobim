<?php $title = ($data['profileUser']['name'] ?? 'Profile') . ' - DTTube'; ?>
<?php
$profileUser = $data['profileUser'] ?? null;
$posts = $data['posts'] ?? [];
$videos = $data['videos'] ?? [];
$isOwnProfile = $data['isOwnProfile'] ?? false;

$name = $profileUser['name'] ?? 'User';
$username = $profileUser['username'] ?? 'user';
$avatar = $profileUser['avatar'] ?? 'https://placehold.co/80x80/6d28d9/ffffff?text=' . urlencode(substr($name, 0, 2));
$bio = $profileUser['bio'] ?? '';
$isVerified = !empty($profileUser['is_verified']);
$followersCount = 0;
$followingCount = 0;
$postsCount = count($posts);
$videosCount = count($videos);

if ($profileUser) {
    try {
        $followersCount = (int)(\Core\Database::queryOne("SELECT COUNT(*) AS c FROM followers WHERE following_id = ?", [$profileUser['id']])['c'] ?? 0);
        $followingCount = (int)(\Core\Database::queryOne("SELECT COUNT(*) AS c FROM followers WHERE follower_id = ?", [$profileUser['id']])['c'] ?? 0);
        $postsCount = (int)(\Core\Database::queryOne("SELECT COUNT(*) AS c FROM posts WHERE user_id = ? AND status = 'published'", [$profileUser['id']])['c'] ?? 0);
        $videosCount = (int)(\Core\Database::queryOne("SELECT COUNT(*) AS c FROM videos WHERE user_id = ? AND status = 'published'", [$profileUser['id']])['c'] ?? 0);
    } catch (\Exception $e) {}
}
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center gap-3 mb-5">
        <a href="/menu" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <h1 class="font-display text-lg font-bold text-white">Profile</h1>
        <?php if ($isOwnProfile): ?>
        <a href="/settings" class="ml-auto w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-lg">settings</span>
        </a>
        <?php endif; ?>
    </div>

    <?php if ($profileUser): ?>
    <div class="text-center mb-5">
        <div class="relative inline-block mb-3">
            <img src="<?= $avatar ?>" alt="<?= htmlspecialchars($name) ?>" class="w-20 h-20 rounded-full object-cover border-3 border-brand-500/40">
            <?php if ($isVerified): ?>
            <span class="absolute -bottom-1 -right-1 material-icons-round text-brand-400 text-xl bg-surface-50 rounded-full">verified</span>
            <?php endif; ?>
        </div>
        <h2 class="text-white text-lg font-bold"><?= htmlspecialchars($name) ?></h2>
        <div class="flex items-center justify-center gap-1.5">
            <span class="text-zinc-500 text-xs">@<?= htmlspecialchars($username) ?></span>
            <?php if ($isVerified): ?>
            <span class="px-2 py-0.5 rounded-full bg-brand-500/20 text-brand-400 text-[9px] font-medium">Verified</span>
            <?php endif; ?>
        </div>
        <?php if ($bio): ?>
        <p class="text-zinc-400 text-xs mt-2 max-w-xs mx-auto"><?= htmlspecialchars($bio) ?></p>
        <?php endif; ?>
    </div>

    <div class="flex items-center justify-center gap-6 mb-5">
        <div class="text-center">
            <span class="text-white text-base font-bold"><?= number_format($postsCount) ?></span>
            <span class="text-zinc-500 text-[9px] block">Posts</span>
        </div>
        <div class="w-px h-8 bg-surface-400/30"></div>
        <div class="text-center">
            <span class="text-white text-base font-bold"><?= number_format($followersCount) ?></span>
            <span class="text-zinc-500 text-[9px] block">Followers</span>
        </div>
        <div class="w-px h-8 bg-surface-400/30"></div>
        <div class="text-center">
            <span class="text-white text-base font-bold"><?= number_format($followingCount) ?></span>
            <span class="text-zinc-500 text-[9px] block">Following</span>
        </div>
    </div>

    <?php if (!$isOwnProfile): ?>
    <div class="flex gap-2 mb-5">
        <button onclick="followUser(<?= $profileUser['id'] ?>)" class="flex-1 gradient-brand py-2.5 rounded-xl text-white text-sm font-semibold hover:opacity-90 transition-opacity">Follow</button>
        <a href="/messages" class="flex-1 bg-surface-200 py-2.5 rounded-xl text-white text-sm font-semibold hover:bg-surface-300 transition-colors text-center">Message</a>
    </div>
    <?php endif; ?>

    <?php if (!empty($videos)): ?>
    <div class="mb-5">
        <h3 class="text-white text-xs font-bold mb-3">Videos</h3>
        <div class="grid grid-cols-3 gap-2">
            <?php foreach ($videos as $video): ?>
            <a href="/videos/<?= $video['id'] ?>" class="relative group rounded-xl overflow-hidden">
                <img src="<?= $video['thumbnail'] ?? 'https://placehold.co/200x112/3f3f46/ffffff?text=Video' ?>" alt="" class="w-full aspect-video object-cover">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                    <span class="material-icons-round text-white text-2xl opacity-0 group-hover:opacity-100 transition-opacity">play_circle</span>
                </div>
                <div class="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/80 text-white text-[8px] font-medium">
                    <?= formatDuration($video['duration'] ?? 0) ?>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($posts)): ?>
    <div>
        <h3 class="text-white text-xs font-bold mb-3">Posts</h3>
        <div class="space-y-3">
            <?php foreach ($posts as $post): ?>
            <a href="/posts/<?= $post['id'] ?>" class="block bg-surface-100/30 rounded-xl border border-surface-400/10 p-3 hover:border-surface-400/30 transition-all">
                <div class="flex items-center gap-2 mb-2">
                    <img src="<?= $avatar ?>" alt="" class="w-6 h-6 rounded-full">
                    <span class="text-zinc-500 text-[10px]"><?= timeAgo($post['created_at']) ?></span>
                </div>
                <p class="text-zinc-200 text-xs leading-relaxed line-clamp-2"><?= htmlspecialchars($post['content'] ?? '') ?></p>
                <?php if (!empty($post['image_url'])): ?>
                <img src="<?= $post['image_url'] ?>" alt="" class="w-full rounded-lg mt-2 max-h-48 object-cover">
                <?php endif; ?>
                <div class="flex items-center gap-3 mt-2">
                    <span class="text-zinc-500 text-[10px]"><?= formatCount($post['likes'] ?? 0) ?> likes</span>
                    <span class="text-zinc-500 text-[10px]"><?= formatCount($post['comments_count'] ?? 0) ?> comments</span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="text-center py-10 bg-surface-100/30 rounded-2xl border border-surface-400/10">
        <span class="material-icons-round text-zinc-500 text-4xl">person</span>
        <p class="text-zinc-500 text-xs mt-2">No content yet</p>
        <?php if ($isOwnProfile): ?>
        <a href="/posts/create" class="inline-block mt-3 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">Create Post</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="text-center py-16">
        <span class="material-icons-round text-zinc-500 text-5xl">person_off</span>
        <h3 class="text-white font-semibold text-sm mt-3">User not found</h3>
        <p class="text-zinc-500 text-xs mt-1">This user doesn't exist or has been deactivated</p>
        <a href="/" class="inline-block mt-4 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">Go Home</a>
    </div>
    <?php endif; ?>
</div>

<script>
function followUser(userId) {
    fetch('/profile/' + userId + '/follow', {
        method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(r => r.json()).then(d => {
        if (d.message) alert(d.message);
    }).catch(() => {});
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
