<?php $activeTab = 'menu'; $title = 'Analytics - DTTube'; ?>
<?php $d = $data['data'] ?? []; ?>
<style>
    @keyframes barGrow { from { transform: scaleY(0.3); opacity: 0.3; } to { transform: scaleY(1); opacity: 1; } }
    @keyframes fadeSlideUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes pulseGlow { 0%,100% { box-shadow: 0 0 8px rgba(168,85,247,0.2); } 50% { box-shadow: 0 0 20px rgba(168,85,247,0.4); } }
    @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
    .stat-card { animation: fadeSlideUp 0.5s ease-out forwards; opacity: 0; }
    .stat-card:nth-child(1) { animation-delay: 0.05s; }
    .stat-card:nth-child(2) { animation-delay: 0.1s; }
    .stat-card:nth-child(3) { animation-delay: 0.15s; }
    .stat-card:nth-child(4) { animation-delay: 0.2s; }
    .stat-card-small { animation: fadeSlideUp 0.5s ease-out forwards; opacity: 0; }
    .stat-card-small:nth-child(1) { animation-delay: 0.25s; }
    .stat-card-small:nth-child(2) { animation-delay: 0.3s; }
    .stat-card-small:nth-child(3) { animation-delay: 0.35s; }
    .chart-bar { transform-origin: bottom; animation: barGrow 0.6s ease-out forwards; opacity: 0; transition: all 0.3s ease; }
    .chart-bar:hover { filter: brightness(1.3); transform: scaleY(1.05) !important; }
    .chart-container { animation: fadeSlideUp 0.6s ease-out 0.4s both; }
    .top-item { animation: fadeSlideUp 0.4s ease-out forwards; opacity: 0; }
    .top-item:nth-child(1) { animation-delay: 0.5s; }
    .top-item:nth-child(2) { animation-delay: 0.55s; }
    .top-item:nth-child(3) { animation-delay: 0.6s; }
    .top-item:nth-child(4) { animation-delay: 0.65s; }
    .top-item:nth-child(5) { animation-delay: 0.7s; }
    .trend-badge { animation: pulseGlow 2s ease-in-out infinite; }
    .chart-gradient { background: linear-gradient(180deg, rgba(168,85,247,0.5) 0%, rgba(168,85,247,0.15) 60%, rgba(168,85,247,0.05) 100%); }
    .chart-bar-wrapper { border-radius: 6px 6px 0 0; overflow: hidden; }
    .glass-card { backdrop-filter: blur(12px); }
    .rank-badge { background: linear-gradient(135deg, rgba(168,85,247,0.2), rgba(236,72,153,0.15)); border: 1px solid rgba(168,85,247,0.2); }
</style>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center gap-3 mb-6">
        <a href="/menu" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <h1 class="font-display text-lg font-bold text-white">Analytics</h1>
    </div>

    <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="stat-card bg-gradient-to-br from-brand-600/20 to-purple-700/10 rounded-xl border border-brand-500/15 p-3 hover:border-brand-500/40 transition-all hover:-translate-y-0.5">
            <span class="text-zinc-400 text-[10px] font-medium flex items-center gap-1">
                <span class="material-icons-round text-brand-400 text-sm">visibility</span>
                Total Views
            </span>
            <div class="flex items-center justify-between mt-1">
                <span class="text-white text-xl font-bold"><?= number_format((int)($d['total_views'] ?? 0)) ?></span>
                <span class="trend-badge flex items-center gap-0.5 text-emerald-400 text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-500/15">
                    <span class="material-icons-round text-sm">trending_up</span>
                    <?= $d['views_growth'] ?? 0 ?>%
                </span>
            </div>
        </div>
        <div class="stat-card bg-gradient-to-br from-pink-600/20 to-rose-700/10 rounded-xl border border-pink-500/15 p-3 hover:border-pink-500/40 transition-all hover:-translate-y-0.5">
            <span class="text-zinc-400 text-[10px] font-medium flex items-center gap-1">
                <span class="material-icons-round text-pink-400 text-sm">favorite</span>
                Total Likes
            </span>
            <div class="flex items-center justify-between mt-1">
                <span class="text-white text-xl font-bold"><?= number_format((int)($d['total_likes'] ?? 0)) ?></span>
                <span class="trend-badge flex items-center gap-0.5 text-brand-400 text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-brand-500/15">+<?= $d['engagement_rate'] ?? 0 ?>%</span>
            </div>
        </div>
        <div class="stat-card bg-gradient-to-br from-emerald-600/20 to-green-700/10 rounded-xl border border-emerald-500/15 p-3 hover:border-emerald-500/40 transition-all hover:-translate-y-0.5">
            <span class="text-zinc-400 text-[10px] font-medium flex items-center gap-1">
                <span class="material-icons-round text-emerald-400 text-sm">people</span>
                Followers
            </span>
            <div class="flex items-center justify-between mt-1">
                <span class="text-white text-xl font-bold"><?= number_format((int)($d['total_followers'] ?? 0)) ?></span>
                <span class="trend-badge flex items-center gap-0.5 text-emerald-400 text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-500/15">
                    <span class="material-icons-round text-sm">trending_up</span>
                    <?= $d['followers_growth'] ?? 0 ?>%
                </span>
            </div>
        </div>
        <div class="stat-card bg-gradient-to-br from-amber-600/20 to-yellow-700/10 rounded-xl border border-amber-500/15 p-3 hover:border-amber-500/40 transition-all hover:-translate-y-0.5">
            <span class="text-zinc-400 text-[10px] font-medium flex items-center gap-1">
                <span class="material-icons-round text-amber-400 text-sm">account_balance_wallet</span>
                Earnings
            </span>
            <div class="flex items-center justify-between mt-1">
                <span class="text-white text-xl font-bold">KES <?= number_format((float)($d['total_earnings'] ?? 0)) ?></span>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-3 gap-2 mb-4">
        <div class="stat-card-small bg-surface-100/50 rounded-xl border border-surface-400/10 p-3 text-center hover:border-surface-400/30 transition-all">
            <div class="w-7 h-7 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-1.5">
                <span class="material-icons-round text-blue-400 text-sm">chat_bubble_outline</span>
            </div>
            <span class="text-white text-sm font-bold block"><?= number_format((int)($d['total_comments'] ?? 0)) ?></span>
            <span class="text-zinc-500 text-[9px] font-medium">Comments</span>
        </div>
        <div class="stat-card-small bg-surface-100/50 rounded-xl border border-surface-400/10 p-3 text-center hover:border-surface-400/30 transition-all">
            <div class="w-7 h-7 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-1.5">
                <span class="material-icons-round text-emerald-400 text-sm">ios_share</span>
            </div>
            <span class="text-white text-sm font-bold block"><?= number_format((int)($d['total_shares'] ?? 0)) ?></span>
            <span class="text-zinc-500 text-[9px] font-medium">Shares</span>
        </div>
        <div class="stat-card-small bg-surface-100/50 rounded-xl border border-surface-400/10 p-3 text-center hover:border-surface-400/30 transition-all">
            <div class="w-7 h-7 rounded-full bg-brand-500/20 flex items-center justify-center mx-auto mb-1.5">
                <span class="material-icons-round text-brand-400 text-sm">auto_graph</span>
            </div>
            <span class="text-white text-sm font-bold block"><?= $d['engagement_rate'] ?? 0 ?>%</span>
            <span class="text-zinc-500 text-[9px] font-medium">Engagement</span>
        </div>
    </div>

    <div class="chart-container bg-surface-100/60 rounded-2xl border border-surface-400/15 p-4 mb-4 hover:border-brand-500/20 transition-all">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-white text-xs font-bold flex items-center gap-1.5">
                <span class="material-icons-round text-brand-400 text-lg">bar_chart</span>
                Daily Views (Last 7 Days)
            </h3>
            <span class="text-zinc-500 text-[9px] font-medium">Total: <?= number_format(array_sum(array_column($d['daily_views'] ?? [], 'views'))) ?></span>
        </div>
        <div class="flex items-end gap-2 h-32">
            <?php $maxViews = max(array_column($d['daily_views'] ?? [], 'views')); $maxViews = $maxViews ?: 1; ?>
            <?php foreach (($d['daily_views'] ?? []) as $i => $day): ?>
            <div class="chart-bar flex-1 flex flex-col items-center gap-1 group" style="animation-delay: <?= 0.4 + $i * 0.08 ?>s">
                 <div class="w-full rounded-t-md relative chart-bar-wrapper" style="height: <?= max(8, ((int)$day['views'] / $maxViews) * 100) ?>%">
                     <div class="w-full h-full chart-gradient rounded-t-md hover:shadow-lg hover:shadow-brand-500/30 transition-shadow chart-hover-glow"></div>
                     <div class="absolute -top-4 left-1/2 -translate-x-1/2 text-white text-[8px] font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity"><?= number_format((int)$day['views']) ?></div>
                </div>
                <span class="text-zinc-500 text-[8px] font-medium mt-1"><?= $day['date'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="flex items-center gap-3 mt-3 pt-3 border-t border-surface-400/10">
            <div class="flex items-center gap-1.5">
                <div class="w-2.5 h-2.5 rounded-sm chart-gradient"></div>
                <span class="text-zinc-600 text-[9px]">Views</span>
            </div>
            <span class="text-zinc-600 text-[9px]">·</span>
            <span class="text-zinc-600 text-[9px]">Avg: <?= number_format((int)(array_sum(array_column($d['daily_views'] ?? [], 'views')) / max(count($d['daily_views'] ?? []), 1))) ?>/day</span>
        </div>
    </div>

    <div class="mb-4">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-white text-xs font-bold flex items-center gap-1.5">
                <span class="material-icons-round text-amber-400 text-lg">emoji_events</span>
                Top Performing Content
            </h3>
        </div>
        <?php if (!empty($d['top_content'])): ?>
        <div class="space-y-2">
            <?php foreach ($d['top_content'] as $i => $item): ?>
            <div class="top-item flex items-center gap-3 p-3 rounded-xl bg-surface-100/40 border border-surface-400/10 hover:bg-surface-100/60 hover:border-brand-500/30 transition-all hover:-translate-y-0.5">
                <div class="w-7 h-7 rounded-lg rank-badge flex items-center justify-center flex-shrink-0">
                    <span class="text-brand-300 text-xs font-bold">#<?= $i + 1 ?></span>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-white text-xs font-semibold truncate"><?= htmlspecialchars(mb_substr($item['content'] ?? '', 0, 60)) . (mb_strlen($item['content'] ?? '') > 60 ? '...' : '') ?></p>
                    <div class="flex items-center gap-2 mt-0.5">
                        <span class="text-zinc-500 text-[9px] flex items-center gap-0.5"><span class="material-icons-round text-pink-400 text-[12px]">favorite</span><?= formatCount($item['likes'] ?? 0) ?></span>
                        <span class="text-zinc-600">·</span>
                        <span class="text-zinc-500 text-[9px] flex items-center gap-0.5"><span class="material-icons-round text-blue-400 text-[12px]">chat_bubble</span><?= formatCount($item['comments_count'] ?? 0) ?></span>
                        <span class="text-zinc-600">·</span>
                        <span class="text-zinc-500 text-[9px] flex items-center gap-0.5"><span class="material-icons-round text-emerald-400 text-[12px]">ios_share</span><?= formatCount($item['shares'] ?? 0) ?></span>
                    </div>
                </div>
                <span class="text-zinc-600 text-[9px] flex-shrink-0"><?= timeAgo($item['created_at']) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-10 bg-surface-100/30 rounded-xl border border-surface-400/10">
            <div class="w-14 h-14 rounded-full bg-surface-200/80 flex items-center justify-center mx-auto mb-3">
                <span class="material-icons-round text-zinc-500 text-3xl">analytics</span>
            </div>
            <p class="text-white text-sm font-semibold mb-1">No data yet</p>
            <p class="text-zinc-500 text-xs">Publish content to see your top performers</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
