<?php $activeTab = 'clips'; $title = 'Reels - DTTube'; ?>
<?php ob_start(); ?>

<div id="reelsContainer" class="relative w-full h-[calc(100vh-112px)] overflow-hidden">

    <div id="reelsSlider" class="transition-transform duration-300 ease-out">

        <?php
        $bgs = [
            'from-purple-900 via-violet-800 to-indigo-900',
            'from-red-900 via-orange-800 to-amber-900',
            'from-blue-900 via-cyan-800 to-teal-900',
            'from-rose-900 via-pink-800 to-fuchsia-900',
            'from-amber-900 via-yellow-800 to-orange-900',
            'from-violet-900 via-purple-800 to-fuchsia-900',
        ];
        if (empty($reels)) {
            $reels = [
                ['id' => 1, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'title' => 'Dance Challenge #Kukua', 'description' => 'Can you keep up with the Kukua challenge? 🔥💃', 'thumbnail' => 'https://picsum.photos/id/20/300/500', 'views' => 2450000, 'likes' => 24500, 'comments_count' => 1800, 'shares' => 5200, 'song_name' => 'Kukua Beat - DJ MixMaster', 'duration' => 30],
                ['id' => 2, 'creator_name' => 'Zara Ke', 'username' => 'zarake', 'creator_avatar' => 'https://picsum.photos/id/64/48/48', 'is_verified' => 1, 'title' => 'Cooking Jollof Rice', 'description' => 'My secret recipe revealed! 🍚', 'thumbnail' => 'https://picsum.photos/id/21/300/500', 'views' => 1800000, 'likes' => 18900, 'comments_count' => 3200, 'shares' => 8100, 'song_name' => 'Afro Kitchen Vibes - BeatMaker', 'duration' => 45],
            ];
        }
        ?>

        <?php foreach ($reels as $index => $reel): ?>
        <div class="reel-item relative w-full h-[calc(100vh-112px)] bg-gradient-to-b <?= $bgs[$index % count($bgs)] ?>" data-reel-id="<?= $reel['id'] ?>" data-index="<?= $index ?>">

            <div class="absolute inset-0 flex items-center justify-center">
                <div class="text-center opacity-30">
                    <span class="material-icons-round text-white text-7xl">play_circle</span>
                </div>
            </div>

            <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20 pointer-events-none"></div>

            <div class="absolute top-4 left-3 right-16 z-10">
                <div class="flex items-center gap-2 text-white/60 text-xs">
                    <span class="material-icons-round text-sm">movie</span>
                    <span class="font-medium">Reels</span>
                </div>
            </div>

            <div class="absolute right-3 bottom-24 flex flex-col items-center gap-5 z-20">
                <button onclick="toggleLike(this)" class="flex flex-col items-center gap-0.5 group">
                    <div class="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-hover:bg-red-500/30 transition-colors">
                        <span class="material-icons-round text-white text-[24px] like-icon">favorite_border</span>
                    </div>
                    <span class="text-white text-[11px] font-medium like-count"><?= formatCount($reel['likes'] ?? 0) ?></span>
                </button>

                <button onclick="openComments(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5 group">
                    <div class="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-hover:bg-brand-500/30 transition-colors">
                        <span class="material-icons-round text-white text-[24px]">chat_bubble_outline</span>
                    </div>
                    <span class="text-white text-[11px] font-medium"><?= $reel['comments_count'] ?? 0 ?></span>
                </button>

                <button onclick="shareReel(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5 group">
                    <div class="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-hover:bg-green-500/30 transition-colors">
                        <span class="material-icons-round text-white text-[24px]">repeat</span>
                    </div>
                    <span class="text-white text-[11px] font-medium"><?= $reel['shares'] ?></span>
                </button>

                <button onclick="openReelGiftPanel(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5 group">
                    <div class="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center group-hover:bg-amber-500/30 transition-colors">
                        <span class="material-icons-round text-amber-400 text-[24px]">card_giftcard</span>
                    </div>
                    <span class="text-white text-[11px] font-medium">Gift</span>
                </button>

                <div class="w-11 h-11 rounded-full border-2 border-white/40 overflow-hidden animate-spin-slow mt-1" style="animation: spin 4s linear infinite;">
                    <img src="https://placehold.co/44x44/3f3f46/ffffff?text=♪" alt="Music" class="w-full h-full object-cover">
                </div>

                <button onclick="toggleReelMenu()" class="flex flex-col items-center gap-0.5">
                    <div class="w-11 h-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
                        <span class="material-icons-round text-white text-[24px]">more_horiz</span>
                    </div>
                </button>
            </div>

            <div class="absolute bottom-4 left-3 right-16 z-20">
                <div class="flex items-center gap-2.5 mb-2.5">
                    <img src="<?= $reel['creator_avatar'] ?? 'https://placehold.co/40x40/3f3f46/ffffff?text=U' ?>" alt="<?= $reel['creator_name'] ?? '' ?>" class="w-10 h-10 rounded-full border-2 border-white/30">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-1">
                            <span class="text-white text-sm font-bold">@<?= strtolower($reel['username'] ?? '') ?></span>
                            <?php if (!empty($reel['is_verified'])): ?>
                            <span class="material-icons-round text-brand-400 text-[14px]">verified</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <button onclick="followReelCreator(this)" class="px-3 py-1 rounded-lg gradient-brand text-white text-xs font-semibold hover:opacity-90 transition-opacity">Follow</button>
                </div>

                <p class="text-white text-[13px] leading-snug mb-2.5 line-clamp-2"><?= htmlspecialchars($reel['description'] ?? $reel['title'] ?? '') ?></p>

                <div class="flex items-center gap-1.5 mb-2.5 text-white/50 text-xs cursor-pointer" onclick="openComments(<?= $reel['id'] ?>)">
                    <span class="material-icons-round text-[14px]">chat_bubble</span>
                    <span>View all <?= formatCount($reel['comments_count'] ?? 0) ?> comments</span>
                </div>

                <div class="flex items-center gap-2">
                    <span class="material-icons-round text-white text-[14px]">music_note</span>
                    <div class="flex-1 overflow-hidden">
                        <div class="marquee text-white/70 text-xs whitespace-nowrap"><?= htmlspecialchars($reel['song_name'] ?? 'Original Sound') ?>&nbsp;&nbsp;&nbsp;♪&nbsp;&nbsp;&nbsp;<?= htmlspecialchars($reel['song_name'] ?? 'Original Sound') ?>&nbsp;&nbsp;&nbsp;♪&nbsp;&nbsp;&nbsp;</div>
                    </div>
                </div>
            </div>

        </div>
        <?php endforeach; ?>

    </div>

    <div id="reelMenu" class="hidden absolute top-1/2 right-14 -translate-y-1/2 z-30 bg-surface-100/95 backdrop-blur-xl rounded-2xl border border-surface-400/30 overflow-hidden shadow-2xl min-w-[180px]">
        <button onclick="toggleAutoscroll()" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg" id="autoscrollIcon">autoplay</span>
            <span class="text-zinc-200 text-sm font-medium" id="autoscrollLabel">Autoscroll: On</span>
        </button>
        <button onclick="saveReel()" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg">bookmark_border</span>
            <span class="text-zinc-200 text-sm font-medium">Save</span>
        </button>
        <button onclick="reportReel()" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg">report</span>
            <span class="text-zinc-200 text-sm font-medium">Report</span>
        </button>
        <button onclick="notInterested()" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg">block</span>
            <span class="text-zinc-200 text-sm font-medium">Not Interested</span>
        </button>
        <button onclick="shareReel(currentReel + 1)" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg">share</span>
            <span class="text-zinc-200 text-sm font-medium">Share to...</span>
        </button>
        <button onclick="downloadReel()" class="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-300 text-lg">download</span>
            <span class="text-zinc-200 text-sm font-medium">Download</span>
        </button>
    </div>

    <div id="commentsPanel" class="hidden absolute bottom-0 left-0 right-0 z-30 bg-surface-100/95 backdrop-blur-xl rounded-t-2xl border-t border-surface-400/30 max-h-[60%] flex flex-col">
        <div class="flex items-center justify-between px-4 py-3 border-b border-surface-400/20">
            <span class="text-white text-sm font-bold">Comments</span>
            <button onclick="closeComments()" class="p-1 rounded-full hover:bg-surface-200">
                <span class="material-icons-round text-zinc-400 text-xl">close</span>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            <?php for ($i = 0; $i < 5; $i++):
                $commenters = ['ZaraKe', 'ChefAmi', 'TechBro', 'LaughKing', 'GlowUp'];
                $texts = ['This is amazing! 🔥', 'No way!! 😂', 'Tutorial please 👏', 'First! 💪', 'Can\'t stop watching 🔄'];
            ?>
            <div class="flex gap-2.5">
                <img src="https://placehold.co/32x32/3f3f46/ffffff?text=<?= strtoupper(substr($commenters[$i], 0, 1)) ?>" class="w-8 h-8 rounded-full flex-shrink-0">
                <div>
                    <span class="text-white text-xs font-semibold"><?= $commenters[$i] ?></span>
                    <p class="text-zinc-300 text-[13px]"><?= $texts[$i] ?></p>
                    <div class="flex items-center gap-3 mt-0.5">
                        <span class="text-zinc-600 text-[10px]"><?= $i + 1 ?>h</span>
                        <button class="text-zinc-600 text-[10px] font-medium hover:text-zinc-400">Reply</button>
                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>
        <div class="px-4 py-2.5 border-t border-surface-400/20 flex items-center gap-2">
            <img src="https://picsum.photos/id/64/32/32" class="w-8 h-8 rounded-full flex-shrink-0">
            <input type="text" id="commentInput" placeholder="Add a comment..." class="flex-1 bg-surface-200 text-white px-3 py-2 rounded-full text-sm placeholder:text-surface-500 focus:outline-none" onkeydown="if(event.key==='Enter')postReelComment()">
            <button onclick="postReelComment()" class="text-brand-400 font-semibold text-sm">Post</button>
        </div>
    </div>

    <!-- REEL GIFT PANEL -->
    <div id="reelGiftPanel" class="fixed inset-0 z-50 hidden" onclick="closeReelGiftPanel(event)">
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
        <div class="absolute bottom-0 left-0 right-0 bg-surface-50 rounded-t-3xl slide-up max-w-lg mx-auto" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between p-4 border-b border-surface-400/20">
                <h3 class="font-display text-white font-bold text-lg">Send a Gift</h3>
                <button onclick="closeReelGiftPanel()" class="w-8 h-8 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
                    <span class="material-icons-round text-zinc-400 text-lg">close</span>
                </button>
            </div>
            <div class="p-4">
                <div class="flex items-center gap-2 mb-4">
                    <span class="material-icons-round text-amber-400 text-lg">monetization_on</span>
                    <span class="text-white text-sm font-semibold">Send a gift to support the creator!</span>
                </div>
                <div class="grid grid-cols-4 gap-3" id="reelGiftGrid">
                    <?php
                    $reelGifts = $data['gifts'] ?? [];
                    if (empty($reelGifts)) {
                        $reelGifts = [
                            ['id' => 1, 'name' => 'Heart', 'icon' => 'favorite', 'image_url' => null, 'price_usd' => 0.50, 'color_class' => 'text-red-400'],
                            ['id' => 2, 'name' => 'Fire', 'icon' => 'local_fire_department', 'image_url' => null, 'price_usd' => 1.00, 'color_class' => 'text-orange-400'],
                            ['id' => 3, 'name' => 'Star', 'icon' => 'star', 'image_url' => null, 'price_usd' => 2.50, 'color_class' => 'text-yellow-400'],
                            ['id' => 4, 'name' => 'Diamond', 'icon' => 'diamond', 'image_url' => null, 'price_usd' => 5.00, 'color_class' => 'text-cyan-400'],
                            ['id' => 5, 'name' => 'Crown', 'icon' => 'crown', 'image_url' => null, 'price_usd' => 10.00, 'color_class' => 'text-amber-400'],
                            ['id' => 6, 'name' => 'Rocket', 'icon' => 'rocket_launch', 'image_url' => null, 'price_usd' => 20.00, 'color_class' => 'text-purple-400'],
                            ['id' => 7, 'name' => 'Party', 'icon' => 'celebration', 'image_url' => null, 'price_usd' => 50.00, 'color_class' => 'text-pink-400'],
                            ['id' => 8, 'name' => 'Super', 'icon' => 'bolt', 'image_url' => null, 'price_usd' => 100.00, 'color_class' => 'text-brand-400'],
                        ];
                    }
                    ?>
                    <?php foreach ($reelGifts as $g): ?>
                    <button onclick="sendReelGift(<?= $reel['id'] ?? 1 ?>, <?= $g['id'] ?>)" class="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-surface-200/60 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/40 transition-all group" data-gift-id="<?= $g['id'] ?>">
                        <?php if (!empty($g['image_url'])): ?>
                        <div class="w-9 h-9 rounded-lg overflow-hidden group-hover:scale-110 transition-transform">
                            <img src="<?= $g['image_url'] ?>" alt="<?= $g['name'] ?>" class="w-full h-full object-cover">
                        </div>
                        <?php else: ?>
                        <span class="material-icons-round <?= $g['color_class'] ?> text-2xl group-hover:scale-110 transition-transform"><?= $g['icon'] ?></span>
                        <?php endif; ?>
                        <span class="text-zinc-300 text-[10px] font-medium"><?= $g['name'] ?></span>
                        <span class="text-brand-400 text-[9px] font-bold">$<?= number_format((float)$g['price_usd'], 2) ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.animate-spin-slow { animation: spin 4s linear infinite; }
.marquee { animation: marquee 8s linear infinite; }
@keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
.reel-item { scroll-snap-align: start; }
#reelsContainer { scroll-snap-type: y mandatory; overflow-y: scroll; }
#reelsContainer::-webkit-scrollbar { display: none; }
#reelsContainer { -ms-overflow-style: none; scrollbar-width: none; }
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
</style>

<script>
let currentReel = 0;
const totalReels = <?= count($reels) ?>;
let autoscrollEnabled = true;
let autoscrollTimer = null;
const container = document.getElementById('reelsContainer');

container.addEventListener('scroll', () => {
    const reelHeight = container.clientHeight;
    currentReel = Math.round(container.scrollTop / reelHeight);
    resetAutoscrollTimer();
});

function goToReel(index) {
    if (index < 0 || index >= totalReels) return;
    currentReel = index;
    container.scrollTo({ top: currentReel * container.clientHeight, behavior: 'smooth' });
}

function nextReel() {
    if (currentReel < totalReels - 1) {
        goToReel(currentReel + 1);
    } else {
        goToReel(0);
    }
}

function toggleLike(btn) {
    const icon = btn.querySelector('.like-icon');
    const countEl = btn.querySelector('.like-count');
    if (icon.textContent === 'favorite_border') {
        icon.textContent = 'favorite';
        icon.classList.add('text-red-500');
        icon.classList.remove('text-white');
    } else {
        icon.textContent = 'favorite_border';
        icon.classList.remove('text-red-500');
        icon.classList.add('text-white');
    }
}

function toggleReelMenu() {
    const menu = document.getElementById('reelMenu');
    menu.classList.toggle('hidden');
}

function toggleAutoscroll() {
    autoscrollEnabled = !autoscrollEnabled;
    const label = document.getElementById('autoscrollLabel');
    const icon = document.getElementById('autoscrollIcon');
    label.textContent = 'Autoscroll: ' + (autoscrollEnabled ? 'On' : 'Off');
    icon.textContent = autoscrollEnabled ? 'autoplay' : 'pause_circle';
    if (autoscrollEnabled) {
        resetAutoscrollTimer();
    } else {
        clearTimeout(autoscrollTimer);
    }
    document.getElementById('reelMenu').classList.add('hidden');
}

function resetAutoscrollTimer() {
    clearTimeout(autoscrollTimer);
    if (autoscrollEnabled) {
        autoscrollTimer = setTimeout(nextReel, 8000);
    }
}

function openComments(reelId) {
    document.getElementById('commentsPanel').classList.remove('hidden');
}

function closeComments() {
    document.getElementById('commentsPanel').classList.add('hidden');
}

function shareReel(id) {
    if (navigator.share) {
        navigator.share({ title: 'DTTube Reel', url: '/reels/' + id }).catch(() => {});
    } else {
        navigator.clipboard.writeText(window.location.origin + '/reels/' + id).then(() => { showReelToast('Link copied!'); }).catch(() => {});
    }
    document.getElementById('reelMenu').classList.add('hidden');
}

function tipReel(id) {
    openReelGiftPanel(id);
}

/* ===== REEL GIFT FUNCTIONS ===== */
let currentReelGiftId = 1;

function openReelGiftPanel(reelId) {
    currentReelGiftId = reelId;
    document.getElementById('reelGiftPanel').classList.remove('hidden');
}

function closeReelGiftPanel(e) {
    if (!e || e.target === e.currentTarget) {
        document.getElementById('reelGiftPanel').classList.add('hidden');
    }
}

function sendReelGift(reelId, giftId) {
    closeReelGiftPanel();
    const grid = document.getElementById('reelGiftGrid');
    const btn = grid.querySelector('button[data-gift-id="' + giftId + '"]');
    const giftName = btn ? btn.querySelector('.text-zinc-300').textContent : 'Gift';
    showReelToast('Sent ' + giftName + '! 🎁');

    fetch('/reels/' + reelId + '/gift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ gift_id: giftId })
    }).then(r => r.json()).then(d => {
        if (d.error) showReelToast(d.error);
    }).catch(() => {});
}

function followReelCreator(btn) {
    btn.textContent = 'Following';
    btn.classList.remove('gradient-brand');
    btn.classList.add('bg-white/10', 'text-zinc-400');
}

function postReelComment() {
    const input = document.getElementById('commentInput');
    const msg = input.value.trim();
    if (!msg) return;
    const panel = document.getElementById('commentsPanel');
    const commentsDiv = panel.querySelector('.overflow-y-auto');
    const div = document.createElement('div');
    div.className = 'flex gap-2.5 fade-in';
    div.innerHTML = '<div class="w-8 h-8 rounded-full bg-brand-600 flex-shrink-0 flex items-center justify-center"><span class="material-icons-round text-white text-sm">person</span></div><div><span class="text-white text-xs font-semibold">You</span><p class="text-zinc-300 text-[13px]">' + escapeHtml(msg) + '</p><div class="flex items-center gap-3 mt-0.5"><span class="text-zinc-600 text-[10px]">Just now</span></div></div>';
    commentsDiv.appendChild(div);
    commentsDiv.scrollTop = commentsDiv.scrollHeight;
    input.value = '';
}

function saveReel() {
    showReelToast('Reel saved!');
    document.getElementById('reelMenu').classList.add('hidden');
}

function reportReel() {
    showReelToast('Reported');
    document.getElementById('reelMenu').classList.add('hidden');
}

function notInterested() {
    showReelToast('Marked as not interested');
    document.getElementById('reelMenu').classList.add('hidden');
}

function downloadReel() {
    showReelToast('Download started');
    document.getElementById('reelMenu').classList.add('hidden');
}

function showReelToast(msg) {
    const existing = document.querySelector('.reel-toast');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.className = 'reel-toast fixed top-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-surface-200 text-white text-sm font-medium z-[200] slide-up';
    div.textContent = msg;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 2500);
}

function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}

document.addEventListener('click', (e) => {
    const menu = document.getElementById('reelMenu');
    if (!menu.classList.contains('hidden') && !e.target.closest('#reelMenu') && !e.target.closest('[onclick="toggleReelMenu()"]')) {
        menu.classList.add('hidden');
    }
});

resetAutoscrollTimer();
</script>

<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
