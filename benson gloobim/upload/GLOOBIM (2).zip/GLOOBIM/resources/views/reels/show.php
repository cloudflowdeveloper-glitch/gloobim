<?php $title = ($data['reel']['title'] ?? 'Reel') . ' - DTTube'; ?>
<?php
$reel = $data['reel'] ?? [];
$comments = $data['comments'] ?? [];
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto bg-black min-h-screen">
    <div class="relative flex items-center justify-center h-[calc(100vh-7rem)]">
        <div class="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-indigo-950/60 via-purple-950/40 to-black">
            <img src="<?= $reel['thumbnail'] ?? 'https://placehold.co/300x500/3f3f46/ffffff?text=Reel' ?>" alt="" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40"></div>
        </div>

        <div class="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-3">
            <a href="/reels" class="w-9 h-9 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-black/70 transition-colors">
                <span class="material-icons-round text-white text-xl">chevron_left</span>
            </a>
            <div class="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-sm">
                <span class="material-icons-round text-red-500 text-sm">favorite</span>
                <span class="text-white text-xs font-semibold"><?= formatCount($reel['likes'] ?? 0) ?></span>
                <span class="w-px h-3 bg-white/20 mx-1"></span>
                <span class="material-icons-round text-white/70 text-sm">visibility</span>
                <span class="text-white/70 text-xs"><?= formatCount($reel['views'] ?? 0) ?></span>
            </div>
        </div>

        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
            <div class="w-16 h-16 rounded-full bg-brand-600/80 backdrop-blur-sm flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                <span class="material-icons-round text-white text-3xl">play_arrow</span>
            </div>
        </div>

        <div class="absolute bottom-0 left-0 right-0 z-10 p-4">
            <div class="flex items-center gap-3 mb-2">
                <img src="<?= $reel['creator_avatar'] ?? 'https://placehold.co/40x40/6d28d9/ffffff?text=U' ?>" alt="" class="w-10 h-10 rounded-full border-2 border-white/40">
                <div>
                    <div class="flex items-center gap-1">
                        <span class="text-white text-sm font-bold"><?= htmlspecialchars($reel['creator_name'] ?? $reel['username'] ?? '') ?></span>
                        <?php if (!empty($reel['is_verified'])): ?>
                        <span class="material-icons-round text-brand-400 text-sm">verified</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-white/60 text-[10px]"><?= htmlspecialchars($reel['song_name'] ?? '') ?></span>
                </div>
            </div>
            <p class="text-white/80 text-xs leading-relaxed"><?= htmlspecialchars($reel['description'] ?? $reel['title'] ?? '') ?></p>
        </div>

        <div class="absolute bottom-20 right-3 z-10 flex flex-col items-center gap-4">
            <button onclick="likeReel(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5">
                <div class="w-11 h-11 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-red-500/30 transition-all">
                    <span class="material-icons-round text-white hover:text-red-400 text-2xl transition-colors" id="reelLikeIcon">favorite_border</span>
                </div>
                <span class="text-white/70 text-[9px]" id="reelLikeCount"><?= formatCount($reel['likes'] ?? 0) ?></span>
            </button>
            <button onclick="openComments()" class="flex flex-col items-center gap-0.5">
                <div class="w-11 h-11 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-brand-500/30 transition-all">
                    <span class="material-icons-round text-white hover:text-brand-400 text-2xl transition-colors">chat</span>
                </div>
                <span class="text-white/70 text-[9px]"><?= formatCount($reel['comments_count'] ?? 0) ?></span>
            </button>
            <button onclick="shareReel(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5">
                <div class="w-11 h-11 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-brand-500/30 transition-all">
                    <span class="material-icons-round text-white hover:text-brand-400 text-2xl transition-colors">ios_share</span>
                </div>
                <span class="text-white/70 text-[9px]"><?= formatCount($reel['shares'] ?? 0) ?></span>
            </button>
            <button onclick="openReelGiftPanel(<?= $reel['id'] ?>)" class="flex flex-col items-center gap-0.5">
                <div class="w-11 h-11 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center hover:bg-amber-500/30 transition-all">
                    <span class="material-icons-round text-white hover:text-amber-400 text-2xl transition-colors">card_giftcard</span>
                </div>
                <span class="text-white/70 text-[9px]">Gift</span>
            </button>
        </div>
    </div>

    <div id="commentsPanel" class="fixed inset-0 z-50 hidden" onclick="closeComments(event)">
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
        <div class="absolute bottom-0 left-0 right-0 bg-surface-50 rounded-t-3xl max-h-[70vh] flex flex-col slide-up" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between p-4 border-b border-surface-400/20 flex-shrink-0">
                <h3 class="text-white font-bold text-lg">Comments (<?= count($comments) ?>)</h3>
                <button onclick="closeComments()" class="w-8 h-8 rounded-full bg-surface-200 flex items-center justify-center">
                    <span class="material-icons-round text-zinc-400">close</span>
                </button>
            </div>
            <div class="flex-1 overflow-y-auto p-4 space-y-3" id="commentsContainer">
                <?php if (!empty($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                    <div class="flex gap-3">
                        <img src="<?= $comment['commenter_avatar'] ?? 'https://picsum.photos/id/64/32/32' ?>" alt="" class="w-8 h-8 rounded-full flex-shrink-0">
                        <div>
                            <div class="flex items-center gap-1">
                                <span class="text-white text-xs font-semibold"><?= htmlspecialchars($comment['commenter_name'] ?? $comment['username'] ?? '') ?></span>
                                <span class="text-zinc-600 text-[9px]"><?= timeAgo($comment['created_at'] ?? '') ?></span>
                            </div>
                            <p class="text-zinc-300 text-xs mt-0.5"><?= htmlspecialchars($comment['body'] ?? '') ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div class="text-center py-8">
                    <span class="material-icons-round text-zinc-500 text-3xl">chat_bubble_outline</span>
                    <p class="text-zinc-500 text-xs mt-2">No comments yet. Be the first!</p>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex items-center gap-2 p-4 border-t border-surface-400/20 flex-shrink-0">
                <input type="text" id="commentInput" placeholder="Add a comment..." class="flex-1 bg-surface-200 text-white px-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500 focus:outline-none text-sm" onkeydown="if(event.key==='Enter')addComment(<?= $reel['id'] ?>)">
                <button onclick="addComment(<?= $reel['id'] ?>)" class="w-10 h-10 rounded-full gradient-brand flex items-center justify-center flex-shrink-0">
                    <span class="material-icons-round text-white">send</span>
                </button>
            </div>
        </div>
    </div>

    <!-- REEL GIFT PANEL -->
    <div id="reelGiftPanel" class="fixed inset-0 z-50 hidden" onclick="closeReelGiftPanel(event)">
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
        <div class="absolute bottom-0 left-0 right-0 bg-surface-50 rounded-t-3xl slide-up max-w-lg mx-auto" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between p-4 border-b border-surface-400/20">
                <h3 class="font-display text-white font-bold text-lg">Send a Gift</h3>
                <button onclick="closeReelGiftPanel()" class="w-8 h-8 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
                    <span class="material-icons-round text-zinc-400 text-lg">close</span>
                </button>
            </div>
            <div class="p-4">
                <div class="flex items-center gap-2 mb-4">
                    <span class="material-icons-round text-amber-400 text-lg">monetization_on</span>
                    <span class="text-white text-sm font-semibold">Send a gift to support <?= htmlspecialchars($reel['creator_name'] ?? $reel['username'] ?? 'the creator') ?>!</span>
                </div>
                <div class="grid grid-cols-4 gap-3" id="reelGiftGrid">
                    <?php
                    $reelGifts = $data['gifts'] ?? [];
                    if (empty($reelGifts)) {
                        $reelGifts = [
                            ['id' => 1, 'name' => 'Heart', 'icon' => 'favorite', 'image_url' => null, 'price_usd' => 0.50, 'color_class' => 'text-red-400'],
                            ['id' => 2, 'name' => 'Fire', 'icon' => 'local_fire_department', 'image_url' => null, 'price_usd' => 1.00, 'color_class' => 'text-orange-400'],
                            ['id' => 3, 'name' => 'Star', 'icon' => 'star', 'image_url' => null, 'price_usd' => 2.50, 'color_class' => 'text-yellow-400'],
                            ['id' => 4, 'name' => 'Diamond', 'icon' => 'diamond', 'image_url' => null, 'price_usd' => 5.00, 'color_class' => 'text-cyan-400'],
                            ['id' => 5, 'name' => 'Crown', 'icon' => 'crown', 'image_url' => null, 'price_usd' => 10.00, 'color_class' => 'text-amber-400'],
                            ['id' => 6, 'name' => 'Rocket', 'icon' => 'rocket_launch', 'image_url' => null, 'price_usd' => 20.00, 'color_class' => 'text-purple-400'],
                            ['id' => 7, 'name' => 'Party', 'icon' => 'celebration', 'image_url' => null, 'price_usd' => 50.00, 'color_class' => 'text-pink-400'],
                            ['id' => 8, 'name' => 'Super', 'icon' => 'bolt', 'image_url' => null, 'price_usd' => 100.00, 'color_class' => 'text-brand-400'],
                        ];
                    }
                    ?>
                    <?php foreach ($reelGifts as $g): ?>
                    <button onclick="sendReelGift(<?= $reel['id'] ?>, <?= $g['id'] ?>)" class="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-surface-200/60 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/40 transition-all group" data-gift-id="<?= $g['id'] ?>">
                        <?php if (!empty($g['image_url'])): ?>
                        <div class="w-9 h-9 rounded-lg overflow-hidden group-hover:scale-110 transition-transform">
                            <img src="<?= $g['image_url'] ?>" alt="<?= $g['name'] ?>" class="w-full h-full object-cover">
                        </div>
                        <?php else: ?>
                        <span class="material-icons-round <?= $g['color_class'] ?> text-2xl group-hover:scale-110 transition-transform"><?= $g['icon'] ?></span>
                        <?php endif; ?>
                        <span class="text-zinc-300 text-[10px] font-medium"><?= $g['name'] ?></span>
                        <span class="text-brand-400 text-[9px] font-bold">$<?= number_format((float)$g['price_usd'], 2) ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
.slide-up { animation: slideUp 0.3s ease-out forwards; }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
</style>

<script>
function likeReel(id) {
    const icon = document.getElementById('reelLikeIcon');
    const countEl = document.getElementById('reelLikeCount');
    if (icon.textContent === 'favorite_border') {
        icon.textContent = 'favorite';
        icon.classList.add('text-red-400');
        let c = parseInt(countEl.textContent.replace(/[^0-9]/g, '')) + 1;
        countEl.textContent = formatCount(c);
    }
    fetch('/reels/' + id + '/like', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function openComments() { document.getElementById('commentsPanel').classList.remove('hidden'); }
function closeComments(e) { if (!e || e.target === e.currentTarget) document.getElementById('commentsPanel').classList.add('hidden'); }

function addComment(id) {
    const input = document.getElementById('commentInput');
    const body = input.value.trim();
    if (!body) return;
    input.value = '';
    fetch('/reels/' + id + '/comment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ body: body })
    }).then(r => r.json()).then(d => {
        location.reload();
    }).catch(() => {});
}

function shareReel(id) {
    if (navigator.share) {
        navigator.share({ title: 'Check out this reel!', url: '/reels/' + id });
    } else {
        navigator.clipboard.writeText(window.location.origin + '/reels/' + id).then(() => alert('Link copied!'));
    }
    fetch('/reels/' + id + '/share', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

/* ===== REEL GIFT FUNCTIONS ===== */
function openReelGiftPanel(reelId) {
    document.getElementById('reelGiftPanel').classList.remove('hidden');
}
function closeReelGiftPanel(e) {
    if (!e || e.target === e.currentTarget) {
        document.getElementById('reelGiftPanel').classList.add('hidden');
    }
}
function sendReelGift(reelId, giftId) {
    closeReelGiftPanel();
    const grid = document.getElementById('reelGiftGrid');
    const btn = grid.querySelector('button[data-gift-id="' + giftId + '"]');
    const giftName = btn ? btn.querySelector('.text-zinc-300').textContent : 'Gift';
    alert('Sent ' + giftName + '! 🎁');

    fetch('/reels/' + reelId + '/gift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ gift_id: giftId })
    }).then(r => r.json()).then(d => {
        if (d.error) alert(d.error);
    }).catch(() => {});
}

function formatCount(n) {
    n = parseInt(n) || 0;
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
