<?php $title = 'Notifications - DTTube'; ?>
<?php ob_start(); ?>
<style>
    .notif-row { transition: all 0.2s ease; }
    .notif-row:hover { background: rgba(39, 39, 42, 0.6); }
    .notif-row.unread { border-left: 3px solid #a855f7; }
</style>

<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center justify-between mb-1">
        <h1 class="font-display text-xl font-bold text-white">Notifications</h1>
        <button onclick="markAllRead()" class="text-brand-400 text-[11px] font-semibold hover:text-brand-300 transition-colors">Mark all read</button>
    </div>
    <p class="text-zinc-500 text-xs mb-5">Stay updated with your activity</p>

    <?php
    $unreadCount = 0;
    $today = [];
    $thisWeek = [];
    $earlier = [];
    $now = time();
    foreach ($notifications as $n) {
        if (!$n['is_read']) $unreadCount++;
        $diff = $now - strtotime($n['created_at']);
        if ($diff < 86400) $today[] = $n;
        elseif ($diff < 604800) $thisWeek[] = $n;
        else $earlier[] = $n;
    }
    ?>

    <div class="flex items-center gap-3 mb-5">
        <div class="flex-1 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-surface-100/60 border border-surface-400/15">
            <span class="material-icons-round text-brand-400 text-lg">notifications</span>
            <span class="text-white text-xs font-semibold">All</span>
            <?php if ($unreadCount > 0): ?>
            <span class="px-1.5 py-0.5 rounded-full bg-brand-600/30 text-brand-300 text-[9px] font-bold"><?= $unreadCount ?> new</span>
            <?php endif; ?>
        </div>
        <div class="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-surface-200/60 border border-surface-400/15 text-zinc-500 cursor-pointer hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-lg">filter_list</span>
            <span class="text-xs font-medium">Filter</span>
        </div>
    </div>

    <div class="flex gap-2 mb-5 overflow-x-auto scrollbar-hide">
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full gradient-brand text-white text-[10px] font-bold">All</button>
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-400 text-[10px] font-medium border border-surface-400/30 hover:bg-surface-300 hover:text-zinc-300 transition-colors">Likes</button>
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-400 text-[10px] font-medium border border-surface-400/30 hover:bg-surface-300 hover:text-zinc-300 transition-colors">Comments</button>
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-400 text-[10px] font-medium border border-surface-400/30 hover:bg-surface-300 hover:text-zinc-300 transition-colors">Follows</button>
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-400 text-[10px] font-medium border border-surface-400/30 hover:bg-surface-300 hover:text-zinc-300 transition-colors">Tips</button>
        <button class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-400 text-[10px] font-medium border border-surface-400/30 hover:bg-surface-300 hover:text-zinc-300 transition-colors">System</button>
    </div>

    <?php if ($unreadCount > 0): ?>
    <div class="flex items-center gap-2 mb-3">
        <span class="w-1.5 h-1.5 rounded-full bg-brand-500"></span>
        <span class="text-zinc-500 text-[10px] font-medium uppercase tracking-wider">New</span>
        <span class="flex-1 h-px bg-surface-400/20"></span>
    </div>
    <div class="space-y-1 mb-6">
        <?php foreach ($today as $n): ?>
        <div class="notif-row <?= $n['is_read'] ? '' : 'unread' ?> flex items-start gap-3 p-3 rounded-xl bg-surface-100/40 border border-surface-400/10 cursor-pointer" onclick="openNotification(<?= $n['id'] ?>)">
            <div class="relative flex-shrink-0">
                <img src="<?= $n['actor_avatar'] ?? 'https://placehold.co/40x40/3f3f46/ffffff?text=?' ?>" alt="" class="w-10 h-10 rounded-full object-cover">
                <div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px] <?= $n['type'] === 'like' ? 'bg-red-500' : ($n['type'] === 'follow' ? 'bg-brand-500' : ($n['type'] === 'comment' ? 'bg-blue-500' : ($n['type'] === 'tip' ? 'bg-amber-500' : ($n['type'] === 'verified' || $n['type'] === 'milestone' ? 'bg-emerald-500' : 'bg-zinc-500')))) ?>">
                    <span class="material-icons-round text-[10px]"><?= $n['type'] === 'like' ? 'favorite' : ($n['type'] === 'follow' ? 'person_add' : ($n['type'] === 'comment' ? 'chat_bubble' : ($n['type'] === 'tip' ? 'monetization_on' : ($n['type'] === 'verified' || $n['type'] === 'milestone' ? 'emoji_events' : 'notifications')))) ?></span>
                </div>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-zinc-200 text-[13px] leading-relaxed"><?= $n['title'] ?></p>
                <?php if (!empty($n['body'])): ?>
                <p class="text-zinc-500 text-[11px] mt-0.5 line-clamp-1"><?= $n['body'] ?></p>
                <?php endif; ?>
                <div class="flex items-center gap-2 mt-1">
                    <span class="text-zinc-600 text-[10px]"><?= timeAgo($n['created_at']) ?></span>
                    <?php if (!$n['is_read']): ?>
                    <span class="w-1.5 h-1.5 rounded-full bg-brand-500"></span>
                    <?php endif; ?>
                </div>
            </div>
            <button onclick="event.stopPropagation();moreNotifOptions(<?= $n['id'] ?>)" class="flex-shrink-0 p-1 rounded-full hover:bg-surface-300 transition-colors self-start mt-0.5">
                <span class="material-icons-round text-zinc-600 text-lg">more_vert</span>
            </button>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($thisWeek)): ?>
    <div class="flex items-center gap-2 mb-3">
        <span class="w-1.5 h-1.5 rounded-full bg-zinc-500"></span>
        <span class="text-zinc-600 text-[10px] font-medium uppercase tracking-wider">This Week</span>
        <span class="flex-1 h-px bg-surface-400/20"></span>
    </div>
    <div class="space-y-1 mb-6">
        <?php foreach ($thisWeek as $n): ?>
        <div class="notif-row <?= $n['is_read'] ? '' : 'unread' ?> flex items-start gap-3 p-3 rounded-xl bg-surface-100/40 border border-surface-400/10 cursor-pointer" onclick="openNotification(<?= $n['id'] ?>)">
            <div class="relative flex-shrink-0">
                <img src="<?= $n['actor_avatar'] ?? 'https://placehold.co/40x40/3f3f46/ffffff?text=?' ?>" alt="" class="w-10 h-10 rounded-full object-cover">
                <div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px] <?= $n['type'] === 'like' ? 'bg-red-500' : ($n['type'] === 'follow' ? 'bg-brand-500' : ($n['type'] === 'comment' ? 'bg-blue-500' : ($n['type'] === 'tip' ? 'bg-amber-500' : ($n['type'] === 'verified' || $n['type'] === 'milestone' ? 'bg-emerald-500' : 'bg-zinc-500')))) ?>">
                    <span class="material-icons-round text-[10px]"><?= $n['type'] === 'like' ? 'favorite' : ($n['type'] === 'follow' ? 'person_add' : ($n['type'] === 'comment' ? 'chat_bubble' : ($n['type'] === 'tip' ? 'monetization_on' : ($n['type'] === 'verified' || $n['type'] === 'milestone' ? 'emoji_events' : 'notifications')))) ?></span>
                </div>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-zinc-300 text-[13px] leading-relaxed"><?= $n['title'] ?></p>
                <?php if (!empty($n['body'])): ?>
                <p class="text-zinc-500 text-[11px] mt-0.5 line-clamp-1"><?= $n['body'] ?></p>
                <?php endif; ?>
                <span class="text-zinc-600 text-[10px] mt-1 block"><?= timeAgo($n['created_at']) ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($earlier)): ?>
    <div class="flex items-center gap-2 mb-3">
        <span class="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
        <span class="text-zinc-600 text-[10px] font-medium uppercase tracking-wider">Earlier</span>
        <span class="flex-1 h-px bg-surface-400/20"></span>
    </div>
    <div class="space-y-1 mb-6">
        <?php foreach ($earlier as $n): ?>
        <div class="notif-row flex items-start gap-3 p-3 rounded-xl bg-surface-100/30 border border-surface-400/10 cursor-pointer opacity-70 hover:opacity-100 transition-opacity" onclick="openNotification(<?= $n['id'] ?>)">
            <div class="relative flex-shrink-0">
                <img src="<?= $n['actor_avatar'] ?? 'https://placehold.co/40x40/3f3f46/ffffff?text=?' ?>" alt="" class="w-10 h-10 rounded-full object-cover">
                <div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-zinc-600 flex items-center justify-center text-white text-[10px]">
                    <span class="material-icons-round text-[10px]">notifications</span>
                </div>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-zinc-400 text-[13px] leading-relaxed"><?= $n['title'] ?></p>
                <?php if (!empty($n['body'])): ?>
                <p class="text-zinc-600 text-[11px] mt-0.5 line-clamp-1"><?= $n['body'] ?></p>
                <?php endif; ?>
                <span class="text-zinc-600 text-[10px] mt-1 block"><?= timeAgo($n['created_at']) ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (empty($notifications)): ?>
    <div class="text-center py-16">
        <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-4xl">notifications_none</span>
        </div>
        <h3 class="text-white font-semibold text-base mb-1">No notifications yet</h3>
        <p class="text-zinc-500 text-xs">When you get likes, comments, and follows, they'll show up here.</p>
    </div>
    <?php endif; ?>
</div>

<script>
function markAllRead() {
    document.querySelectorAll('.notif-row.unread').forEach(r => {
        r.classList.remove('unread');
        r.style.borderLeft = 'none';
    });
    const badge = document.querySelector('.bg-brand-600\\/30');
    if (badge) badge.remove();
}

function openNotification(id) {
    const row = event.currentTarget;
    row.classList.remove('unread');
    row.style.borderLeft = 'none';
}

function moreNotifOptions(id) {
    alert('Notification options (dismiss, mute, report)');
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
