<?php $title = ($data['video']['title'] ?? 'Video') . ' - DTTube'; ?>
<?php
$video = $data['video'] ?? [];
$comments = $data['comments'] ?? [];
?>
<?php ob_start(); ?>
<div class="max-w-4xl mx-auto px-3 py-4 pb-24 lg:pb-6">
    <div class="mb-4">
        <a href="/videos" class="inline-flex items-center gap-1 text-zinc-400 text-xs hover:text-white transition-colors mb-3">
            <span class="material-icons-round text-lg">chevron_left</span>
            Back to Videos
        </a>
        <div class="relative rounded-2xl overflow-hidden bg-black mb-3">
            <div class="aspect-video flex items-center justify-center bg-gradient-to-br from-brand-900/40 to-purple-900/40">
                <img src="<?= $video['thumbnail'] ?? 'https://placehold.co/800x450/3f3f46/ffffff?text=Video' ?>" alt="" class="w-full h-full object-cover">
                <div class="absolute inset-0 flex items-center justify-center">
                    <div class="w-16 h-16 rounded-full bg-brand-600/80 backdrop-blur-sm flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                        <span class="material-icons-round text-white text-3xl">play_arrow</span>
                    </div>
                </div>
                <?php if (!empty($video['duration'])): ?>
                <div class="absolute bottom-3 right-3 px-2 py-1 rounded-lg bg-black/80 text-white text-xs font-medium">
                    <?= formatDuration($video['duration']) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <h1 class="text-white text-lg font-bold leading-snug mb-2"><?= htmlspecialchars($video['title'] ?? '') ?></h1>

        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-2">
                <img src="<?= $video['creator_avatar'] ?? 'https://placehold.co/40x40/6d28d9/ffffff?text=U' ?>" alt="" class="w-10 h-10 rounded-full">
                <div>
                    <div class="flex items-center gap-1">
                        <span class="text-white text-sm font-semibold"><?= htmlspecialchars($video['creator_name'] ?? $video['username'] ?? '') ?></span>
                        <?php if (!empty($video['is_verified'])): ?>
                        <span class="material-icons-round text-brand-400 text-sm">verified</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-zinc-500 text-[10px]"><?= formatCount($video['views'] ?? 0) ?> views<?php if (!empty($video['created_at'])): ?> · <?= timeAgo($video['created_at']) ?><?php endif; ?></span>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="likeVideo(<?= $video['id'] ?>)" class="flex items-center gap-1 px-3 py-1.5 rounded-full bg-surface-200 hover:bg-surface-300 transition-colors">
                    <span class="material-icons-round text-zinc-400 text-lg" id="videoLikeIcon">favorite_border</span>
                    <span class="text-zinc-400 text-xs" id="videoLikeCount"><?= formatCount($video['likes'] ?? 0) ?></span>
                </button>
                <button onclick="shareVideo(<?= $video['id'] ?>)" class="flex items-center gap-1 px-3 py-1.5 rounded-full bg-surface-200 hover:bg-surface-300 transition-colors">
                    <span class="material-icons-round text-zinc-400 text-lg">ios_share</span>
                    <span class="text-zinc-400 text-xs">Share</span>
                </button>
            </div>
        </div>

        <?php if (!empty($video['description'])): ?>
        <div class="bg-surface-100/40 rounded-xl p-3 mb-4">
            <p class="text-zinc-300 text-xs leading-relaxed whitespace-pre-wrap"><?= htmlspecialchars($video['description']) ?></p>
        </div>
        <?php endif; ?>
    </div>

    <div>
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-white text-sm font-bold">Comments (<?= count($comments) ?>)</h3>
        </div>
        <div class="flex items-center gap-2 mb-4">
            <input type="text" id="videoCommentInput" placeholder="Add a comment..." class="flex-1 bg-surface-200 text-white px-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500 focus:outline-none text-sm" onkeydown="if(event.key==='Enter')addVideoComment(<?= $video['id'] ?>)">
            <button onclick="addVideoComment(<?= $video['id'] ?>)" class="w-10 h-10 rounded-full gradient-brand flex items-center justify-center flex-shrink-0">
                <span class="material-icons-round text-white">send</span>
            </button>
        </div>
        <?php if (!empty($comments)): ?>
        <div class="space-y-3">
            <?php foreach ($comments as $comment): ?>
            <div class="flex gap-3">
                <img src="<?= $comment['commenter_avatar'] ?? 'https://placehold.co/32x32/3f3f46/ffffff?text=U' ?>" alt="" class="w-8 h-8 rounded-full flex-shrink-0">
                <div>
                    <div class="flex items-center gap-1">
                        <span class="text-white text-xs font-semibold"><?= htmlspecialchars($comment['commenter_name'] ?? $comment['username'] ?? '') ?></span>
                        <span class="text-zinc-600 text-[9px]"><?= timeAgo($comment['created_at'] ?? '') ?></span>
                    </div>
                    <p class="text-zinc-300 text-xs mt-0.5"><?= htmlspecialchars($comment['body'] ?? '') ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-8 bg-surface-100/30 rounded-xl border border-surface-400/10">
            <span class="material-icons-round text-zinc-500 text-3xl">chat_bubble_outline</span>
            <p class="text-zinc-500 text-xs mt-2">No comments yet. Be the first!</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function likeVideo(id) {
    const icon = document.getElementById('videoLikeIcon');
    const countEl = document.getElementById('videoLikeCount');
    if (icon.textContent === 'favorite_border') {
        icon.textContent = 'favorite';
        icon.classList.add('text-red-400');
        let c = parseInt(countEl.textContent.replace(/[^0-9]/g, '')) + 1;
        countEl.textContent = formatCount(c);
    }
    fetch('/videos/' + id + '/like', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function shareVideo(id) {
    if (navigator.share) {
        navigator.share({ title: 'Check out this video!', url: '/videos/' + id });
    } else {
        navigator.clipboard.writeText(window.location.origin + '/videos/' + id).then(() => alert('Link copied!'));
    }
    fetch('/videos/' + id + '/share', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function addVideoComment(id) {
    const input = document.getElementById('videoCommentInput');
    const body = input.value.trim();
    if (!body) return;
    input.value = '';
    fetch('/videos/' + id + '/comment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ body: body })
    }).then(r => r.json()).then(d => {
        location.reload();
    }).catch(() => {});
}

function formatCount(n) {
    n = parseInt(n) || 0;
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
