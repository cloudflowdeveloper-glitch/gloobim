<?php $title = 'Videos - DTTube'; ?>
<?php extract($data ?? []); ?>
<?php ob_start(); ?>
<div class="max-w-[1400px] mx-auto px-4 py-6 pb-24 lg:pb-6">
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <span class="material-icons-round text-brand-400 text-2xl">play_circle</span>
            <h1 class="font-display text-2xl font-bold text-white">Videos</h1>
        </div>
        <a href="/videos/create" class="inline-flex items-center gap-2 gradient-brand px-4 py-2 rounded-xl text-white text-sm font-semibold hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-lg">upload</span>
            Upload Video
        </a>
    </div>

    <?php if (!empty($videos)): ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php foreach ($videos as $video): ?>
        <a href="/videos/<?= $video['id'] ?>" class="group block">
            <div class="relative rounded-xl overflow-hidden mb-2.5 hover-scale">
                <img src="<?= $video['thumbnail'] ?>" alt="<?= $video['title'] ?>" class="w-full aspect-video object-cover">
                <div class="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-medium">
                    <?= formatDuration($video['duration'] ?? 0) ?>
                </div>
                <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div class="w-12 h-12 rounded-full bg-brand-600/80 backdrop-blur-sm flex items-center justify-center">
                        <span class="material-icons-round text-white text-2xl">play_arrow</span>
                    </div>
                </div>
            </div>
            <div class="flex gap-3">
                <img src="<?= $video['creator_avatar'] ?? 'https://placehold.co/36x36/3f3f46/ffffff?text=C' ?>" class="w-9 h-9 rounded-full flex-shrink-0 mt-0.5">
                <div class="min-w-0 flex-1">
                    <h3 class="text-white text-sm font-semibold line-clamp-2 leading-snug"><?= $video['title'] ?></h3>
                    <div class="flex items-center gap-1 mt-0.5">
                        <span class="text-zinc-500 text-xs"><?= $video['creator_name'] ?? $video['username'] ?></span>
                        <?php if (!empty($video['is_verified'])): ?>
                        <span class="material-icons-round text-brand-500 text-xs">verified</span>
                        <?php endif; ?>
                    </div>
                    <div class="flex items-center gap-1.5 mt-0.5">
                        <span class="text-zinc-600 text-[11px]"><?= formatCount($video['views']) ?> views</span>
                        <?php if (!empty($video['created_at'])): ?>
                        <span class="text-zinc-600 text-[11px]">· <?= timeAgo($video['created_at']) ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="flex items-center justify-center h-64">
        <div class="text-center">
            <span class="material-icons-round text-surface-400 text-6xl">play_circle</span>
            <p class="text-zinc-400 mt-4">No videos available yet</p>
            <p class="text-zinc-500 text-sm mt-1">Upload the first video!</p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
