<?php $activeTab = 'music'; $title = 'Music - DTTube'; ?>
<?php ob_start(); ?>
<style>
    @keyframes visualizer { 0%,100% { transform: scaleY(0.4); } 50% { transform: scaleY(1); } }
    .viz-bar { animation: visualizer 1.2s ease-in-out infinite; transform-origin: bottom; }
    .viz-bar:nth-child(1) { animation-delay: 0s; height: 14px; }
    .viz-bar:nth-child(2) { animation-delay: 0.15s; height: 22px; }
    .viz-bar:nth-child(3) { animation-delay: 0.3s; height: 10px; }
    .viz-bar:nth-child(4) { animation-delay: 0.45s; height: 18px; }
    @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }
    .marquee-text { overflow: hidden; white-space: nowrap; }
    .marquee-text > span { display: inline-block; animation: marquee 12s linear infinite; }
    .scroll-snap-x { scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; }
    .scroll-snap-x > * { scroll-snap-align: start; }
    .hero-glow { box-shadow: 0 0 40px rgba(168,85,247,0.15), inset 0 0 40px rgba(168,85,247,0.05); }
    .card-hover { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
    .card-hover:hover { transform: translateY(-4px); }
    .playlist-card { transition: all 0.3s ease; }
    .playlist-card:hover { transform: scale(1.03); }
    .now-playing-bar { background: linear-gradient(135deg, rgba(24,24,27,0.98), rgba(15,15,19,0.98)); backdrop-filter: blur(24px); border-top: 1px solid rgba(168,85,247,0.15); }
    .category-pill { transition: all 0.25s ease; }
    .category-pill:hover { background: rgba(168,85,247,0.2); color: #c084fc; }
    .category-pill.active { background: linear-gradient(135deg, #9333ea, #6d28d9); color: white; box-shadow: 0 4px 15px rgba(147,51,234,0.3); }
    @keyframes pulse-glow { 0%,100% { box-shadow: 0 0 15px rgba(168,85,247,0.3); } 50% { box-shadow: 0 0 30px rgba(168,85,247,0.6); } }
    .glow-pulse { animation: pulse-glow 2s ease-in-out infinite; }
    .chart-number { font-feature-settings: "tnum"; }
</style>

<div class="max-w-lg mx-auto pb-4">
    <div class="px-3 pt-3 pb-1">
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center shadow-lg shadow-brand-500/30">
                    <span class="material-icons-round text-white text-lg">music_note</span>
                </div>
                <h1 class="font-display text-xl font-bold text-white tracking-tight">GLOBIIM Music</h1>
            </div>
            <div class="flex items-center gap-2">
                <button class="w-9 h-9 rounded-full bg-surface-200/80 flex items-center justify-center hover:bg-surface-300 transition-colors relative">
                    <span class="material-icons-round text-zinc-300 text-[20px]">notifications_none</span>
                    <span class="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <div class="w-8 h-8 rounded-full overflow-hidden border-2 border-brand-500/60">
                    <img src="https://placehold.co/80x80/6d28d9/ffffff?text=U" alt="Profile" class="w-full h-full object-cover">
                </div>
            </div>
        </div>

        <div class="flex items-center gap-2 mb-4">
            <div class="relative flex-1">
                <span class="material-icons-round absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-lg">search</span>
                <input type="text" placeholder="Search songs, artists, albums..." class="w-full bg-surface-200/80 text-white pl-10 pr-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-all">
            </div>
            <button class="w-11 h-11 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all">
                <div class="flex items-end gap-0.5 h-full py-2.5">
                    <div class="viz-bar w-1 bg-white rounded-full"></div>
                    <div class="viz-bar w-1 bg-white rounded-full"></div>
                    <div class="viz-bar w-1 bg-white rounded-full"></div>
                    <div class="viz-bar w-1 bg-white rounded-full"></div>
                </div>
            </button>
        </div>

        <div class="flex gap-2 overflow-x-auto scrollbar-hide pb-1 scroll-snap-x">
            <button class="category-pill active flex-shrink-0 px-5 py-2 rounded-full text-xs font-bold">Hot Hits</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">Trending</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">Afrobeats</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">Gospel</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">Chill</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">Podcasts</button>
            <button class="category-pill flex-shrink-0 px-5 py-2 rounded-full bg-surface-200/80 text-zinc-400 text-xs font-medium border border-surface-400/30">More</button>
        </div>
    </div>

    <?php $feat = $featured ?? ['title' => 'African Heat 2025', 'description' => 'Hottest African tracks right now', 'cover_url' => 'https://placehold.co/400x400/7c3aed/ffffff?text=African+Heat', 'author' => 'DTTube Music']; ?>
    <div class="px-3 py-3">
        <div class="relative rounded-2xl overflow-hidden hero-glow">
            <img src="<?= $feat['cover_url'] ?>" alt="<?= $feat['title'] ?>" class="w-full aspect-[2/1] object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-purple-900/30 to-transparent"></div>
            <div class="absolute bottom-0 left-0 right-0 p-4">
                <span class="text-[10px] font-semibold text-purple-300 uppercase tracking-wider">Featured Playlist</span>
                <h2 class="font-display text-xl font-bold text-white mt-0.5"><?= $feat['title'] ?></h2>
                <p class="text-zinc-300 text-xs mt-0.5"><?= $feat['description'] ?></p>
                <div class="flex items-center justify-between mt-3">
                    <div class="flex items-center gap-3">
                        <button class="px-5 py-2 rounded-full gradient-brand text-white text-xs font-bold shadow-lg shadow-brand-500/30 hover:opacity-90 transition-opacity glow-pulse">
                            <span class="flex items-center gap-1.5">
                                <span class="material-icons-round text-[18px]">play_arrow</span>
                                Listen Now
                            </span>
                        </button>
                        <div class="flex items-center gap-1 text-zinc-400">
                            <span class="material-icons-round text-[16px]">headphones</span>
                            <span class="text-[11px] font-medium">12.4K</span>
                        </div>
                    </div>
                    <button class="w-9 h-9 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-white/20 transition-colors">
                        <span class="material-icons-round text-white text-xl">favorite_border</span>
                    </button>
                </div>
            </div>
        </div>
        <div class="flex items-center justify-center gap-1.5 mt-3">
            <span class="w-2 h-2 rounded-full bg-brand-500"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
            <span class="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
        </div>
    </div>

    <div class="px-3 py-1">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-white text-sm font-bold">Recently Played</h2>
            <a href="#" class="text-brand-400 text-[10px] font-semibold">See all</a>
        </div>
        <div class="flex gap-3 overflow-x-auto scrollbar-hide pb-1 scroll-snap-x">
            <?php foreach (array_slice(array_merge($trending, $recent), 0, 6) as $i => $track): ?>
            <div class="flex-shrink-0 w-32" onclick="playTrack(<?= $i ?>)">
                <div class="relative rounded-xl overflow-hidden mb-2 card-hover cursor-pointer group">
                    <img src="<?= $track['cover_url'] ?>" alt="<?= $track['title'] ?>" class="w-full aspect-square object-cover">
                    <div class="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div class="w-10 h-10 rounded-full gradient-brand flex items-center justify-center shadow-lg shadow-brand-500/40">
                            <span class="material-icons-round text-white text-2xl">play_arrow</span>
                        </div>
                    </div>
                    <?php if ($i < 2): ?>
                    <div class="absolute bottom-1.5 left-1.5 flex items-center gap-0.5 bg-black/50 backdrop-blur-sm rounded-md px-1.5 py-0.5">
                        <div class="w-1 h-1 rounded-full bg-green-400"></div>
                        <span class="text-[8px] text-green-400 font-medium">Now</span>
                    </div>
                    <?php endif; ?>
                </div>
                <span class="text-white text-[11px] font-semibold truncate block"><?= $track['title'] ?></span>
                <span class="text-zinc-500 text-[9px] truncate block"><?= $track['artist_name'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="px-3 py-3">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-white text-sm font-bold">Trending Songs</h2>
            <a href="#" class="text-brand-400 text-[10px] font-semibold">See all</a>
        </div>
        <div class="bg-surface-100/60 rounded-2xl border border-surface-400/15 overflow-hidden">
            <?php foreach ($trending as $i => $track): ?>
            <div class="flex items-center gap-3 p-2.5 <?= $i < count($trending) - 1 ? 'border-b border-surface-400/10' : '' ?> cursor-pointer hover:bg-surface-200/60 transition-colors" onclick="playTrack(<?= $i ?>)" data-index="<?= $i ?>">
                <span class="chart-number w-6 text-center text-sm font-bold <?= $i < 3 ? 'text-brand-400' : 'text-zinc-500' ?>"><?= $i + 1 ?></span>
                <div class="relative flex-shrink-0">
                    <img src="<?= $track['cover_url'] ?>" alt="<?= $track['title'] ?>" class="w-11 h-11 rounded-xl object-cover">
                    <div class="absolute inset-0 rounded-xl bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <span class="material-icons-round text-white text-lg">play_arrow</span>
                    </div>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-1">
                        <span class="text-white text-xs font-semibold truncate"><?= $track['title'] ?></span>
                        <?php if (!empty($track['is_verified'])): ?>
                        <span class="material-icons-round text-brand-400 text-[12px] flex-shrink-0">verified</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-zinc-500 text-[10px]"><?= $track['artist_name'] ?></span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-zinc-600 text-[10px] flex-shrink-0"><?= floor($track['duration'] / 60) ?>:<?= str_pad($track['duration'] % 60, 2, '0', STR_PAD_LEFT) ?></span>
                    <button onclick="event.stopPropagation();moreOptions(<?= $track['id'] ?>)" class="p-1 rounded-full hover:bg-surface-300 transition-colors flex-shrink-0">
                        <span class="material-icons-round text-zinc-500 text-lg">more_vert</span>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="px-3 py-1">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-white text-sm font-bold">Recommended Playlists</h2>
            <a href="#" class="text-brand-400 text-[10px] font-semibold">Show all</a>
        </div>
        <div class="flex gap-3 overflow-x-auto scrollbar-hide pb-1 scroll-snap-x">
            <?php foreach ($playlists as $playlist): ?>
            <div class="flex-shrink-0 w-36 playlist-card cursor-pointer group" onclick="openPlaylist(<?= $playlist['id'] ?>)">
                <div class="relative rounded-2xl overflow-hidden mb-2">
                    <img src="<?= $playlist['cover_url'] ?>" alt="<?= $playlist['name'] ?>" class="w-full aspect-square object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                    <div class="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div class="w-12 h-12 rounded-full gradient-brand flex items-center justify-center shadow-lg shadow-brand-500/40">
                            <span class="material-icons-round text-white text-2xl">play_arrow</span>
                        </div>
                    </div>
                    <div class="absolute top-2 right-2 bg-black/50 backdrop-blur-sm rounded-full px-2 py-0.5">
                        <span class="text-white text-[9px] font-medium"><?= $playlist['track_count'] ?> tracks</span>
                    </div>
                </div>
                <span class="text-white text-[11px] font-semibold truncate block"><?= $playlist['name'] ?></span>
                <div class="flex items-center gap-1 text-zinc-500">
                    <span class="material-icons-round text-[12px]">headphones</span>
                    <span class="text-[9px]"><?= rand(1, 50) ?>K listeners</span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div id="nowPlaying" class="now-playing-bar fixed bottom-14 left-0 right-0 z-40 px-3 py-2.5 hidden">
    <div class="max-w-lg mx-auto flex items-center gap-3">
        <img id="npCover" src="" alt="" class="w-11 h-11 rounded-xl object-cover flex-shrink-0 shadow-lg">
        <div class="flex-1 min-w-0">
            <span id="npTitle" class="text-white text-sm font-semibold truncate block"></span>
            <span id="npArtist" class="text-zinc-400 text-[11px]"></span>
        </div>
        <div class="flex items-center gap-1">
            <button onclick="prevTrack()" class="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-300 transition-colors">
                <span class="material-icons-round text-zinc-300 text-xl">skip_previous</span>
            </button>
            <button onclick="togglePlay()" class="w-10 h-10 rounded-full gradient-brand flex items-center justify-center shadow-lg shadow-brand-500/30 glow-pulse">
                <span class="material-icons-round text-white text-2xl" id="playIcon">play_arrow</span>
            </button>
            <button onclick="nextTrack()" class="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-300 transition-colors">
                <span class="material-icons-round text-zinc-300 text-xl">skip_next</span>
            </button>
            <button onclick="openQueue()" class="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-300 transition-colors">
                <span class="material-icons-round text-zinc-400 text-xl">queue_music</span>
            </button>
        </div>
    </div>
    <div class="max-w-lg mx-auto mt-1.5 px-1">
        <div class="h-1 rounded-full bg-surface-400/30 overflow-hidden">
            <div class="h-full rounded-full bg-gradient-to-r from-brand-500 to-pink-500 transition-all duration-1000" id="progressBar" style="width: 0%"></div>
        </div>
    </div>
</div>

<script>
const allTracks = <?= json_encode(array_merge($trending, $recent)) ?>;
let currentTrackIndex = -1;
let isPlaying = false;
let progressInterval = null;
let progress = 0;

function playTrack(index) {
    const track = allTracks[index];
    if (!track) return;
    currentTrackIndex = index;
    document.querySelectorAll('[data-index]').forEach(r => r.classList.remove('active'));
    const row = document.querySelector(`[data-index="${index}"]`);
    if (row) row.classList.add('active');

    const player = document.getElementById('nowPlaying');
    player.classList.remove('hidden');
    document.getElementById('npCover').src = track.cover_url;
    document.getElementById('npTitle').textContent = track.title;
    document.getElementById('npArtist').textContent = track.artist_name;
    document.getElementById('playIcon').textContent = 'pause_arrow';
    isPlaying = true;
    progress = 0;
    clearInterval(progressInterval);
    progressInterval = setInterval(() => {
        progress += 1;
        const pct = Math.min((progress / track.duration) * 100, 99);
        document.getElementById('progressBar').style.width = pct + '%';
        if (progress >= track.duration) {
            clearInterval(progressInterval);
            document.getElementById('playIcon').textContent = 'play_arrow';
            isPlaying = false;
        }
    }, 1000);
}

function togglePlay() {
    if (currentTrackIndex < 0) { playTrack(0); return; }
    const icon = document.getElementById('playIcon');
    if (isPlaying) {
        icon.textContent = 'play_arrow';
        isPlaying = false;
        clearInterval(progressInterval);
    } else {
        icon.textContent = 'pause_arrow';
        isPlaying = true;
        const track = allTracks[currentTrackIndex];
        progressInterval = setInterval(() => {
            progress += 1;
            const pct = Math.min((progress / track.duration) * 100, 99);
            document.getElementById('progressBar').style.width = pct + '%';
            if (progress >= track.duration) {
                clearInterval(progressInterval);
                document.getElementById('playIcon').textContent = 'play_arrow';
                isPlaying = false;
            }
        }, 1000);
    }
}

function nextTrack() {
    if (currentTrackIndex < allTracks.length - 1) playTrack(currentTrackIndex + 1);
    else playTrack(0);
}

function prevTrack() {
    if (progress > 3) { progress = 0; document.getElementById('progressBar').style.width = '0%'; return; }
    if (currentTrackIndex > 0) playTrack(currentTrackIndex - 1);
    else playTrack(allTracks.length - 1);
}

function openQueue() {
    alert('Queue view coming soon!');
}

function moreOptions(id) {
    const track = allTracks.find(t => t.id === id);
    if (track) alert('More options for: ' + track.title);
}

function openPlaylist(id) {
    alert('Opening playlist...');
}

document.querySelectorAll('.category-pill').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.category-pill').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === ' ' && currentTrackIndex >= 0) { e.preventDefault(); togglePlay(); }
});
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
