<?php $activeTab = 'post'; $title = 'Posts - DTTube'; ?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center justify-between mb-5">
        <h1 class="font-display text-lg font-bold text-white">Posts</h1>
        <a href="/posts/create" class="w-9 h-9 rounded-full gradient-brand flex items-center justify-center hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-white text-lg">add</span>
        </a>
    </div>

    <?php if (!empty($posts)): ?>
        <div class="space-y-4">
            <?php foreach ($posts as $post): ?>
            <a href="/posts/<?= $post['id'] ?>" class="block bg-surface-100/30 rounded-2xl overflow-hidden border border-surface-400/10 hover:border-surface-400/30 transition-all">
                <div class="flex items-center justify-between px-4 pt-4 pb-2">
                    <div class="flex items-center gap-2.5">
                        <img src="<?= $post['creator_avatar'] ?>" alt="" class="w-9 h-9 rounded-full">
                        <div>
                            <div class="flex items-center gap-1">
                                <span class="text-white text-xs font-semibold"><?= $post['creator_name'] ?></span>
                                <?php if (!empty($post['is_verified'])): ?>
                                <span class="material-icons-round text-brand-400 text-[12px]">verified</span>
                                <?php endif; ?>
                            </div>
                            <span class="text-zinc-600 text-[10px]"><?= $post['username'] ?> · <?= timeAgo($post['created_at']) ?></span>
                        </div>
                    </div>
                    <span class="material-icons-round text-zinc-600 text-lg">more_horiz</span>
                </div>

                <?php if (!empty($post['image_url'])): ?>
                <div class="px-0">
                    <img src="<?= $post['image_url'] ?>" alt="" class="w-full max-h-[400px] object-cover">
                </div>
                <?php endif; ?>

                <div class="px-4 pb-3">
                    <p class="text-zinc-200 text-[13px] leading-relaxed mt-2 line-clamp-3"><?= htmlspecialchars($post['content']) ?></p>
                </div>

                <div class="flex items-center gap-4 px-4 py-2.5 border-t border-surface-400/10">
                    <div class="flex items-center gap-1 text-zinc-500">
                        <span class="material-icons-round text-[16px]">favorite_border</span>
                        <span class="text-[10px]"><?= formatCount($post['likes'] ?? 0) ?></span>
                    </div>
                    <div class="flex items-center gap-1 text-zinc-500">
                        <span class="material-icons-round text-[16px]">chat_bubble_outline</span>
                        <span class="text-[10px]"><?= formatCount($post['comments_count'] ?? 0) ?></span>
                    </div>
                    <div class="flex items-center gap-1 text-zinc-500">
                        <span class="material-icons-round text-[16px]">ios_share</span>
                        <span class="text-[10px]"><?= formatCount($post['shares'] ?? 0) ?></span>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
    <div class="text-center py-16">
        <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-4xl">article</span>
        </div>
        <h3 class="text-white font-semibold text-base mb-1">No posts yet</h3>
        <p class="text-zinc-500 text-xs mb-4">Be the first to share something!</p>
        <a href="/posts/create" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-sm font-semibold hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-lg">add</span>
            Create Post
        </a>
    </div>
    <?php endif; ?>
</div>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
