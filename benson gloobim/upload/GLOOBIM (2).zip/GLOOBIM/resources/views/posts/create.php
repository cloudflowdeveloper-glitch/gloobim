<?php $activeTab = 'post'; $title = 'Create - DTTube'; ?>
<?php ob_start(); ?>
<style>
    @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
    .float-anim { animation: float 3s ease-in-out infinite; }
    @keyframes glow-pulse { 0%,100% { box-shadow: 0 0 15px rgba(168,85,247,0.3), 0 0 30px rgba(168,85,247,0.1); } 50% { box-shadow: 0 0 30px rgba(168,85,247,0.6), 0 0 60px rgba(168,85,247,0.2); } }
    .glow-pulse { animation: glow-pulse 2s ease-in-out infinite; }
    @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
    .shimmer { background: linear-gradient(90deg, rgba(168,85,247,0.1), rgba(236,72,153,0.2), rgba(168,85,247,0.1)); background-size: 200% 100%; animation: shimmer 3s ease-in-out infinite; }
    .content-card { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
    .content-card:hover { transform: translateY(-4px) scale(1.02); }
    .scroll-snap-x { scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; }
    .scroll-snap-x > * { scroll-snap-align: start; }
    .ai-glow { box-shadow: 0 0 40px rgba(168,85,247,0.2), inset 0 0 30px rgba(168,85,247,0.05); }
    .draft-card { transition: all 0.3s ease; }
    .draft-card:hover { transform: scale(1.03); }
    .grid-item { transition: all 0.25s ease; }
    .grid-item:hover { background: rgba(168,85,247,0.1); border-color: rgba(168,85,247,0.3); transform: translateY(-2px); }
    .badge-neon { background: linear-gradient(135deg, rgba(168,85,247,0.3), rgba(236,72,153,0.3)); border: 1px solid rgba(168,85,247,0.3); }
</style>

<div class="max-w-lg mx-auto pb-4">
    <div class="px-3 pt-2 pb-1">
        <div class="flex items-center justify-between mb-1">
            <a href="/" class="w-9 h-9 rounded-full bg-surface-200/80 flex items-center justify-center hover:bg-surface-300 transition-colors">
                <span class="material-icons-round text-zinc-400 text-xl">close</span>
            </a>
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-full overflow-hidden border-2 border-brand-500/60">
                    <img src="https://placehold.co/80x80/6d28d9/ffffff?text=U" alt="Profile" class="w-full h-full object-cover">
                </div>
                <div class="relative">
                    <div class="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-pink-500 flex items-center justify-center glow-pulse">
                        <span class="material-icons-round text-white text-lg">auto_awesome</span>
                    </div>
                    <span class="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-surface-50"></span>
                </div>
            </div>
        </div>
        <h1 class="font-display text-2xl font-bold text-white mt-3">Create</h1>
        <p class="text-zinc-500 text-sm mt-0.5">What do you want to create today?</p>
    </div>

    <div class="flex gap-2.5 overflow-x-auto scrollbar-hide px-3 py-3 scroll-snap-x">
        <div class="flex-shrink-0 w-32 bg-surface-100/80 rounded-xl border border-surface-400/20 p-3">
            <div class="flex items-center gap-1.5 mb-1.5">
                <span class="w-2 h-2 rounded-full bg-green-400"></span>
                <span class="text-green-400 text-[9px] font-semibold">Active</span>
            </div>
            <span class="text-zinc-400 text-[10px]">Data Saver</span>
            <span class="text-white text-xs font-bold block">70% saved</span>
        </div>
        <div class="flex-shrink-0 w-32 bg-surface-100/80 rounded-xl border border-surface-400/20 p-3">
            <div class="flex items-center gap-1.5 mb-1.5">
                <span class="material-icons-round text-brand-400 text-[14px]">cloud_upload</span>
                <span class="text-brand-400 text-[9px] font-semibold">Estimate</span>
            </div>
            <span class="text-zinc-400 text-[10px]">Upload time</span>
            <span class="text-white text-xs font-bold block">~2 min</span>
        </div>
        <div class="flex-shrink-0 w-36 bg-surface-100/80 rounded-xl border border-surface-400/20 p-3">
            <div class="flex items-center gap-1.5 mb-1.5">
                <span class="material-icons-round text-pink-400 text-[14px]">trending_up</span>
                <span class="text-pink-400 text-[9px] font-semibold">Trending</span>
            </div>
            <span class="text-zinc-400 text-[10px]">#Hashtag</span>
            <span class="text-white text-xs font-bold block truncate">#DTTubeCreator</span>
        </div>
    </div>

    <div class="px-3 py-1">
        <h2 class="text-white text-sm font-bold mb-3">Popular Content</h2>
        <div class="grid grid-cols-2 gap-3">
            <a href="/reels/create" class="content-card bg-gradient-to-br from-purple-600/30 to-purple-900/30 rounded-2xl border border-purple-500/20 p-4 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-purple-500/30 flex items-center justify-center mb-3">
                    <span class="material-icons-round text-purple-300 text-xl">smart_display</span>
                </div>
                <span class="text-white text-sm font-bold block">Reel / Short</span>
                <span class="text-zinc-400 text-[10px] mt-0.5 block leading-relaxed">Short-form vertical video with music & effects</span>
                <div class="mt-2 inline-flex items-center gap-1 badge-neon rounded-full px-2 py-0.5">
                    <span class="text-[9px] text-brand-300 font-medium">15-60s</span>
                </div>
            </a>
            <a href="/posts/create/video" class="content-card bg-gradient-to-br from-blue-600/30 to-blue-900/30 rounded-2xl border border-blue-500/20 p-4 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-blue-500/30 flex items-center justify-center mb-3">
                    <span class="material-icons-round text-blue-300 text-xl">videocam</span>
                </div>
                <span class="text-white text-sm font-bold block">Video</span>
                <span class="text-zinc-400 text-[10px] mt-0.5 block leading-relaxed">Long-form HD video content with chapters</span>
                <div class="mt-2 inline-flex items-center gap-1 badge-neon rounded-full px-2 py-0.5">
                    <span class="text-[9px] text-brand-300 font-medium">Up to 4K</span>
                </div>
            </a>
            <a href="/livestream/start" class="content-card bg-gradient-to-br from-red-600/30 to-red-900/30 rounded-2xl border border-red-500/20 p-4 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-red-500/30 flex items-center justify-center mb-3">
                    <span class="material-icons-round text-red-300 text-xl">sensors</span>
                </div>
                <span class="text-white text-sm font-bold block">Go Live</span>
                <span class="text-zinc-400 text-[10px] mt-0.5 block leading-relaxed">Real-time streaming with chat & gifts</span>
                <div class="mt-2 inline-flex items-center gap-1 bg-red-500/30 rounded-full px-2 py-0.5 border border-red-500/30">
                    <span class="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                    <span class="text-[9px] text-red-300 font-medium">Live</span>
                </div>
            </a>
            <a href="/posts/create/photo" class="content-card bg-gradient-to-br from-emerald-600/30 to-emerald-900/30 rounded-2xl border border-emerald-500/20 p-4 cursor-pointer group">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/30 flex items-center justify-center mb-3">
                    <span class="material-icons-round text-emerald-300 text-xl">photo_camera</span>
                </div>
                <span class="text-white text-sm font-bold block">Photo</span>
                <span class="text-zinc-400 text-[10px] mt-0.5 block leading-relaxed">High-res images with filters & editing</span>
                <div class="mt-2 inline-flex items-center gap-1 badge-neon rounded-full px-2 py-0.5">
                    <span class="text-[9px] text-brand-300 font-medium">4K + RAW</span>
                </div>
            </a>
        </div>
    </div>

    <div class="px-3 py-3">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-white text-sm font-bold">More Ways to Create</h2>
            <button class="text-brand-400 text-[10px] font-semibold">View all</button>
        </div>
        <div class="grid grid-cols-4 gap-2.5">
            <?php
            $moreItems = [
                ['Podcast', 'mic', 'from-orange-500/30 to-orange-600/20', 'text-orange-300'],
                ['Audio Room', 'headset_mic', 'from-pink-500/30 to-pink-600/20', 'text-pink-300'],
                ['Music Upload', 'music_note', 'from-purple-500/30 to-purple-600/20', 'text-purple-300'],
                ['Live Shopping', 'shopping_bag', 'from-cyan-500/30 to-cyan-600/20', 'text-cyan-300'],
                ['Product Selling', 'sell', 'from-yellow-500/30 to-yellow-600/20', 'text-yellow-300'],
                ['Course Creation', 'school', 'from-blue-500/30 to-blue-600/20', 'text-blue-300'],
                ['Event Creation', 'event', 'from-rose-500/30 to-rose-600/20', 'text-rose-300'],
                ['Community', 'groups', 'from-teal-500/30 to-teal-600/20', 'text-teal-300'],
                ['Template', 'dashboard', 'from-indigo-500/30 to-indigo-600/20', 'text-indigo-300'],
                ['Text Post', 'article', 'from-zinc-500/30 to-zinc-600/20', 'text-zinc-300'],
                ['Poll', 'poll', 'from-amber-500/30 to-amber-600/20', 'text-amber-300'],
                ['Document Upload', 'description', 'from-violet-500/30 to-violet-600/20', 'text-violet-300'],
            ];
            foreach ($moreItems as $item):
            ?>
            <a href="#" class="grid-item flex flex-col items-center gap-1.5 p-3 rounded-xl bg-surface-100/60 border border-surface-400/15 cursor-pointer">
                <div class="w-9 h-9 rounded-xl <?= $item[2] ?> flex items-center justify-center">
                    <span class="material-icons-round <?= $item[3] ?> text-xl"><?= $item[1] ?></span>
                </div>
                <span class="text-zinc-300 text-[8px] font-medium text-center leading-tight"><?= $item[0] ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="px-3 py-2">
        <div class="relative rounded-2xl overflow-hidden ai-glow bg-gradient-to-br from-purple-900/60 via-brand-900/40 to-pink-900/60 border border-brand-500/20">
            <div class="shimmer absolute inset-0 pointer-events-none"></div>
            <div class="relative p-5 flex items-center gap-4">
                <div class="flex-shrink-0">
                    <div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-brand-400 to-pink-500 flex items-center justify-center float-anim shadow-xl shadow-brand-500/30">
                        <span class="material-icons-round text-white text-4xl">auto_awesome</span>
                    </div>
                </div>
                <div class="flex-1">
                    <span class="text-[10px] font-semibold text-brand-300 uppercase tracking-wider">AI Creator Suite</span>
                    <h3 class="font-display text-base font-bold text-white mt-0.5">Create with AI</h3>
                    <p class="text-zinc-400 text-[11px] mt-0.5 leading-relaxed">Generate scripts, thumbnails, captions & more using advanced AI</p>
                    <button class="mt-3 px-5 py-2 rounded-full gradient-brand text-white text-xs font-bold shadow-lg shadow-brand-500/30 hover:opacity-90 transition-opacity glow-pulse">
                        <span class="flex items-center gap-1.5">
                            <span class="material-icons-round text-[16px]">bolt</span>
                            Try AI Suite
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="px-3 py-2">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-white text-sm font-bold">Drafts</h2>
            <a href="#" class="text-brand-400 text-[10px] font-semibold">See all</a>
        </div>
        <div class="flex gap-3 overflow-x-auto scrollbar-hide pb-1 scroll-snap-x">
            <div class="flex-shrink-0 w-28">
                <div class="aspect-[3/4] rounded-xl border-2 border-dashed border-surface-400/30 flex flex-col items-center justify-center cursor-pointer hover:border-brand-500/50 transition-colors bg-surface-100/40">
                    <span class="material-icons-round text-zinc-500 text-3xl">add</span>
                    <span class="text-zinc-500 text-[10px] font-medium mt-1">New Draft</span>
                </div>
            </div>
            <?php
            $drafts = [
                ['thumb' => 'https://placehold.co/200x300/7c3aed/ffffff?text=Draft+1', 'title' => 'Weekly Vlog', 'duration' => '12:34', 'time' => '2h ago'],
                ['thumb' => 'https://placehold.co/200x300/d97706/ffffff?text=Draft+2', 'title' => 'Tutorial', 'duration' => '28:15', 'time' => '5h ago'],
                ['thumb' => 'https://placehold.co/200x300/06b6d4/ffffff?text=Draft+3', 'title' => 'Music Video', 'duration' => '4:20', 'time' => '1d ago'],
            ];
            foreach ($drafts as $draft):
            ?>
            <div class="flex-shrink-0 w-28 draft-card cursor-pointer group">
                <div class="relative rounded-xl overflow-hidden mb-1.5 aspect-[3/4]">
                    <img src="<?= $draft['thumb'] ?>" alt="<?= $draft['title'] ?>" class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors"></div>
                    <div class="absolute bottom-1.5 left-1.5 bg-black/70 backdrop-blur-sm rounded-md px-1.5 py-0.5">
                        <span class="text-white text-[9px] font-medium"><?= $draft['duration'] ?></span>
                    </div>
                    <div class="absolute top-1.5 right-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button class="w-7 h-7 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80 transition-colors">
                            <span class="material-icons-round text-white text-sm">more_vert</span>
                        </button>
                    </div>
                </div>
                <span class="text-white text-[10px] font-semibold truncate block"><?= $draft['title'] ?></span>
                <span class="text-zinc-500 text-[8px]">Updated <?= $draft['time'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.content-card').forEach(card => {
    card.addEventListener('click', function(e) {
        if (e.target.closest('a')) return;
        const link = this.closest('a');
        if (link) window.location.href = link.href;
    });
});
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
