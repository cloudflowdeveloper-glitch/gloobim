<?php $activeTab = 'stream'; $title = 'Live - DTTube'; ?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto">

    <div class="px-3 pt-3 pb-2 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 bg-red-500 rounded-full pulse-live"></span>
            <h1 class="font-display text-lg font-bold text-white">Live</h1>
        </div>
        <a href="/livestream/start" class="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 px-4 py-1.5 rounded-full text-white text-xs font-semibold transition-colors">
            <span class="material-icons-round text-[16px]">sensors</span>
            Go Live
        </a>
    </div>

    <?php if (!empty($liveStreams)): ?>
    <section class="px-3 py-2">
        <div class="flex items-center gap-2 mb-3">
            <span class="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
            <span class="text-zinc-400 text-xs font-medium"><?= count($liveStreams) ?> stream<?= count($liveStreams) > 1 ? 's' : '' ?> live now</span>
        </div>
        <div class="space-y-3">
            <?php foreach ($liveStreams as $stream): ?>
            <a href="/livestream/<?= $stream['id'] ?>" class="group block bg-surface-100/60 rounded-2xl overflow-hidden border border-surface-400/15 hover:border-brand-500/30 transition-all hover-scale">
                <div class="relative">
                    <img src="<?= $stream['thumbnail'] ?>" alt="<?= $stream['title'] ?>" class="w-full aspect-video object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                    <div class="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                        <span class="flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold">
                            <span class="w-1.5 h-1.5 bg-white rounded-full pulse-live"></span>
                            LIVE
                        </span>
                        <span class="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-black/60 text-white text-[10px]">
                            <span class="material-icons-round text-[12px]">visibility</span>
                            <?= formatCount($stream['viewers']) ?>
                        </span>
                    </div>
                    <?php if (($stream['total_gifts'] ?? 0) > 0): ?>
                    <div class="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-amber-500/80 text-white text-[10px] font-medium flex items-center gap-0.5">
                        <span class="material-icons-round text-[12px]">cards</span>
                        <?= $stream['total_gifts'] ?>
                    </div>
                    <?php endif; ?>
                    <div class="absolute bottom-2.5 left-2.5 right-2.5">
                        <h3 class="text-white text-sm font-bold leading-tight line-clamp-1"><?= $stream['title'] ?></h3>
                        <?php if (!empty($stream['description'])): ?>
                        <p class="text-white/60 text-[11px] mt-0.5 line-clamp-1"><?= $stream['description'] ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="p-3 flex items-center gap-2.5">
                    <img src="<?= $stream['creator_avatar'] ?>" alt="<?= $stream['creator_name'] ?>" class="w-8 h-8 rounded-full">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-1">
                            <span class="text-white text-xs font-semibold"><?= $stream['creator_name'] ?></span>
                            <?php if (!empty($stream['is_verified'])): ?>
                            <span class="material-icons-round text-brand-400 text-[12px]">verified</span>
                            <?php endif; ?>
                        </div>
                        <span class="text-zinc-500 text-[10px]"><?= $stream['username'] ?></span>
                    </div>
                    <span class="text-zinc-500 text-[10px]"><?= timeAgo($stream['started_at']) ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php else: ?>
    <div class="px-3 py-12">
        <div class="text-center">
            <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-surface-200/80 flex items-center justify-center">
                <span class="material-icons-round text-surface-400 text-4xl">sensors</span>
            </div>
            <h3 class="text-white font-semibold text-base mb-1">No live streams right now</h3>
            <p class="text-zinc-500 text-xs">Be the first to go live and connect with your audience!</p>
            <a href="/livestream/start" class="inline-flex items-center gap-1.5 mt-4 bg-red-600 hover:bg-red-700 px-5 py-2 rounded-full text-white text-sm font-semibold transition-colors">
                <span class="material-icons-round text-[18px]">sensors</span>
                Go Live Now
            </a>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($scheduledStreams)): ?>
    <section class="px-3 py-3 border-t border-surface-400/20">
        <div class="flex items-center gap-2 mb-3">
            <span class="material-icons-round text-zinc-500 text-lg">schedule</span>
            <h2 class="font-display text-sm font-bold text-white">Upcoming Streams</h2>
        </div>
        <div class="space-y-2.5">
            <?php foreach ($scheduledStreams as $stream): ?>
            <div class="flex items-center gap-3 p-2.5 bg-surface-100/40 rounded-xl border border-surface-400/10">
                <div class="w-16 h-10 rounded-lg overflow-hidden flex-shrink-0 bg-surface-200">
                    <?php if ($stream['thumbnail']): ?>
                    <img src="<?= $stream['thumbnail'] ?>" class="w-full h-full object-cover">
                    <?php endif; ?>
                </div>
                <div class="flex-1 min-w-0">
                    <h4 class="text-white text-xs font-semibold truncate"><?= $stream['title'] ?></h4>
                    <div class="flex items-center gap-1 mt-0.5">
                        <span class="text-zinc-500 text-[10px]"><?= $stream['creator_name'] ?></span>
                        <?php if (!empty($stream['is_verified'])): ?>
                        <span class="material-icons-round text-brand-400 text-[10px]">verified</span>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="text-zinc-500 text-[10px] flex-shrink-0"><?= $stream['started_at'] ? date('M j, g:i A', strtotime($stream['started_at'])) : 'TBD' ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

</div>

<a href="/livestream/start" id="goLiveFab" class="fixed bottom-20 right-4 w-14 h-14 rounded-full gradient-brand shadow-lg shadow-brand-500/30 flex items-center justify-center hover:scale-110 hover:shadow-xl hover:shadow-brand-500/40 transition-all duration-300 z-40 sm:bottom-24 lg:bottom-6">
    <span class="material-icons-round text-white text-2xl">sensors</span>
</a>

<script>
const fab = document.getElementById('goLiveFab');
let fabVisible = true;
window.addEventListener('scroll', function() {
    const scrollTop = window.scrollY;
    const headerGoLive = document.querySelector('a[href="/livestream/start"]');
    if (headerGoLive) {
        const headerRect = headerGoLive.getBoundingClientRect();
        if (headerRect.top > -50 && headerRect.bottom < window.innerHeight + 50) {
            if (fabVisible) { fab.style.transform = 'scale(0)'; fab.style.opacity = '0'; fabVisible = false; }
        } else {
            if (!fabVisible) { fab.style.transform = 'scale(1)'; fab.style.opacity = '1'; fabVisible = true; }
        }
    }
});
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
