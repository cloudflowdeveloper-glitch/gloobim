<?php $title = 'Messages - DTTube'; ?>
<?php extract($data ?? []); ?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center justify-between mb-5">
        <div class="flex items-center gap-2">
            <span class="material-icons-round text-brand-400 text-2xl">chat</span>
            <h1 class="font-display text-xl font-bold text-white">Messages</h1>
        </div>
        <button onclick="newConversation()" class="w-9 h-9 rounded-full gradient-brand flex items-center justify-center hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-white text-lg">edit</span>
        </button>
    </div>

    <?php if ($user && !empty($conversations)): ?>
    <div class="space-y-1">
        <?php foreach ($conversations as $conv): ?>
        <a href="/messages/<?= $conv['id'] ?>" class="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-200/50 transition-colors <?= !empty($conv['unread_count']) ? 'bg-surface-100/60 border border-surface-400/20' : '' ?>">
            <div class="relative flex-shrink-0">
                <img src="<?= $conv['other_avatar'] ?? 'https://placehold.co/44x44/3f3f46/ffffff?text=U' ?>" alt="" class="w-11 h-11 rounded-full object-cover">
                <?php if (!empty($conv['other_verified'])): ?>
                <span class="absolute -bottom-0.5 -right-0.5 material-icons-round text-brand-500 text-xs bg-surface-50 rounded-full">verified</span>
                <?php endif; ?>
            </div>
            <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-1">
                        <span class="text-white text-sm font-semibold"><?= htmlspecialchars($conv['other_name']) ?></span>
                    </div>
                    <?php if (!empty($conv['last_message_at'])): ?>
                    <span class="text-zinc-600 text-[10px] flex-shrink-0"><?= timeAgo($conv['last_message_at']) ?></span>
                    <?php endif; ?>
                </div>
                <div class="flex items-center justify-between mt-0.5">
                    <p class="text-zinc-500 text-xs truncate">
                        <?php if ((int)$conv['last_sender_id'] === (int)$user['id']): ?>
                        <span class="text-zinc-600">You: </span>
                        <?php endif; ?>
                        <?= htmlspecialchars($conv['last_message'] ?? 'No messages yet') ?>
                    </p>
                    <?php if (!empty($conv['unread_count']) && (int)$conv['unread_count'] > 0): ?>
                    <span class="flex-shrink-0 ml-2 px-1.5 py-0.5 rounded-full bg-brand-600 text-white text-[9px] font-bold"><?= $conv['unread_count'] ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php elseif ($user): ?>
    <div class="text-center py-16">
        <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-4xl">chat_bubble</span>
        </div>
        <h3 class="text-white font-semibold text-base mb-1">No conversations yet</h3>
        <p class="text-zinc-500 text-xs mb-4">Start chatting with other creators!</p>
        <button onclick="newConversation()" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-sm font-semibold hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-lg">edit</span>
            New Message
        </button>
    </div>
    <?php else: ?>
    <div class="text-center py-16">
        <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-4xl">chat_bubble</span>
        </div>
        <h3 class="text-white font-semibold text-base mb-1">Sign in to message</h3>
        <p class="text-zinc-500 text-xs mb-4">Connect with creators and fans</p>
        <a href="/login" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-sm font-semibold hover:opacity-90 transition-opacity">
            Sign In
        </a>
    </div>
    <?php endif; ?>
</div>
<script>
function newConversation() {
    const username = prompt('Enter the username to message:');
    if (username && username.trim()) {
        fetch('/messages/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            body: JSON.stringify({ username: username.trim() })
        })
        .then(r => r.json())
        .then(data => {
            if (data.conversation_id) {
                window.location.href = '/messages/' + data.conversation_id;
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(() => alert('Could not create conversation. Please try again.'));
    }
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
