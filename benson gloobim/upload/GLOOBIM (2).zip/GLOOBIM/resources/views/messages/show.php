<?php $title = 'Messages - DTTube'; ?>
<?php
$messages = $data['messages'] ?? [];
$conversation = $data['conversation'] ?? null;
$userId = (int)($data['userId'] ?? 0);
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto h-[calc(100vh-8rem)] flex flex-col">
    <div class="flex items-center gap-3 p-3 border-b border-surface-400/15 flex-shrink-0">
        <a href="/messages" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors flex-shrink-0">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <?php if ($conversation): ?>
        <div class="flex items-center gap-2.5 flex-1 min-w-0">
            <div class="relative flex-shrink-0">
                <img src="<?= $conversation['other_avatar'] ?? 'https://placehold.co/40x40/3f3f46/ffffff?text=U' ?>" alt="" class="w-10 h-10 rounded-full object-cover">
                <?php if (!empty($conversation['other_verified'])): ?>
                <span class="absolute -bottom-0.5 -right-0.5 material-icons-round text-brand-400 text-xs bg-surface-50 rounded-full">verified</span>
                <?php endif; ?>
            </div>
            <div class="min-w-0">
                <h2 class="text-white text-sm font-bold truncate"><?= htmlspecialchars($conversation['other_name'] ?? '') ?></h2>
                <span class="text-zinc-500 text-[10px]">@<?= htmlspecialchars($conversation['other_username'] ?? '') ?></span>
            </div>
        </div>
        <?php else: ?>
        <h2 class="text-white text-sm font-bold">Conversation</h2>
        <?php endif; ?>
    </div>

    <div class="flex-1 overflow-y-auto p-3 space-y-3" id="chatMessages">
        <?php if ($conversation && !empty($messages)): ?>
            <?php foreach ($messages as $msg): ?>
            <div class="flex <?= (int)$msg['sender_id'] === $userId ? 'justify-end' : 'justify-start' ?>">
                <div class="max-w-[80%] <?= (int)$msg['sender_id'] === $userId ? 'bg-brand-600/60' : 'bg-surface-200/80' ?> rounded-2xl px-3.5 py-2.5">
                    <p class="text-white text-xs leading-relaxed"><?= htmlspecialchars($msg['body'] ?? '') ?></p>
                    <span class="block text-right text-[9px] <?= (int)$msg['sender_id'] === $userId ? 'text-brand-300' : 'text-zinc-500' ?> mt-0.5">
                        <?= isset($msg['created_at']) ? date('H:i', strtotime($msg['created_at'])) : '' ?>
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
        <div class="flex items-center justify-center h-full">
            <div class="text-center">
                <span class="material-icons-round text-zinc-500 text-4xl">chat</span>
                <p class="text-zinc-500 text-xs mt-2">No messages yet. Say hello!</p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($conversation): ?>
    <div class="flex items-center gap-2 p-3 border-t border-surface-400/15 flex-shrink-0">
        <input type="text" id="messageInput" placeholder="Type a message..." class="flex-1 bg-surface-200 text-white px-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500 focus:outline-none text-sm" onkeydown="if(event.key==='Enter')sendMessage()">
        <button onclick="sendMessage()" class="w-10 h-10 rounded-full gradient-brand flex items-center justify-center flex-shrink-0">
            <span class="material-icons-round text-white">send</span>
        </button>
    </div>
    <?php endif; ?>
</div>

<script>
const CONVERSATION_ID = <?= $data['conversation']['id'] ?? 0 ?>;
const USER_ID = <?= $userId ?>;

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const body = input.value.trim();
    if (!body || !CONVERSATION_ID) return;
    input.value = '';

    const chatEl = document.getElementById('chatMessages');
    const div = document.createElement('div');
    div.className = 'flex justify-end';
    div.innerHTML = '<div class="max-w-[80%] bg-brand-600/60 rounded-2xl px-3.5 py-2.5"><p class="text-white text-xs leading-relaxed">' + escapeHtml(body) + '</p><span class="block text-right text-[9px] text-brand-300 mt-0.5">Just now</span></div>';
    chatEl.appendChild(div);
    chatEl.scrollTop = chatEl.scrollHeight;

    try {
        await fetch('/messages/' + CONVERSATION_ID + '/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            body: JSON.stringify({ body: body })
        });
    } catch (e) {}
}

let lastMsgCount = <?= count($messages) ?>;
setInterval(async () => {
    if (!CONVERSATION_ID) return;
    try {
        const r = await fetch('/messages/' + CONVERSATION_ID + '/poll', { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const d = await r.json();
        if (d.length > lastMsgCount) {
            location.reload();
        }
    } catch(e) {}
}, 5000);

function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
