<?php $activeTab = 'menu'; $title = 'Menu - DTTube'; ?>
<?php
$currentUser = \Core\Auth::user();
$wallet = null;
if ($currentUser) {
    try {
        $wallets = \Core\Database::query("SELECT balance, currency FROM wallets WHERE user_id = ? LIMIT 1", [$currentUser['id']]);
        $wallet = $wallets[0] ?? null;
    } catch (\Exception $e) {}
}
$name = $currentUser['name'] ?? 'Guest';
$username = $currentUser['username'] ?? 'guest';
$avatar = $currentUser['avatar'] ?? 'https://placehold.co/56x56/6d28d9/ffffff?text=U';
$isVerified = !empty($currentUser['is_verified']);
$balance = $wallet ? number_format((float)$wallet['balance'], 0) : '0';
$currency = $wallet['currency'] ?? 'KES';
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <h1 class="font-display text-xl font-bold text-white mb-5">Menu</h1>

    <a href="/profile" class="flex items-center gap-3 mb-6 p-3 rounded-2xl bg-surface-100/80 border border-surface-400/20 hover:border-brand-500/30 transition-all">
        <img src="<?= $avatar ?>" class="w-14 h-14 rounded-full object-cover">
        <div class="flex-1">
            <div class="flex items-center gap-1">
                <h3 class="text-white font-semibold text-sm"><?= htmlspecialchars($name) ?></h3>
                <?php if ($isVerified): ?>
                <span class="material-icons-round text-brand-400 text-sm">verified</span>
                <?php endif; ?>
            </div>
            <p class="text-zinc-400 text-xs">@<?= htmlspecialchars($username) ?></p>
        </div>
        <a href="/wallet" class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-600/20 text-amber-400 text-xs font-semibold hover:bg-amber-600/30 transition-colors">
            <span class="material-icons-round text-sm">account_balance_wallet</span>
            <?= $currency ?> <?= $balance ?>
        </a>
    </a>

    <?php if (!$currentUser): ?>
    <div class="text-center py-6 mb-4 bg-surface-100/40 rounded-2xl border border-surface-400/20">
        <p class="text-zinc-400 text-sm mb-3">Sign in to access all features</p>
        <a href="/login" class="inline-flex items-center gap-1.5 gradient-brand px-6 py-2 rounded-full text-white text-sm font-semibold hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-lg">login</span>
            Sign In
        </a>
    </div>
    <?php endif; ?>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Content</p>
        <a href="/feed" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">explore</span>
            <span class="text-zinc-200 text-sm font-medium">Explore</span>
        </a>
        <a href="/reels" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">movie</span>
            <span class="text-zinc-200 text-sm font-medium">Reels</span>
        </a>
        <a href="/videos" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">play_circle</span>
            <span class="text-zinc-200 text-sm font-medium">Videos</span>
        </a>
        <a href="/music" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">music_note</span>
            <span class="text-zinc-200 text-sm font-medium">Music</span>
        </a>
        <a href="/posts" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">article</span>
            <span class="text-zinc-200 text-sm font-medium">Posts</span>
        </a>
        <a href="/livestream" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">sensors</span>
            <span class="text-zinc-200 text-sm font-medium">Live Streams</span>
        </a>
    </div>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Market</p>
        <a href="/market" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-amber-400">sell</span>
            <span class="text-zinc-200 text-sm font-medium">Digital Products & Services</span>
        </a>
        <a href="/market/my" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-amber-400">inventory</span>
            <span class="text-zinc-200 text-sm font-medium">My Items</span>
        </a>
        <a href="/market/create" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-amber-400">add_circle</span>
            <span class="text-zinc-200 text-sm font-medium">Sell Digital / Offer Service</span>
        </a>
    </div>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Marketplace</p>
        <a href="/marketplace" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-emerald-400">storefront</span>
            <span class="text-zinc-200 text-sm font-medium">Browse Marketplace</span>
        </a>
        <a href="/marketplace/my" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-emerald-400">inventory_2</span>
            <span class="text-zinc-200 text-sm font-medium">My Listings</span>
        </a>
        <a href="/marketplace/create" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-emerald-400">add_business</span>
            <span class="text-zinc-200 text-sm font-medium">Sell an Item</span>
        </a>
    </div>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Social</p>
        <a href="/messages" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-sky-400">chat</span>
            <span class="text-zinc-200 text-sm font-medium">Messages</span>
        </a>
        <a href="/notifications" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">favorite</span>
            <span class="text-zinc-200 text-sm font-medium">Notifications</span>
        </a>
        <a href="/feed" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-amber-400">trending_up</span>
            <span class="text-zinc-200 text-sm font-medium">Trending</span>
        </a>
    </div>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Creator Tools</p>
        <a href="/creator/dashboard" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-emerald-400">dashboard</span>
            <span class="text-zinc-200 text-sm font-medium">Creator Dashboard</span>
        </a>
        <a href="/creator/analytics" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-purple-400">analytics</span>
            <span class="text-zinc-200 text-sm font-medium">Analytics</span>
        </a>
        <a href="/wallet" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-amber-400">account_balance_wallet</span>
            <span class="text-zinc-200 text-sm font-medium">Wallet (<?= $currency ?> <?= $balance ?>)</span>
        </a>
        <a href="/livestream/start" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">sensors</span>
            <span class="text-zinc-200 text-sm font-medium">Go Live</span>
        </a>
        <a href="/livestream/my" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">playlist_play</span>
            <span class="text-zinc-200 text-sm font-medium">My Streams</span>
        </a>
        <a href="/livestream/schedule" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">calendar_add</span>
            <span class="text-zinc-200 text-sm font-medium">Schedule Stream</span>
        </a>
        <a href="/livestream/ended" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">history</span>
            <span class="text-zinc-200 text-sm font-medium">Past Streams</span>
        </a>
    </div>

    <div class="space-y-1 mb-6">
        <p class="text-[10px] text-zinc-600 uppercase tracking-wider font-semibold px-3 mb-2">Account</p>
        <a href="/profile" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-400">person</span>
            <span class="text-zinc-200 text-sm font-medium">Profile</span>
        </a>
        <a href="/settings" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-400">settings</span>
            <span class="text-zinc-200 text-sm font-medium">Settings</span>
        </a>
        <a href="#" onclick="showHelp()" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-zinc-400">help</span>
            <span class="text-zinc-200 text-sm font-medium">Help & Support</span>
        </a>
        <?php if ($currentUser): ?>
        <a href="/logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-red-400">logout</span>
            <span class="text-red-400 text-sm font-medium">Sign Out</span>
        </a>
        <form id="logout-form" method="POST" action="/logout" style="display:none;"></form>
        <?php else: ?>
        <a href="/login" class="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-surface-200/60 transition-colors">
            <span class="material-icons-round text-brand-400">login</span>
            <span class="text-brand-400 text-sm font-medium">Sign In</span>
        </a>
        <?php endif; ?>
    </div>
</div>
<script>
function showHelp() {
    alert('DTTube Help & Support\n\nFor assistance, please email support@dttube.com');
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
