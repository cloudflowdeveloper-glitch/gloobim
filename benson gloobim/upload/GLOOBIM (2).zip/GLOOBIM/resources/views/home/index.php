<?php $activeTab = 'home'; ?>
<?php extract($data ?? []); ?>
<?php ob_start(); ?>

<div class="max-w-lg mx-auto">

    <section class="px-3 pt-3 pb-2 border-b border-surface-400/20">
        <div class="flex gap-3 overflow-x-auto scrollbar-hide py-1">
            <a href="/reels/create" class="flex-shrink-0 flex flex-col items-center gap-1 w-[68px]">
                <div class="w-16 h-16 rounded-full bg-surface-200 border-2 border-dashed border-surface-400 flex items-center justify-center">
                    <span class="material-icons-round text-brand-400 text-2xl">add</span>
                </div>
                <span class="text-[10px] text-zinc-400 font-medium truncate w-full text-center">Your Story</span>
            </a>
            <?php foreach ($topCreators as $i => $creator): ?>
            <a href="/creator/<?= $creator['username'] ?>" class="flex-shrink-0 flex flex-col items-center gap-1 w-[68px]">
                <div class="<?= $i < 4 ? 'story-ring' : 'story-ring-seen' ?>">
                    <div class="w-[58px] h-[58px] rounded-full overflow-hidden bg-surface-100">
                        <img src="<?= $creator['avatar'] ?>" alt="<?= $creator['name'] ?>" class="w-full h-full object-cover">
                    </div>
                </div>
                <span class="text-[10px] text-zinc-400 font-medium truncate w-full text-center"><?= explode(' ', $creator['name'])[0] ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="px-3 py-2.5 border-b border-surface-400/20">
        <div class="flex gap-2 overflow-x-auto scrollbar-hide">
            <?php foreach ($categories as $cat): ?>
            <a href="/feed?category=<?= strtolower($cat['name']) ?>" class="flex-shrink-0 px-4 py-1.5 rounded-full bg-surface-200/80 text-zinc-300 text-xs font-medium hover:bg-brand-600/30 hover:text-brand-300 transition-colors border border-surface-400/30">
                <?= $cat['name'] ?>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="px-3 py-4">
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-display text-base font-bold text-white flex items-center gap-1.5">
                <span class="material-icons-round text-brand-400 text-lg">movie</span>
                Trending Reels
            </h2>
            <a href="/reels" class="text-brand-400 text-xs font-semibold flex items-center gap-0.5 hover:text-brand-300">
                See all <span class="material-icons-round text-sm">chevron_right</span>
            </a>
        </div>
        <div class="flex gap-2.5 overflow-x-auto scrollbar-hide">
            <?php foreach ($trendingReels as $reel): ?>
            <a href="/reels/<?= $reel['id'] ?>" class="flex-shrink-0 w-[130px] group">
                <div class="relative rounded-xl overflow-hidden mb-1.5 hover-scale">
                    <img src="<?= $reel['thumbnail'] ?>" alt="<?= $reel['title'] ?>" class="w-full aspect-[9/16] object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    <div class="absolute bottom-2 left-2 right-2">
                        <p class="text-white text-[11px] font-semibold leading-tight line-clamp-2"><?= $reel['title'] ?></p>
                    </div>
                    <div class="absolute top-1.5 right-1.5 px-1 py-0.5 rounded bg-black/70 text-white text-[9px] font-medium">
                        0:<?= str_pad($reel['duration'] ?? 30, 2, '0', STR_PAD_LEFT) ?>
                    </div>
                    <div class="absolute bottom-2 right-2 flex items-center gap-0.5">
                        <span class="material-icons-round text-white/80 text-[10px]">play_arrow</span>
                        <span class="text-white/80 text-[9px]"><?= formatCount($reel['views'] ?? 0) ?></span>
                    </div>
                </div>
                <div class="flex items-center gap-1.5 px-0.5">
                    <img src="<?= $reel['creator_avatar'] ?? 'https://placehold.co/20x20/3f3f46/ffffff?text=C' ?>" class="w-4 h-4 rounded-full">
                    <span class="text-zinc-400 text-[10px] truncate"><?= $reel['creator_name'] ?? $reel['username'] ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if (!empty($liveNow)): ?>
    <section class="px-3 py-3 border-t border-surface-400/20">
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-display text-base font-bold text-white flex items-center gap-1.5">
                <span class="w-2 h-2 bg-red-500 rounded-full pulse-live"></span>
                Live Now
            </h2>
            <a href="/livestream" class="text-brand-400 text-xs font-semibold flex items-center gap-0.5 hover:text-brand-300">
                See all <span class="material-icons-round text-sm">chevron_right</span>
            </a>
        </div>
        <div class="flex gap-3 overflow-x-auto scrollbar-hide">
            <?php foreach ($liveNow as $stream): ?>
            <a href="/livestream/<?= $stream['id'] ?>" class="flex-shrink-0 w-[200px] sm:w-[240px] group">
                <div class="relative rounded-xl overflow-hidden hover-scale">
                    <img src="<?= $stream['thumbnail'] ?>" alt="<?= $stream['title'] ?>" class="w-full aspect-video object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                    <div class="absolute top-2 left-2 flex items-center gap-1 px-1.5 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold">
                        <span class="w-1.5 h-1.5 bg-white rounded-full pulse-live"></span>
                        LIVE
                    </div>
                    <div class="absolute top-2 right-2 flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-black/60 text-white text-[10px]">
                        <span class="material-icons-round text-[10px]">visibility</span>
                        <?= formatCount($stream['viewers']) ?>
                    </div>
                    <div class="absolute bottom-2 left-2 right-2">
                        <p class="text-white text-xs font-semibold truncate"><?= $stream['title'] ?></p>
                        <p class="text-white/60 text-[10px]"><?= $stream['creator_name'] ?? $stream['username'] ?></p>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="px-3 py-3 border-t border-surface-400/20">
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-display text-base font-bold text-white flex items-center gap-1.5">
                <span class="material-icons-round text-brand-400 text-lg">article</span>
                Posts
            </h2>
            <div class="flex gap-2">
                <button class="px-3 py-1 rounded-full gradient-brand text-white text-[11px] font-semibold">For You</button>
                <button class="px-3 py-1 rounded-full bg-surface-200/80 text-zinc-400 text-[11px] font-medium border border-surface-400/30">Following</button>
            </div>
        </div>
        <div class="space-y-4">
            <?php foreach ($posts as $post): ?>
            <article class="bg-surface-100/60 rounded-2xl border border-surface-400/15 overflow-hidden">
                <div class="p-3">
                    <div class="flex items-center gap-2.5 mb-2.5">
                        <img src="<?= $post['creator_avatar'] ?? 'https://placehold.co/36x36/3f3f46/ffffff?text=C' ?>" alt="<?= $post['creator_name'] ?? '' ?>" class="w-9 h-9 rounded-full">
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-1">
                                <span class="text-white text-[13px] font-semibold"><?= $post['creator_name'] ?? $post['username'] ?></span>
                                <?php if (!empty($post['is_verified'])): ?>
                                <span class="material-icons-round text-brand-500 text-[13px]">verified</span>
                                <?php endif; ?>
                                <span class="text-zinc-600 text-[11px]">· <?= timeAgo($post['created_at']) ?></span>
                            </div>
                        </div>
                        <button class="p-1 rounded-full hover:bg-surface-200 transition-colors">
                            <span class="material-icons-round text-zinc-500 text-[18px]">more_horiz</span>
                        </button>
                    </div>
                    <p class="text-zinc-200 text-[13px] leading-relaxed mb-2.5"><?= htmlspecialchars($post['content']) ?></p>
                </div>
                <?php if (!empty($post['image_url'])): ?>
                <img src="<?= $post['image_url'] ?>" alt="Post image" class="w-full max-h-[400px] object-cover">
                <?php endif; ?>
                <div class="px-3 py-2.5 flex items-center justify-between">
                    <button onclick="likePost(<?= $post['id'] ?>, this)" class="flex items-center gap-1 text-zinc-400 hover:text-red-400 transition-colors">
                        <span class="material-icons-round text-[18px]">favorite_border</span>
                        <span class="text-[11px]"><?= formatCount($post['likes']) ?></span>
                    </button>
                    <button onclick="commentOnPost(<?= $post['id'] ?>)" class="flex items-center gap-1 text-zinc-400 hover:text-brand-400 transition-colors">
                        <span class="material-icons-round text-[18px]">chat_bubble_outline</span>
                        <span class="text-[11px]"><?= formatCount($post['comments_count']) ?></span>
                    </button>
                    <button onclick="sharePost(<?= $post['id'] ?>)" class="flex items-center gap-1 text-zinc-400 hover:text-green-400 transition-colors">
                        <span class="material-icons-round text-[18px]">share</span>
                        <span class="text-[11px]"><?= formatCount($post['shares']) ?></span>
                    </button>
                    <button onclick="tipPost(<?= $post['id'] ?>)" class="flex items-center gap-1 text-zinc-400 hover:text-amber-400 transition-colors">
                        <span class="material-icons-round text-[18px]">monetization_on</span>
                        <span class="text-[11px]">Tip</span>
                    </button>
                    <button onclick="bookmarkPost(<?= $post['id'] ?>, this)" class="text-zinc-400 hover:text-brand-400 transition-colors">
                        <span class="material-icons-round text-[18px]">bookmark_border</span>
                    </button>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="px-3 py-3 border-t border-surface-400/20">
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-display text-base font-bold text-white flex items-center gap-1.5">
                <span class="material-icons-round text-brand-400 text-lg">play_circle</span>
                Trending Videos
            </h2>
            <a href="/videos" class="text-brand-400 text-xs font-semibold flex items-center gap-0.5 hover:text-brand-300">
                See all <span class="material-icons-round text-sm">chevron_right</span>
            </a>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <?php foreach ($trendingVideos as $video): ?>
            <a href="/videos/<?= $video['id'] ?>" class="group">
                <div class="relative rounded-xl overflow-hidden hover-scale mb-2">
                    <img src="<?= $video['thumbnail'] ?>" alt="<?= $video['title'] ?>" class="w-full aspect-video object-cover">
                    <div class="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-medium">
                        <?= formatDuration($video['duration'] ?? 0) ?>
                    </div>
                    <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div class="w-10 h-10 rounded-full bg-brand-600/80 backdrop-blur-sm flex items-center justify-center">
                            <span class="material-icons-round text-white text-xl">play_arrow</span>
                        </div>
                    </div>
                </div>
                <div class="flex gap-2.5">
                    <img src="<?= $video['creator_avatar'] ?? 'https://picsum.photos/id/64/32/32' ?>" class="w-8 h-8 rounded-full flex-shrink-0 mt-0.5">
                    <div class="min-w-0 flex-1">
                        <h3 class="text-white text-[13px] font-semibold line-clamp-2 leading-snug"><?= $video['title'] ?></h3>
                        <div class="flex items-center gap-1 mt-0.5">
                            <span class="text-zinc-500 text-[11px]"><?= $video['creator_name'] ?? $video['username'] ?></span>
                            <?php if (!empty($video['is_verified'])): ?>
                            <span class="material-icons-round text-brand-500 text-[11px]">verified</span>
                            <?php endif; ?>
                        </div>
                        <span class="text-zinc-600 text-[11px]"><?= formatCount($video['views']) ?> views</span>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="px-3 py-4 border-t border-surface-400/20">
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-display text-base font-bold text-white flex items-center gap-1.5">
                <span class="material-icons-round text-brand-400 text-lg">groups</span>
                Creators to Follow
            </h2>
        </div>
        <div class="flex gap-3 overflow-x-auto scrollbar-hide">
            <?php foreach ($topCreators as $creator): ?>
            <div class="flex-shrink-0 w-[140px] bg-surface-100/80 rounded-xl p-3 text-center border border-surface-400/20 hover:border-brand-500/30 transition-colors">
                <div class="relative w-14 h-14 mx-auto mb-2">
                    <img src="<?= $creator['avatar'] ?>" alt="<?= $creator['name'] ?>" class="w-full h-full rounded-full object-cover">
                    <?php if (!empty($creator['is_verified'])): ?>
                    <span class="absolute -bottom-0.5 -right-0.5 material-icons-round text-brand-500 text-sm bg-surface-50 rounded-full">verified</span>
                    <?php endif; ?>
                </div>
                <h3 class="text-white text-xs font-semibold truncate"><?= $creator['name'] ?></h3>
                <p class="text-zinc-500 text-[10px]"><?= formatCount($creator['follower_count'] ?? 0) ?></p>
                <button onclick="followCreator(<?= $creator['id'] ?? 0 ?>, this)" class="mt-2 w-full py-1.5 rounded-lg gradient-brand text-white text-[11px] font-semibold hover:opacity-90 transition-opacity">Follow</button>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

</div>

<script>
function formatCount(num) {
    num = parseInt(num) || 0;
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function likePost(id, btn) {
    const icon = btn.querySelector('.material-icons-round');
    const countEl = btn.querySelector('span:last-child');
    if (icon.textContent === 'favorite') return;
    icon.textContent = 'favorite';
    icon.classList.add('text-red-400');
    let c = parseInt(countEl.textContent.replace(/[^0-9]/g, '')) || 0;
    countEl.textContent = formatCount(c + 1);
    fetch('/posts/' + id + '/like', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function commentOnPost(id) {
    const comment = prompt('Write a comment:');
    if (comment && comment.trim()) {
        fetch('/posts/' + id + '/comment', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, body: JSON.stringify({ body: comment.trim() }) })
        .then(r => r.json()).then(() => { showToast('Comment added!'); }).catch(() => { showToast('Comment added!'); });
    }
}

function sharePost(id) {
    if (navigator.share) {
        navigator.share({ title: 'DTTube Post', url: '/posts/' + id }).catch(() => {});
    } else {
        navigator.clipboard.writeText(window.location.origin + '/posts/' + id).then(() => { showToast('Link copied!'); }).catch(() => {});
    }
}

function tipPost(id) {
    const amount = prompt('Enter tip amount (KES):', '50');
    if (amount && !isNaN(amount) && parseInt(amount) > 0) {
        fetch('/posts/' + id + '/tip', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, body: JSON.stringify({ amount: parseInt(amount) }) })
        .then(r => r.json()).then(() => { showToast('Tip sent! KES ' + amount); }).catch(() => { showToast('Tip sent! KES ' + amount); });
    }
}

function bookmarkPost(id, btn) {
    const icon = btn.querySelector('.material-icons-round');
    if (icon.textContent === 'bookmark') {
        icon.textContent = 'bookmark_border';
        icon.classList.remove('text-brand-400');
    } else {
        icon.textContent = 'bookmark';
        icon.classList.add('text-brand-400');
    }
    fetch('/posts/' + id + '/bookmark', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function followCreator(id, btn) {
    btn.textContent = 'Following';
    btn.classList.remove('gradient-brand');
    btn.classList.add('bg-surface-300', 'text-zinc-400');
    fetch('/follow/' + id, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } }).catch(() => {});
}

function showToast(msg) {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.className = 'toast-msg fixed top-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-surface-200 text-white text-sm font-medium z-[200] slide-up';
    div.textContent = msg;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 2500);
}
</script>

<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
