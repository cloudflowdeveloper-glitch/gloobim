<?php $activeTab = 'menu'; $title = 'Sell an Item - DTTube'; ?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center gap-3 mb-6">
        <a href="/marketplace" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <h1 class="font-display text-lg font-bold text-white">Sell an Item</h1>
    </div>

    <form id="listingForm" class="space-y-4" enctype="multipart/form-data" onsubmit="submitListing(event)">
        <div>
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Title *</label>
            <input type="text" id="title" required placeholder="e.g. iPhone 15 Pro Max 256GB" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
        </div>

        <div>
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Description</label>
            <textarea id="description" rows="4" placeholder="Describe your item in detail..." class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm resize-none"></textarea>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Price *</label>
                <div class="relative">
                    <?php $ci = $data['currencyInfo'] ?? ['code' => 'KES', 'symbol' => 'KES', 'rate' => 129.50]; ?>
                    <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-sm font-medium" id="priceCurrencyLabel"><?= $ci['symbol'] ?></span>
                    <input type="number" id="price" required min="1" step="0.01" placeholder="0.00" class="w-full bg-surface-200/80 text-white pl-12 pr-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
                </div>
                <p class="text-zinc-600 text-[9px] mt-1">Auto-detected from your country. <span id="currencyName"><?= $ci['code'] ?></span></p>
                <input type="hidden" id="currency" value="<?= $ci['code'] ?>">
            </div>
            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Category</label>
                <select id="category" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
                    <option value="Electronics">Electronics</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Home">Home & Garden</option>
                    <option value="Collectibles">Collectibles</option>
                    <option value="Sports">Sports</option>
                    <option value="Music">Music</option>
                    <option value="Art">Art</option>
                    <option value="Books">Books</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Condition</label>
                <select id="condition" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
                    <option value="new">Brand New</option>
                    <option value="like_new">Like New</option>
                    <option value="good">Good</option>
                    <option value="fair">Fair</option>
                    <option value="used">Used</option>
                </select>
            </div>
        </div>

        <div>
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Image Upload (Recommended)</label>
            <input type="file" id="imageFile" accept="image/jpeg,image/png,image/gif,image/webp" class="w-full bg-surface-200/80 text-zinc-400 px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:gradient-brand file:text-white file:text-xs file:font-medium file:cursor-pointer"
                   onchange="document.getElementById('imageUrlLabel').classList.add('hidden')">
            <p class="text-zinc-600 text-[9px] mt-1">Upload a photo (JPG, PNG, GIF, WebP — max 5MB)</p>
        </div>

        <div id="imageUrlLabel">
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Or Image URL</label>
            <input type="url" id="image_url" placeholder="https://placehold.co/400x300/..." class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
        </div>

        <div>
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Location</label>
            <input type="text" id="location" placeholder="e.g. Nairobi, Kenya" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
        </div>

        <div>
            <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Phone Number</label>
            <input type="tel" id="phone" placeholder="e.g. +254712345678" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm">
        </div>

        <button type="submit" id="submitBtn" class="w-full py-2.5 rounded-xl gradient-brand text-white text-sm font-bold hover:opacity-90 transition-all flex items-center justify-center gap-2">
            <span class="material-icons-round text-lg">add_business</span>
            Post Listing
        </button>
    </form>
</div>

<script>
function submitListing(e) {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="material-icons-round animate-spin text-lg">refresh</span> Posting...';

    const formData = new FormData();
    formData.append('title', document.getElementById('title').value.trim());
    formData.append('description', document.getElementById('description').value.trim());
    formData.append('price', document.getElementById('price').value);
    formData.append('currency', document.getElementById('currency').value);
    formData.append('category', document.getElementById('category').value);
    formData.append('condition', document.getElementById('condition').value);
    formData.append('location', document.getElementById('location').value.trim());
    formData.append('phone', document.getElementById('phone').value.trim());

    const fileInput = document.getElementById('imageFile');
    if (fileInput && fileInput.files.length > 0) {
        formData.append('image', fileInput.files[0]);
    } else {
        const imageUrl = document.getElementById('image_url').value.trim();
        if (imageUrl) {
            formData.append('image_url', imageUrl);
        }
    }

    fetch('/marketplace', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    }).then(r => r.json()).then(d => {
        if (d.listing_id) {
            alert('Listing posted successfully!');
            window.location.href = '/marketplace/' + d.listing_id;
        } else {
            alert(d.error || 'Error creating listing');
            btn.disabled = false;
            btn.innerHTML = '<span class="material-icons-round text-lg">add_business</span> Post Listing';
        }
    }).catch(() => {
        alert('Network error. Please try again.');
        btn.disabled = false;
        btn.innerHTML = '<span class="material-icons-round text-lg">add_business</span> Post Listing';
    });
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
