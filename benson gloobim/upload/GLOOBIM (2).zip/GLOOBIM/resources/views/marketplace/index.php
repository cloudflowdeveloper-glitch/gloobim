<?php $activeTab = 'menu'; $title = 'Marketplace - DTTube'; ?>
<?php
$listings = $data['listings'] ?? [];
$categories = $data['categories'] ?? [];
$userListings = $data['userListings'] ?? [];
$activeCategory = $data['activeCategory'] ?? '';
$search = $data['search'] ?? '';
$sort = $data['sort'] ?? 'latest';
$minPrice = $data['minPrice'] ?? 0;
$maxPrice = $data['maxPrice'] ?? 0;
$user = \Core\Auth::user();

function buildQuery($overrides = []) {
    $params = array_merge(['category', 'search', 'sort', 'min_price', 'max_price'], array_keys($overrides));
    $parts = [];
    foreach ($_GET as $key => $val) {
        if ($val !== '' && !isset($overrides[$key])) {
            $parts[] = urlencode($key) . '=' . urlencode($val);
        }
    }
    foreach ($overrides as $key => $val) {
        if ($val !== '' && $val !== null) {
            $parts[] = urlencode($key) . '=' . urlencode($val);
        }
    }
    return '/marketplace' . ($parts ? '?' . implode('&', $parts) : '');
}
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4 pb-24 lg:pb-6">
    <div class="flex items-center justify-between mb-4">
        <div class="flex items-center gap-2">
            <span class="material-icons-round text-emerald-400 text-2xl">storefront</span>
            <h1 class="font-display text-xl font-bold text-white">Marketplace</h1>
        </div>
        <a href="/marketplace/create" class="w-9 h-9 rounded-full gradient-brand flex items-center justify-center hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-white text-lg">add</span>
        </a>
    </div>

    <form method="GET" action="/marketplace" class="relative mb-3">
        <span class="material-icons-round absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-lg">search</span>
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search marketplace..." class="w-full bg-surface-200/80 text-white pl-9 pr-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-emerald-500/60 focus:outline-none text-sm placeholder:text-zinc-600 transition-all">
        <?php if ($activeCategory): ?>
        <input type="hidden" name="category" value="<?= htmlspecialchars($activeCategory) ?>">
        <?php endif; ?>
    </form>

    <div class="flex items-center justify-between mb-4">
        <div class="flex gap-2 overflow-x-auto scrollbar-hide pb-1 flex-1">
            <a href="<?= buildQuery(['category' => '']) ?>" class="flex-shrink-0 px-3.5 py-1.5 rounded-full <?= empty($activeCategory) ? 'gradient-brand text-white' : 'bg-surface-200 text-zinc-400 hover:text-white' ?> text-xs font-semibold transition-all">All</a>
            <?php foreach ($categories as $cat): ?>
            <a href="<?= buildQuery(['category' => $cat['category']]) ?>" class="flex-shrink-0 px-3.5 py-1.5 rounded-full <?= $activeCategory === $cat['category'] ? 'gradient-brand text-white' : 'bg-surface-200 text-zinc-400 hover:text-white' ?> text-xs font-semibold transition-all">
                <?= htmlspecialchars($cat['category']) ?> (<?= $cat['count'] ?>)
            </a>
            <?php endforeach; ?>
        </div>
        <div class="flex-shrink-0 ml-2">
            <select onchange="window.location.href='<?= buildQuery(['sort' => '']) ?>' + '&sort=' + this.value" class="bg-surface-200/80 text-zinc-300 text-[10px] px-2 py-1.5 rounded-lg border border-surface-400/30 focus:outline-none">
                <option value="latest" <?= $sort === 'latest' ? 'selected' : '' ?>>Latest</option>
                <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: Low</option>
                <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High</option>
                <option value="views" <?= $sort === 'views' ? 'selected' : '' ?>>Most Viewed</option>
            </select>
        </div>
    </div>

    <?php if (!empty($listings)): ?>
    <div class="grid grid-cols-2 gap-3">
        <?php foreach ($listings as $listing): ?>
        <a href="/marketplace/<?= $listing['id'] ?>" class="block bg-surface-100/40 rounded-2xl border border-surface-400/10 hover:border-emerald-500/30 hover:-translate-y-0.5 transition-all group overflow-hidden">
            <div class="relative aspect-[4/3] bg-surface-200 overflow-hidden">
                <img src="<?= $listing['image_url'] ?? 'https://picsum.photos/id/0/400/300' ?>" alt="" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                <?php if (!empty($listing['sold'])): ?>
                <div class="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <span class="px-3 py-1 rounded-full bg-red-500/80 text-white text-xs font-bold">SOLD</span>
                </div>
                <?php endif; ?>
                <span class="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-white text-[9px] font-medium">
                    <?= htmlspecialchars($listing['condition'] ?? '') ?>
                </span>
            </div>
            <div class="p-2.5">
                <p class="text-white text-xs font-semibold truncate"><?= htmlspecialchars($listing['title'] ?? '') ?></p>
                <div class="flex items-center justify-between mt-1">
                    <span class="text-emerald-400 text-sm font-bold"><?= htmlspecialchars($listing['currency'] ?? 'KES') ?> <?= number_format((float)($listing['price'] ?? 0)) ?></span>
                    <?php if (!empty($listing['location'])): ?>
                    <span class="text-zinc-500 text-[9px] truncate ml-1"><?= htmlspecialchars($listing['location']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-12 bg-surface-100/30 rounded-2xl border border-surface-400/10">
        <div class="w-16 h-16 mx-auto mb-3 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-3xl">storefront</span>
        </div>
        <h3 class="text-white font-semibold text-sm mb-1">No listings yet</h3>
        <p class="text-zinc-500 text-xs mb-4"><?= $user ? 'Be the first to sell something!' : 'Sign in to browse and sell items' ?></p>
        <?php if ($user): ?>
        <a href="/marketplace/create" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">Sell an Item</a>
        <?php else: ?>
        <a href="/login" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">Sign In</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($user && !empty($userListings)): ?>
    <div class="mt-6">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-white text-xs font-bold">Your Listings</h3>
            <a href="/marketplace/my" class="text-emerald-400 text-[10px] font-semibold">Manage</a>
        </div>
        <div class="space-y-2">
            <?php foreach ($userListings as $listing): ?>
            <a href="/marketplace/<?= $listing['id'] ?>" class="flex items-center gap-3 p-3 rounded-xl bg-surface-100/30 border border-surface-400/10 hover:border-surface-400/30 transition-all">
                <img src="<?= $listing['image_url'] ?? 'https://placehold.co/48x48/3f3f46/ffffff?text=I' ?>" alt="" class="w-12 h-12 rounded-xl object-cover flex-shrink-0">
                <div class="flex-1 min-w-0">
                    <p class="text-white text-xs font-semibold truncate"><?= htmlspecialchars($listing['title'] ?? '') ?></p>
                    <div class="flex items-center gap-2 mt-0.5">
                        <span class="text-emerald-400 text-[10px] font-bold"><?= htmlspecialchars($listing['currency'] ?? 'KES') ?> <?= number_format((float)($listing['price'] ?? 0)) ?></span>
                        <span class="text-zinc-600">·</span>
                        <span class="text-zinc-500 text-[10px]"><?= formatCount($listing['views'] ?? 0) ?> views</span>
                        <?php if (!empty($listing['sold'])): ?>
                        <span class="px-1.5 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[8px] font-medium">Sold</span>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="material-icons-round text-zinc-500">chevron_right</span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
