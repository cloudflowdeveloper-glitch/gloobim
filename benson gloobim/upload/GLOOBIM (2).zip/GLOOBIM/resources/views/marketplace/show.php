<?php $title = ($data['listing']['title'] ?? 'Listing') . ' - DTTube'; ?>
<?php
$listing = $data['listing'] ?? [];
$user = \Core\Auth::user();
$isOwner = $user && $listing && (int)$user['id'] === (int)($listing['user_id'] ?? 0);
$price = (float)($listing['price'] ?? 0);
$currency = $listing['currency'] ?? 'KES';
$category = $listing['category'] ?? 'Other';
$condition = $listing['condition'] ?? 'good';
$conditionLabels = ['new' => 'Brand New', 'like_new' => 'Like New', 'good' => 'Good', 'fair' => 'Fair', 'used' => 'Used'];
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4 pb-24 lg:pb-6">
    <div class="flex items-center gap-3 mb-4">
        <a href="/marketplace<?= isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], '/marketplace') !== false ? '' : '' ?>" onclick="history.back(); return false;" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <h1 class="font-display text-lg font-bold text-white truncate"><?= htmlspecialchars($listing['title'] ?? '') ?></h1>
    </div>

    <?php if ($listing): ?>
    <div class="rounded-2xl overflow-hidden mb-4 bg-surface-200">
        <div class="aspect-[4/3] relative">
            <img src="<?= $listing['image_url'] ?? 'https://placehold.co/600x450/3f3f46/ffffff?text=No+Image' ?>" alt="" class="w-full h-full object-cover">
            <?php if (!empty($listing['sold'])): ?>
            <div class="absolute inset-0 bg-black/60 flex items-center justify-center">
                <span class="px-6 py-2 rounded-full bg-red-500/80 text-white text-lg font-bold">SOLD</span>
            </div>
            <?php endif; ?>
            <div class="absolute top-3 left-3 flex gap-1.5">
                <span class="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-sm text-white text-[10px] font-medium"><?= $conditionLabels[$condition] ?? $condition ?></span>
                <?php if (!empty($listing['location'])): ?>
                <span class="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-sm text-white text-[10px] font-medium"><?= htmlspecialchars($listing['location']) ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="flex items-start justify-between mb-3">
        <div>
            <h2 class="text-white text-lg font-bold"><?= htmlspecialchars($listing['title'] ?? '') ?></h2>
            <p class="text-zinc-500 text-[10px] mt-0.5"><?= htmlspecialchars($category) ?> · <?= formatCount($listing['views'] ?? 0) ?> views</p>
        </div>
        <span class="text-emerald-400 text-xl font-bold flex-shrink-0"><?= htmlspecialchars($currency) ?> <?= number_format($price) ?></span>
    </div>

    <div class="flex items-center gap-3 mb-4 p-3 rounded-xl bg-surface-100/40 border border-surface-400/10">
        <img src="<?= $listing['seller_avatar'] ?? 'https://placehold.co/40x40/6d28d9/ffffff?text=S' ?>" alt="" class="w-10 h-10 rounded-full">
        <div class="flex-1">
            <div class="flex items-center gap-1">
                <span class="text-white text-sm font-semibold"><?= htmlspecialchars($listing['seller_name'] ?? $listing['username'] ?? '') ?></span>
                <?php if (!empty($listing['is_verified'])): ?>
                <span class="material-icons-round text-brand-400 text-sm">verified</span>
                <?php endif; ?>
            </div>
            <span class="text-zinc-500 text-[10px]">@<?= htmlspecialchars($listing['username'] ?? '') ?></span>
        </div>
        <?php if (!$isOwner && $user): ?>
        <a href="/messages" class="px-3 py-1.5 rounded-lg bg-surface-200 text-zinc-300 text-xs font-semibold hover:bg-surface-300 transition-colors">Message</a>
        <?php endif; ?>
    </div>

    <?php if (!empty($listing['description'])): ?>
    <div class="mb-5">
        <h3 class="text-white text-xs font-bold mb-2">Description</h3>
        <p class="text-zinc-300 text-xs leading-relaxed whitespace-pre-wrap"><?= htmlspecialchars($listing['description']) ?></p>
    </div>
    <?php endif; ?>

    <div class="mb-5">
        <h3 class="text-white text-xs font-bold mb-2">Details</h3>
        <div class="bg-surface-100/30 rounded-xl border border-surface-400/10 overflow-hidden">
            <div class="flex items-center justify-between p-3 border-b border-surface-400/10">
                <span class="text-zinc-500 text-xs">Condition</span>
                <span class="text-white text-xs font-semibold"><?= $conditionLabels[$condition] ?? $condition ?></span>
            </div>
            <div class="flex items-center justify-between p-3 border-b border-surface-400/10">
                <span class="text-zinc-500 text-xs">Category</span>
                <span class="text-white text-xs font-semibold"><?= htmlspecialchars($category) ?></span>
            </div>
            <div class="flex items-center justify-between p-3 border-b border-surface-400/10">
                <span class="text-zinc-500 text-xs">Location</span>
                <span class="text-white text-xs font-semibold"><?= htmlspecialchars($listing['location'] ?? 'N/A') ?></span>
            </div>
            <div class="flex items-center justify-between p-3">
                <span class="text-zinc-500 text-xs">Listed</span>
                <span class="text-white text-xs font-semibold"><?= isset($listing['created_at']) ? timeAgo($listing['created_at']) : 'Recently' ?></span>
            </div>
        </div>
    </div>

    <?php if ($isOwner): ?>
    <div class="flex gap-3">
        <a href="/marketplace/<?= $listing['id'] ?>/edit" class="flex-1 py-2.5 rounded-xl bg-surface-200 text-white text-sm font-semibold text-center hover:bg-surface-300 transition-colors">Edit Listing</a>
        <button onclick="markSold(<?= $listing['id'] ?>)" class="flex-1 py-2.5 rounded-xl bg-emerald-600/20 text-emerald-400 text-sm font-semibold hover:bg-emerald-600/30 transition-colors">Mark as Sold</button>
        <button onclick="deleteListing(<?= $listing['id'] ?>)" class="px-4 py-2.5 rounded-xl bg-red-600/20 text-red-400 text-sm font-semibold hover:bg-red-600/30 transition-colors">
            <span class="material-icons-round text-lg">delete</span>
        </button>
    </div>
    <?php elseif ($user): ?>
    <div class="flex gap-3">
        <?php if (!empty($listing['phone'])): ?>
        <a href="tel:<?= htmlspecialchars($listing['phone']) ?>" class="flex-1 py-2.5 rounded-xl gradient-brand text-white text-sm font-semibold text-center hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
            <span class="material-icons-round text-lg">phone</span>
            Call Seller
        </a>
        <?php endif; ?>
        <a href="/messages" class="flex-1 py-2.5 rounded-xl bg-surface-200 text-white text-sm font-semibold text-center hover:bg-surface-300 transition-colors flex items-center justify-center gap-2">
            <span class="material-icons-round text-lg">chat</span>
            Message
        </a>
    </div>
    <?php else: ?>
    <a href="/login" class="block w-full py-2.5 rounded-xl gradient-brand text-white text-sm font-semibold text-center hover:opacity-90 transition-opacity">Sign in to Contact Seller</a>
    <?php endif; ?>
    <?php else: ?>
    <div class="text-center py-16">
        <span class="material-icons-round text-zinc-500 text-5xl">storefront</span>
        <h3 class="text-white font-semibold text-sm mt-3">Listing not found</h3>
        <p class="text-zinc-500 text-xs mt-1">This item may have been removed or doesn't exist</p>
        <a href="/marketplace" class="inline-block mt-4 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">Browse Marketplace</a>
    </div>
    <?php endif; ?>
</div>

<script>
function markSold(id) {
    if (!confirm('Mark this item as sold?')) return;
    fetch('/marketplace/' + id + '/sold', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(r => r.json()).then(d => { alert(d.message); location.reload(); })
        .catch(() => alert('Error marking as sold'));
}

function deleteListing(id) {
    if (!confirm('Delete this listing permanently?')) return;
    fetch('/marketplace/' + id, { method: 'DELETE', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(r => r.json()).then(d => { alert(d.message); window.location.href = '/marketplace/my'; })
        .catch(() => alert('Error deleting listing'));
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
