<?php $activeTab = 'menu'; $title = 'My Listings - DTTube'; ?>
<?php $listings = $data['listings'] ?? []; ?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">
    <div class="flex items-center justify-between mb-5">
        <div class="flex items-center gap-3">
            <a href="/marketplace" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
                <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
            </a>
            <h1 class="font-display text-lg font-bold text-white">My Listings</h1>
        </div>
        <a href="/marketplace/create" class="w-9 h-9 rounded-full gradient-brand flex items-center justify-center hover:opacity-90 transition-opacity">
            <span class="material-icons-round text-white text-lg">add</span>
        </a>
    </div>

    <?php if (!empty($listings)): ?>
    <div class="space-y-2">
        <?php foreach ($listings as $listing): ?>
        <a href="/marketplace/<?= $listing['id'] ?>" class="flex items-center gap-3 p-3.5 rounded-xl bg-surface-100/30 border border-surface-400/10 hover:border-emerald-500/30 hover:-translate-y-0.5 transition-all">
            <img src="<?= $listing['image_url'] ?? 'https://placehold.co/56x56/3f3f46/ffffff?text=I' ?>" alt="" class="w-14 h-14 rounded-xl object-cover flex-shrink-0">
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2">
                    <p class="text-white text-xs font-semibold truncate"><?= htmlspecialchars($listing['title'] ?? '') ?></p>
                    <?php if (!empty($listing['sold'])): ?>
                    <span class="px-1.5 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[8px] font-medium flex-shrink-0">Sold</span>
                    <?php endif; ?>
                </div>
                <div class="flex items-center gap-2 mt-1">
                    <span class="text-emerald-400 text-sm font-bold"><?= htmlspecialchars($listing['currency'] ?? 'KES') ?> <?= number_format((float)($listing['price'] ?? 0)) ?></span>
                    <span class="text-zinc-600">·</span>
                    <span class="text-zinc-500 text-[10px]"><?= formatCount($listing['views'] ?? 0) ?> views</span>
                </div>
                <div class="flex items-center gap-2 mt-0.5">
                    <span class="text-zinc-600 text-[9px]"><?= htmlspecialchars($listing['category'] ?? '') ?></span>
                    <span class="text-zinc-600">·</span>
                    <span class="text-zinc-600 text-[9px]"><?= isset($listing['created_at']) ? date('M d, Y', strtotime($listing['created_at'])) : '' ?></span>
                </div>
            </div>
            <div class="flex flex-col gap-1.5">
                <a href="/marketplace/<?= $listing['id'] ?>/edit" class="w-7 h-7 rounded-lg bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
                    <span class="material-icons-round text-zinc-400 text-sm">edit</span>
                </a>
                <button onclick="event.preventDefault(); event.stopPropagation(); deleteListing(<?= $listing['id'] ?>)" class="w-7 h-7 rounded-lg bg-red-500/20 flex items-center justify-center hover:bg-red-500/30 transition-colors">
                    <span class="material-icons-round text-red-400 text-sm">delete</span>
                </button>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-16 bg-surface-100/30 rounded-2xl border border-surface-400/10">
        <div class="w-16 h-16 mx-auto mb-3 rounded-full bg-surface-200/80 flex items-center justify-center">
            <span class="material-icons-round text-surface-400 text-3xl">inventory_2</span>
        </div>
        <h3 class="text-white font-semibold text-sm mb-1">No listings yet</h3>
        <p class="text-zinc-500 text-xs mb-4">Start selling your items on the marketplace!</p>
        <a href="/marketplace/create" class="inline-flex items-center gap-1.5 gradient-brand px-5 py-2 rounded-full text-white text-xs font-semibold">
            <span class="material-icons-round text-lg">add_business</span>
            Sell an Item
        </a>
    </div>
    <?php endif; ?>
</div>

<script>
function deleteListing(id) {
    if (!confirm('Delete this listing permanently?')) return;
    fetch('/marketplace/' + id, { method: 'DELETE', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(r => r.json()).then(d => { location.reload(); })
        .catch(() => alert('Error deleting listing'));
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
