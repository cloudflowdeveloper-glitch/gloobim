<?php $title = 'Join DTTube'; ?>
<?php ob_start(); ?>
<div class="min-h-screen flex items-center justify-center py-6 px-0 sm:px-4">
    <div class="w-full max-w-md px-0 sm:px-0">

        <div class="text-center mb-6 px-4">
            <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl gradient-brand shadow-lg shadow-brand-500/30 mb-3">
                <span class="material-icons-round text-white text-3xl">play_circle</span>
            </div>
            <h1 class="font-display text-2xl font-bold text-white">Join DTTube</h1>
            <p class="text-zinc-400 text-sm mt-1">Create your account and start creating</p>
        </div>

        <div class="flex items-center justify-center gap-2 mb-6 px-4">
            <div class="flex items-center gap-1.5" id="stepIndicator">
                <span class="step-dot w-2 h-2 rounded-full bg-brand-500 transition-all duration-300" data-step="1"></span>
                <span class="w-8 h-0.5 rounded-full bg-surface-400/30 transition-all duration-300" id="stepLine"></span>
                <span class="step-dot w-2 h-2 rounded-full bg-surface-400/30 transition-all duration-300" data-step="2"></span>
            </div>
            <span class="text-zinc-500 text-[10px] font-medium ml-2" id="stepLabel">Step 1 of 2</span>
        </div>

        <div class="bg-surface-100/60 backdrop-blur-xl rounded-none sm:rounded-3xl border-0 sm:border border-surface-400/20 px-4 sm:px-6 py-6 shadow-xl">

            <div id="step1" class="block">
                <div class="flex items-center gap-3 mb-5">
                    <div class="flex-1 h-px bg-surface-400/30"></div>
                    <span class="text-zinc-500 text-xs font-medium">Quick Sign Up</span>
                    <div class="flex-1 h-px bg-surface-400/30"></div>
                </div>

                <div class="grid grid-cols-4 gap-2 mb-6">
                    <a href="/auth/google" class="flex items-center justify-center py-2.5 rounded-xl bg-surface-200/80 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/30 transition-all group">
                        <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                    </a>
                    <a href="/auth/apple" class="flex items-center justify-center py-2.5 rounded-xl bg-surface-200/80 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/30 transition-all group">
                        <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#fff" d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/></svg>
                    </a>
                    <a href="/auth/facebook" class="flex items-center justify-center py-2.5 rounded-xl bg-surface-200/80 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/30 transition-all group">
                        <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#1877F2" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    </a>
                    <a href="/auth/x" class="flex items-center justify-center py-2.5 rounded-xl bg-surface-200/80 hover:bg-surface-200 border border-surface-400/20 hover:border-brand-500/30 transition-all group">
                        <svg class="w-4 h-4" viewBox="0 0 24 24"><path fill="#fff" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                    </a>
                </div>

                <div class="relative mb-5">
                    <div class="absolute inset-0 flex items-center">
                        <div class="w-full border-t border-surface-400/20"></div>
                    </div>
                    <div class="relative flex justify-center">
                        <span class="px-3 bg-surface-100/60 text-zinc-500 text-xs">or sign up with email</span>
                    </div>
                </div>

                <form id="step1Form" class="space-y-4">
                    <div class="grid grid-cols-2 gap-3">
                        <div class="relative">
                            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 material-icons-round text-zinc-500 text-lg">person</span>
                            <input type="text" id="firstName" placeholder="First Name" required class="w-full bg-surface-200/80 text-white pl-10 pr-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                        </div>
                        <div class="relative">
                            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 material-icons-round text-zinc-500 text-lg">person</span>
                            <input type="text" id="lastName" placeholder="Last Name" required class="w-full bg-surface-200/80 text-white pl-10 pr-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                        </div>
                    </div>

                    <div class="relative">
                        <span class="absolute left-3.5 top-1/2 -translate-y-1/2 material-icons-round text-zinc-500 text-lg">email</span>
                        <input type="email" id="regEmail" placeholder="Email address" required class="w-full bg-surface-200/80 text-white pl-10 pr-4 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                    </div>

                    <div class="relative">
                        <span class="absolute left-3.5 top-1/2 -translate-y-1/2 material-icons-round text-zinc-500 text-lg">lock</span>
                        <input type="password" id="regPassword" placeholder="Password" required minlength="8" class="w-full bg-surface-200/80 text-white pl-10 pr-10 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                        <button type="button" onclick="togglePassword()" class="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors">
                            <span class="material-icons-round text-lg" id="passToggle">visibility_off</span>
                        </button>
                    </div>

                    <div class="flex items-center gap-4 py-1">
                        <div class="flex-1 h-1 rounded-full bg-surface-300 overflow-hidden">
                            <div class="h-full rounded-full transition-all duration-300" id="strengthBar" style="width: 0%"></div>
                        </div>
                        <span class="text-[10px] text-zinc-500 font-medium" id="strengthLabel"></span>
                    </div>

                    <div class="flex items-start gap-2.5">
                        <input type="checkbox" id="terms" class="mt-0.5 accent-brand-500">
                        <label for="terms" class="text-zinc-400 text-xs leading-relaxed">I agree to the <a href="#" class="text-brand-400 hover:underline">Terms of Service</a> and <a href="#" class="text-brand-400 hover:underline">Privacy Policy</a></label>
                    </div>

                    <button type="button" onclick="goToStep2()" class="w-full py-3 rounded-xl gradient-brand text-white text-sm font-bold hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-brand-500/25">
                        <span class="material-icons-round text-lg">arrow_forward</span>
                        Continue
                    </button>
                </form>
            </div>

            <div id="step2" class="hidden">
                <div class="flex flex-col items-center mb-6">
                    <div class="relative mb-4">
                        <div class="w-24 h-24 rounded-full gradient-brand flex items-center justify-center text-white text-3xl font-bold" id="avatarPreview">
                            <span class="material-icons-round text-4xl">person</span>
                        </div>
                        <button type="button" onclick="document.getElementById('avatarInput').click()" class="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-brand-600 border-2 border-surface-100 flex items-center justify-center hover:bg-brand-500 transition-colors shadow-lg">
                            <span class="material-icons-round text-white text-[16px]">camera_alt</span>
                        </button>
                        <input type="file" id="avatarInput" accept="image/*" class="hidden" onchange="previewAvatar(event)">
                    </div>
                    <h2 class="text-white font-bold text-lg">Set up your profile</h2>
                    <p class="text-zinc-400 text-xs text-center">Choose a username and tell us about yourself</p>
                </div>

                <form method="POST" action="/register" class="space-y-4">
                    <input type="hidden" name="first_name" id="hiddenFirstName">
                    <input type="hidden" name="last_name" id="hiddenLastName">
                    <input type="hidden" name="email" id="hiddenEmail">
                    <input type="hidden" name="password" id="hiddenPassword">

                    <div class="relative">
                        <span class="absolute left-3.5 top-1/2 -translate-y-1/2 material-icons-round text-zinc-500 text-lg">badge</span>
                        <div class="flex">
                            <span class="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-surface-400/30 bg-surface-300/80 text-zinc-400 text-sm">dttube.com/</span>
                            <input type="text" name="username" id="regUsername" placeholder="username" required class="flex-1 bg-surface-200/80 text-white pr-4 py-2.5 rounded-r-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                        </div>
                        <span class="text-[10px] text-zinc-600 mt-1 block" id="usernameHint">Choose a unique username</span>
                    </div>

                    <div class="relative">
                        <span class="absolute left-3.5 top-4 material-icons-round text-zinc-500 text-lg">info</span>
                        <textarea name="bio" id="regBio" placeholder="Write a short bio about yourself..." rows="3" maxlength="150" class="w-full bg-surface-200/80 text-white pl-10 pr-4 pt-3 pb-2 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors resize-none"></textarea>
                        <span class="text-[10px] text-zinc-600 mt-1 block text-right" id="bioCount">0/150</span>
                    </div>

                    <div>
                        <label class="block text-zinc-400 text-[11px] font-medium mb-2">What interests you?</label>
                        <div class="flex flex-wrap gap-2" id="interestTags">
                            <?php
                            $interests = ['Music', 'Dance', 'Gaming', 'Comedy', 'Education', 'Sports', 'Fashion', 'Art', 'Tech', 'Cooking', 'Travel', 'News'];
                            foreach ($interests as $interest):
                            ?>
                            <label class="interest-tag cursor-pointer px-3 py-1.5 rounded-full bg-surface-200/80 border border-surface-400/30 text-zinc-400 text-[11px] font-medium hover:border-brand-500/40 hover:text-brand-300 transition-all has-[:checked]:bg-brand-600/20 has-[:checked]:border-brand-500/50 has-[:checked]:text-brand-300">
                                <input type="checkbox" name="interests[]" value="<?= $interest ?>" class="hidden">
                                <?= $interest ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="flex items-center gap-3 pt-2">
                        <button type="button" onclick="goToStep1()" class="flex-1 py-2.5 rounded-xl bg-surface-200 border border-surface-400/30 text-zinc-300 text-sm font-semibold hover:bg-surface-300 transition-colors flex items-center justify-center gap-1">
                            <span class="material-icons-round text-lg">chevron_left</span>
                            Back
                        </button>
                        <button type="submit" class="flex-1 py-2.5 rounded-xl gradient-brand text-white text-sm font-bold hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-brand-500/25">
                            <span class="material-icons-round text-lg">check_circle</span>
                            Create Account
                        </button>
                    </div>
                </form>
            </div>

        </div>

        <p class="text-center mt-6 text-zinc-500 text-sm px-4">
            Already have an account?
            <a href="/login" class="text-brand-400 font-semibold hover:text-brand-300 transition-colors">Sign In</a>
        </p>
    </div>
</div>

<script>
let currentStep = 1;

function goToStep2() {
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;

    if (!firstName || !lastName || !email || !password) {
        alert('Please fill in all fields');
        return;
    }
    if (password.length < 8) {
        alert('Password must be at least 8 characters');
        return;
    }
    if (!document.getElementById('terms').checked) {
        alert('Please agree to the Terms of Service');
        return;
    }

    document.getElementById('hiddenFirstName').value = firstName;
    document.getElementById('hiddenLastName').value = lastName;
    document.getElementById('hiddenEmail').value = email;
    document.getElementById('hiddenPassword').value = password;

    document.getElementById('step1').classList.add('hidden');
    document.getElementById('step2').classList.remove('hidden');
    document.querySelectorAll('.step-dot')[0].classList.remove('bg-brand-500');
    document.querySelectorAll('.step-dot')[0].classList.add('bg-emerald-500');
    document.querySelectorAll('.step-dot')[1].classList.remove('bg-surface-400/30');
    document.querySelectorAll('.step-dot')[1].classList.add('bg-brand-500');
    document.getElementById('stepLine').classList.remove('bg-surface-400/30');
    document.getElementById('stepLine').classList.add('bg-brand-500');
    document.getElementById('stepLabel').textContent = 'Step 2 of 2';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    currentStep = 2;
}

function goToStep1() {
    document.getElementById('step1').classList.remove('hidden');
    document.getElementById('step2').classList.add('hidden');
    document.querySelectorAll('.step-dot')[0].classList.remove('bg-emerald-500');
    document.querySelectorAll('.step-dot')[0].classList.add('bg-brand-500');
    document.querySelectorAll('.step-dot')[1].classList.remove('bg-brand-500');
    document.querySelectorAll('.step-dot')[1].classList.add('bg-surface-400/30');
    document.getElementById('stepLine').classList.remove('bg-brand-500');
    document.getElementById('stepLine').classList.add('bg-surface-400/30');
    document.getElementById('stepLabel').textContent = 'Step 1 of 2';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    currentStep = 1;
}

function togglePassword() {
    const pwd = document.getElementById('regPassword');
    const icon = document.getElementById('passToggle');
    pwd.type = pwd.type === 'password' ? 'text' : 'password';
    icon.textContent = pwd.type === 'password' ? 'visibility_off' : 'visibility';
}

document.getElementById('regPassword')?.addEventListener('input', function() {
    const val = this.value;
    const bar = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    let score = 0;
    if (val.length >= 8) score += 25;
    if (val.length >= 12) score += 15;
    if (/[A-Z]/.test(val)) score += 20;
    if (/[0-9]/.test(val)) score += 20;
    if (/[^A-Za-z0-9]/.test(val)) score += 20;
    bar.style.width = Math.min(score, 100) + '%';
    if (score < 30) { bar.className = 'h-full rounded-full bg-red-500'; label.textContent = 'Weak'; label.className = 'text-[10px] text-red-400 font-medium'; }
    else if (score < 60) { bar.className = 'h-full rounded-full bg-amber-500'; label.textContent = 'Fair'; label.className = 'text-[10px] text-amber-400 font-medium'; }
    else if (score < 85) { bar.className = 'h-full rounded-full bg-lime-500'; label.textContent = 'Good'; label.className = 'text-[10px] text-lime-400 font-medium'; }
    else { bar.className = 'h-full rounded-full bg-emerald-500'; label.textContent = 'Strong'; label.className = 'text-[10px] text-emerald-400 font-medium'; }
});

document.getElementById('regBio')?.addEventListener('input', function() {
    document.getElementById('bioCount').textContent = this.value.length + '/150';
});

document.getElementById('regUsername')?.addEventListener('input', function() {
    const hint = document.getElementById('usernameHint');
    if (this.value.length > 0) {
        hint.textContent = '@' + this.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
        hint.className = 'text-[10px] text-brand-400 mt-1 block';
    } else {
        hint.textContent = 'Choose a unique username';
        hint.className = 'text-[10px] text-zinc-600 mt-1 block';
    }
});

function previewAvatar(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(ev) {
        const preview = document.getElementById('avatarPreview');
        preview.innerHTML = '<img src="' + ev.target.result + '" class="w-full h-full rounded-full object-cover">';
        preview.className = 'w-24 h-24 rounded-full flex items-center justify-center overflow-hidden';
    };
    reader.readAsDataURL(file);
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
