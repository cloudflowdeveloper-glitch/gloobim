<?php $activeTab = 'menu'; $title = 'Account Settings - DTTube'; ?>
<?php
$user = \Core\Auth::user();
$name = $user['name'] ?? 'User';
$username = $user['username'] ?? 'user';
$email = $user['email'] ?? '';
$bio = $user['bio'] ?? '';
$avatar = $user['avatar'] ?? null;
$phone = $user['phone'] ?? '';
$isVerified = !empty($user['is_verified']);
$initials = '';
if ($name) {
    $parts = explode(' ', $name);
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}
?>
<?php ob_start(); ?>
<div class="max-w-lg mx-auto px-3 py-4">

    <div class="flex items-center gap-3 mb-6">
        <a href="/menu" class="w-9 h-9 rounded-full bg-surface-200 flex items-center justify-center hover:bg-surface-300 transition-colors">
            <span class="material-icons-round text-zinc-400 text-xl">chevron_left</span>
        </a>
        <h1 class="font-display text-lg font-bold text-white">Account Settings</h1>
    </div>

    <div class="bg-surface-100/60 rounded-2xl border border-surface-400/15 p-5 mb-4">
        <div class="flex items-center gap-4 mb-5">
            <div class="relative flex-shrink-0">
                <?php if ($avatar): ?>
                <img src="<?= $avatar ?>" alt="" class="w-20 h-20 rounded-full object-cover">
                <?php else: ?>
                <div class="w-20 h-20 rounded-full gradient-brand flex items-center justify-center text-white text-2xl font-bold">
                    <?= $initials ?: 'U' ?>
                </div>
                <?php endif; ?>
                <button class="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-brand-600 border-2 border-surface-100 flex items-center justify-center hover:bg-brand-500 transition-colors">
                    <span class="material-icons-round text-white text-[14px]">edit</span>
                </button>
            </div>
            <div>
                <h2 class="text-white font-bold text-base"><?= htmlspecialchars($name) ?></h2>
                <p class="text-zinc-500 text-xs">@<?= htmlspecialchars($username) ?></p>
                <div class="flex items-center gap-1 mt-1">
                    <?php if (!empty($user['role']) || true): ?>
                    <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-medium">Member</span>
                    <?php endif; ?>
                    <?php if ($isVerified): ?>
                    <span class="text-[10px] px-2 py-0.5 rounded-full bg-brand-500/20 text-brand-400 font-medium">Verified</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <form method="POST" action="/profile/update" class="space-y-4" id="settingsForm">
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">First Name</label>
                    <input type="text" name="first_name" value="<?= htmlspecialchars(explode(' ', $name)[0] ?? '') ?>" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                </div>
                <div>
                    <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Last Name</label>
                    <input type="text" name="last_name" value="<?= htmlspecialchars(explode(' ', $name)[1] ?? '') ?>" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                </div>
            </div>

            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Display Name</label>
                <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
            </div>

            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Username</label>
                <div class="relative">
                    <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">@</span>
                    <input type="text" name="username" value="<?= htmlspecialchars($username) ?>" class="w-full bg-surface-200/80 text-white pl-8 pr-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
                </div>
            </div>

            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Bio</label>
                <textarea name="bio" rows="3" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors resize-none"><?= htmlspecialchars($bio) ?></textarea>
            </div>

            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
            </div>

            <div>
                <label class="block text-zinc-400 text-[11px] font-medium mb-1.5">Phone Number</label>
                <input type="tel" name="phone" value="<?= htmlspecialchars($phone) ?>" class="w-full bg-surface-200/80 text-white px-3.5 py-2.5 rounded-xl border border-surface-400/30 focus:border-brand-500/60 focus:outline-none text-sm placeholder:text-zinc-500 transition-colors">
            </div>

            <button type="button" onclick="saveSettings()" class="w-full py-2.5 rounded-xl gradient-brand text-white text-sm font-bold hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2">
                <span class="material-icons-round text-lg">save</span>
                Save Changes
            </button>
        </form>
    </div>

    <div class="bg-surface-100/60 rounded-2xl border border-surface-400/15 p-5 mb-4">
        <h3 class="text-white font-bold text-sm mb-4 flex items-center gap-2">
            <span class="material-icons-round text-zinc-500 text-lg">security</span>
            Security
        </h3>
        <div class="space-y-3">
            <button onclick="alert('Password change form would open')" class="w-full flex items-center justify-between p-3 rounded-xl bg-surface-200/60 hover:bg-surface-200 border border-surface-400/20 transition-colors">
                <div class="flex items-center gap-3">
                    <span class="material-icons-round text-zinc-500">lock</span>
                    <div class="text-left">
                        <span class="block text-white text-xs font-semibold">Change Password</span>
                        <span class="block text-zinc-500 text-[10px]">Update your password regularly</span>
                    </div>
                </div>
                <span class="material-icons-round text-zinc-500">chevron_right</span>
            </button>
            <button onclick="alert('Two-factor auth setup')" class="w-full flex items-center justify-between p-3 rounded-xl bg-surface-200/60 hover:bg-surface-200 border border-surface-400/20 transition-colors">
                <div class="flex items-center gap-3">
                    <span class="material-icons-round text-zinc-500">verified_user</span>
                    <div class="text-left">
                        <span class="block text-white text-xs font-semibold">Two-Factor Authentication</span>
                        <span class="block text-zinc-500 text-[10px]">Add extra security to your account</span>
                    </div>
                </div>
                <span class="material-icons-round text-zinc-500">chevron_right</span>
            </button>
            <button onclick="alert('Sessions page')" class="w-full flex items-center justify-between p-3 rounded-xl bg-surface-200/60 hover:bg-surface-200 border border-surface-400/20 transition-colors">
                <div class="flex items-center gap-3">
                    <span class="material-icons-round text-zinc-500">devices</span>
                    <div class="text-left">
                        <span class="block text-white text-xs font-semibold">Active Sessions</span>
                        <span class="block text-zinc-500 text-[10px]">Manage where you're logged in</span>
                    </div>
                </div>
                <span class="material-icons-round text-zinc-500">chevron_right</span>
            </button>
        </div>
    </div>

    <div class="bg-surface-100/60 rounded-2xl border border-surface-400/15 p-5 mb-4">
        <h3 class="text-white font-bold text-sm mb-4 flex items-center gap-2">
            <span class="material-icons-round text-zinc-500 text-lg">notifications</span>
            Notifications
        </h3>
        <div class="space-y-3">
            <label class="flex items-center justify-between p-3 rounded-xl bg-surface-200/60 border border-surface-400/20 cursor-pointer">
                <div>
                    <span class="block text-white text-xs font-semibold">Push Notifications</span>
                    <span class="block text-zinc-500 text-[10px]">Receive push notifications</span>
                </div>
                <input type="checkbox" checked class="accent-brand-500 w-4 h-4">
            </label>
            <label class="flex items-center justify-between p-3 rounded-xl bg-surface-200/60 border border-surface-400/20 cursor-pointer">
                <div>
                    <span class="block text-white text-xs font-semibold">Email Updates</span>
                    <span class="block text-zinc-500 text-[10px]">Receive email newsletters and updates</span>
                </div>
                <input type="checkbox" checked class="accent-brand-500 w-4 h-4">
            </label>
            <label class="flex items-center justify-between p-3 rounded-xl bg-surface-200/60 border border-surface-400/20 cursor-pointer">
                <div>
                    <span class="block text-white text-xs font-semibold">SMS Alerts</span>
                    <span class="block text-zinc-500 text-[10px]">Receive SMS for important updates</span>
                </div>
                <input type="checkbox" class="accent-brand-500 w-4 h-4">
            </label>
        </div>
    </div>

    <div class="bg-surface-100/60 rounded-2xl border border-red-500/20 p-5 mb-6">
        <h3 class="text-red-400 font-bold text-sm mb-3 flex items-center gap-2">
            <span class="material-icons-round text-lg">dangerous</span>
            Danger Zone
        </h3>
        <p class="text-zinc-500 text-[11px] mb-4">Permanently delete your account and all data. This action cannot be undone.</p>
        <button onclick="if(confirm('Are you sure? This cannot be undone!')) alert('Account deletion requested')" class="w-full py-2.5 rounded-xl bg-red-600/20 border border-red-500/30 text-red-400 text-sm font-semibold hover:bg-red-600/30 transition-colors flex items-center justify-center gap-2">
            <span class="material-icons-round text-lg">delete_forever</span>
            Delete Account
        </button>
    </div>

</div>

<script>
function saveSettings() {
    const form = document.getElementById('settingsForm');
    const formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => { data[key] = value; });

    fetch('/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify(data)
    }).then(r => r.json()).then(d => {
        if (d.message) {
            alert(d.message);
            if (d.message.includes('success')) location.reload();
        }
    }).catch(() => alert('Failed to save settings'));
}
</script>
<?php $content = ob_get_clean(); ?>
<?php require __DIR__ . '/../layouts/app.php'; ?>
