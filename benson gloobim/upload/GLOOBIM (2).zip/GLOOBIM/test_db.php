<?php
$host = '127.0.0.1';
$port = 3306;
$user = 'root';
$pass = '';
$dbname = 'dttube';

echo "=== MySQL Connection Test ===\n";

$conn = @new \mysqli($host, $user, $pass, '', $port);
if ($conn->connect_error) {
    echo "CONNECTION FAILED: " . $conn->connect_error . "\n";
    echo "Make sure MySQL server is running!\n";
    exit(1);
}

echo "MySQL CONNECTED OK\n";

$result = $conn->query("SHOW DATABASES LIKE '{$dbname}'");
if ($result->num_rows > 0) {
    echo "Database '{$dbname}' EXISTS\n";
    $conn->select_db($dbname);
    $tables = $conn->query('SHOW TABLES');
    echo "Tables count: " . $tables->num_rows . "\n";
    while ($row = $tables->fetch_array()) {
        echo "  - " . $row[0] . "\n";
    }
    $users = $conn->query("SELECT id, username, name, email FROM users");
    if ($users) {
        echo "\nUsers:\n";
        while ($u = $users->fetch_assoc()) {
            echo "  [{$u['id']}] {$u['username']} - {$u['name']} ({$u['email']})\n";
        }
    }
    $reels = $conn->query("SELECT COUNT(*) AS cnt FROM reels");
    if ($reels) {
        echo "\nReels count: " . $reels->fetch_assoc()['cnt'] . "\n";
    }
} else {
    echo "Database '{$dbname}' DOES NOT EXIST yet (will be auto-created on next page load)\n";
}

$conn->close();
echo "\nTest complete.\n";
