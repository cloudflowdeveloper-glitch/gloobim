<?php
$html = @file_get_contents('http://localhost:8000/');
if ($html === false) {
    echo "FAILED to fetch page\n";
} else {
    echo "Page length: " . strlen($html) . " bytes\n";
    echo "Has DOCTYPE: " . (str_contains($html, '<!DOCTYPE') ? 'YES' : 'NO') . "\n";
    echo "Has Tailwind: " . (str_contains($html, 'tailwindcss') ? 'YES' : 'NO') . "\n";
    echo "Has body tag: " . (str_contains($html, '<body') ? 'YES' : 'NO') . "\n";
    echo "Has Fatal error: " . (str_contains($html, 'Fatal error') ? 'YES' : 'NO') . "\n";
    echo "Has formatCount error: " . (str_contains($html, 'formatCount') ? 'MAYBE' : 'NO') . "\n";
    echo "Has nav bar: " . (str_contains($html, 'glass fixed') ? 'YES' : 'NO') . "\n";
    echo "Has DTTube: " . (str_contains($html, 'DTTube') ? 'YES' : 'NO') . "\n";
    echo "\n--- First 500 chars ---\n";
    echo substr($html, 0, 500);
    echo "\n\n--- Last 300 chars ---\n";
    echo substr($html, -300);
}
