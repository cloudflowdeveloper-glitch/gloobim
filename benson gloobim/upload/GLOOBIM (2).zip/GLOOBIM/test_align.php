<?php
$h = @file_get_contents('http://localhost:8000/livestream/1');
if (!$h) { echo "FAILED\n"; exit; }
echo "Nav max-w-lg: " . (strpos($h, 'max-w-lg mx-auto') !== false ? 'YES' : 'NO') . "\n";
echo "Main has max-w-lg: " . (preg_match('/<main[^>]*max-w-lg/', $h) ? 'YES' : 'NO') . "\n";
echo "max-width 100%: " . (strpos($h, 'max-width: 100%') !== false ? 'STILL HAS' : 'REMOVED') . "\n";
echo "live-main inside main: " . (preg_match('/<main[^>]*>.*live-main/s', $h) ? 'YES' : 'NO') . "\n";
echo "Top nav: " . (strpos($h, 'glass fixed top-0') !== false ? 'YES' : 'NO') . "\n";
echo "Bottom nav: " . (strpos($h, 'glass-bottom') !== false ? 'YES' : 'NO') . "\n";
