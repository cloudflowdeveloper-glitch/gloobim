<?php
$urls = [
    'Home' => 'http://localhost:8000/',
    'Livestream' => 'http://localhost:8000/livestream',
    'Livestream/1' => 'http://localhost:8000/livestream/1',
    'Go Live' => 'http://localhost:8000/livestream/start',
];
foreach ($urls as $name => $url) {
    $html = @file_get_contents($url);
    if ($html === false) {
        echo "{$name}: FAILED\n";
    } else {
        $hasLayout = str_contains($html, '<!DOCTYPE');
        $hasError = str_contains($html, 'Fatal error') || str_contains($html, 'Undefined');
        $hasContent = str_contains($html, 'Live Chat') || str_contains($html, 'DTTube') || str_contains($html, 'Live') || $name === 'Home';
        echo "{$name}: " . strlen($html) . " bytes | Layout: " . ($hasLayout ? 'YES' : 'NO') . " | Error: " . ($hasError ? 'YES' : 'NO') . " | HasContent: " . ($hasContent ? 'YES' : 'NO') . "\n";
    }
}
